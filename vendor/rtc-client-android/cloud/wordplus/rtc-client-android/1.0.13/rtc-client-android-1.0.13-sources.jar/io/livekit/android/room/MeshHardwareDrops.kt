/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.content.Context
import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.util.LKLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import livekit.org.webrtc.MediaStreamTrack
import livekit.org.webrtc.RTCStatsReport
import livekit.org.webrtc.RtpSender

// WordPlus Mesh (1.0.5, as @wordplus/realtime-client's calls/encoder-watch.ts in a browser): a camera's hardware encoder
// that drops frames, found while it sends, so this device's next camera goes out in software. A Windows PC's AMD encoder
// sent its camera at 3-6 frames a second of the 15 it was given (2026-10-21), and the mesh's lab gets the same of a
// Mac's VideoToolbox under heavy grain: libwebrtc takes whole frames off the camera when an encoder it doesn't trust
// overshoots, every layer at once, and names nothing that held it back. It is a device's, not a maker's. The calls that
// pick a camera's codec skip one this device remembers ([MeshHardwareDrops.codecs]); the camera sending now isn't
// changed.

/**
 * The codecs whose hardware encoder this device saw take a camera's frames off, remembered for a month: a driver or
 * system update may mend it.
 */
object MeshHardwareDrops {
    internal const val PREFERENCES = "wordplus-rtc"
    internal const val KEY = "hardware-drops"
    internal const val REMEMBER_FOR_MS = 30L * 24 * 3600 * 1000

    /** Where the codecs are kept: the app's preferences, or a map in a test. */
    internal interface Store {
        fun read(): Map<String, Long>
        fun write(seen: Map<String, Long>)
    }

    private class Preferences(context: Context) : Store {
        private val preferences = context.applicationContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

        override fun read(): Map<String, Long> =
            preferences.getStringSet(KEY, emptySet()).orEmpty().mapNotNull { entry ->
                val (codec, at) = entry.split(':', limit = 2).takeIf { it.size == 2 } ?: return@mapNotNull null
                at.toLongOrNull()?.let { codec to it }
            }.toMap()

        override fun write(seen: Map<String, Long>) {
            preferences.edit().putStringSet(KEY, seen.map { (codec, at) -> "$codec:$at" }.toSet()).apply()
        }
    }

    @Volatile
    private var listener: ((String) -> Unit)? = null

    /** Called on a background thread when the watch finds a camera's hardware dropping frames, with the codec. */
    fun setListener(onFound: ((String) -> Unit)?) {
        listener = onFound
    }

    /**
     * The codecs ("h264", "h265") this device saw its hardware encoder drop a camera's frames of in the last month.
     * 1.0.9: as long as the settings say (`tune.rememberDropsDays`, 30 where they say nothing; 0 remembers none), and
     * none seen before `tune.forgetBefore` (Unix ms), which measures every device again from then.
     */
    @JvmOverloads
    fun codecs(context: Context, now: Long = System.currentTimeMillis(), settings: MeshSettings = MeshSettings.NONE): List<String> =
        codecs(Preferences(context), now, settings)

    /** Remembers that this device's hardware encoder dropped a camera's frames in codec; VP8 is left out. */
    fun remember(context: Context, codec: String, now: Long = System.currentTimeMillis()) {
        remember(Preferences(context), codec, now)
    }

    /** Forgets every codec, for a test or a settings screen's reset. */
    fun forget(context: Context) {
        Preferences(context).write(emptyMap())
    }

    internal fun codecs(store: Store, now: Long, settings: MeshSettings = MeshSettings.NONE): List<String> {
        val keep = settings.number("tune.rememberDropsDays")?.let { (it * 24 * 3600 * 1000).toLong() } ?: REMEMBER_FOR_MS
        val since = settings.number("tune.forgetBefore")?.toLong() ?: 0L
        return store.read().filter { (codec, at) -> codec != "vp8" && now - at in 0 until keep && at >= since }.keys.sorted()
    }

    internal fun remember(store: Store, codec: String, now: Long) {
        val name = codec.lowercase()
        if (name == "vp8" || name.isEmpty()) return
        store.write(store.read() + (name to now))
    }

    internal fun found(codec: String) {
        listener?.invoke(codec)
    }
}

/**
 * The rule, as encoder-watch.ts has it: over the last [READINGS] readings (30 s), each of them a hardware encoder's
 * ([hardwareReading]): the camera goes out in H.264 or H.265 from a layer sent in hardware, its source gives at least
 * [MIN_CAPTURED] frames a second, the device names nothing that limits a layer, the hardware keeps up with its source
 * ([slowMs]: at most [MAX_ENCODE_MS] a frame, or [KEEP_UP_SHARE] of the time between two of its source's frames where
 * that is longer, so not a slow device), and a hardware layer sends at least [MIN_SENT] of a target of [MIN_TARGET] or
 * more (an encoder cut off by a path gone down sends nothing and reports no target); and the layer that keeps the most
 * has encoded [SHARE] or less of the frames its source gave in all. A software encoder short of bits drops its own
 * layer's frames alone, and a dim room's camera gives fewer frames, which every layer sends.
 */
internal object HardwareDropRule {
    const val READ_EVERY_MS = 5_000L
    const val READINGS = 6

    // the readings of a camera's first 10 s, left out: its encoder starting sends a frame or two of them
    const val WARMUP = 2
    const val SHARE = 0.7

    // 10 before 1.0.13, as realtime-client before 1.0.85: a dim room's camera giving 9-10 frames a second was never
    // judged, and at 5 a second 30 s is still 150 frames to judge
    const val MIN_CAPTURED = 5.0
    const val MAX_ENCODE_MS = 25.0

    // past MAX_ENCODE_MS a frame's encoding still keeps up while it takes no more than this share of the time between
    // the source's frames (1.0.13, realtime-client 1.0.85's HARDWARE_KEEP_UP_SHARE): 27 ms at 30 a second, 80 at 10
    const val KEEP_UP_SHARE = 0.8
    const val MIN_TARGET = 100_000.0
    const val MIN_SENT = 0.25

    // the watch ends after this long without a camera, until the next one is published (1.0.9)
    const val IDLE_END_MS = 10L * 60 * 1000

    /**
     * The rule's numbers (1.0.9): the settings' (`watch.everyMs`, `watch.warmups`, `watch.dropShare`,
     * `watch.minCapturedFps`, `watch.maxEncodeMs`, `watch.minTargetKbps`, `watch.minSent`, `watch.idleEndMin`, and
     * `tune.dropWatchS` over the readings' pace for their count), the constants above where they say nothing.
     */
    data class Tune(
        val readEveryMs: Long = READ_EVERY_MS,
        val readings: Int = READINGS,
        val warmup: Int = WARMUP,
        val share: Double = SHARE,
        val minCaptured: Double = MIN_CAPTURED,
        val maxEncodeMs: Double = MAX_ENCODE_MS,
        val minTarget: Double = MIN_TARGET,
        val minSent: Double = MIN_SENT,
        val idleEndMs: Long = IDLE_END_MS,
    ) {
        companion object {
            fun of(settings: MeshSettings): Tune {
                val every = settings.number("watch.everyMs")?.toLong() ?: READ_EVERY_MS
                val window = settings.number("tune.dropWatchS")?.let { it * 1000 } ?: (READ_EVERY_MS * READINGS).toDouble()
                return Tune(
                    readEveryMs = every,
                    readings = maxOf(1, Math.round(window / every).toInt()),
                    warmup = settings.int("watch.warmups") ?: WARMUP,
                    share = settings.number("watch.dropShare") ?: SHARE,
                    minCaptured = settings.number("watch.minCapturedFps") ?: MIN_CAPTURED,
                    maxEncodeMs = settings.number("watch.maxEncodeMs") ?: MAX_ENCODE_MS,
                    minTarget = settings.number("watch.minTargetKbps")?.let { it * 1000 } ?: MIN_TARGET,
                    minSent = settings.number("watch.minSent") ?: MIN_SENT,
                    idleEndMs = settings.number("watch.idleEndMin")?.let { (it * 60_000).toLong() } ?: IDLE_END_MS,
                )
            }
        }
    }

    /** One layer between two readings. */
    data class Layer(
        val active: Boolean,
        val fps: Double,
        val hardware: Boolean,
        val limit: String,
        val encodeMs: Double?,
        val target: Double?,
        val sentBps: Double,
    )

    /** A camera's sender between two readings: its codec ("h264"), its source's frames a second, and its layers. */
    data class Reading(val codec: String?, val captured: Double, val layers: List<Layer>)

    /** A layer's counts at a reading, from which the next takes what changed. */
    data class Counts(val frames: Double, val encodeTime: Double, val bytes: Double, val at: Double)

    /**
     * The longest a hardware encoder may take a frame and still be keeping up with a source giving `captured` frames a
     * second (1.0.13, encoder-watch.ts's hardwareSlowMs): the limit itself, or [KEEP_UP_SHARE] of the time between two
     * frames where that is longer.
     */
    fun slowMs(captured: Double, tune: Tune = Tune()): Double =
        if (captured > 0) maxOf(tune.maxEncodeMs, KEEP_UP_SHARE * 1000 / captured) else tune.maxEncodeMs

    /**
     * A reading of a hardware encoder that nothing the device names holds back: the frames a second of the layer that
     * keeps the most, and its source's; null for any other.
     */
    fun hardwareReading(r: Reading, tune: Tune = Tune()): Pair<Double, Double>? {
        if (r.codec != "h264" && r.codec != "h265") return null
        if (r.captured < tune.minCaptured) return null
        val sent = r.layers.filter { it.active }
        if (sent.none { it.hardware }) return null
        if (sent.none { it.hardware && (it.target ?: 0.0) >= tune.minTarget && it.sentBps >= (it.target ?: 0.0) * tune.minSent }) return null
        val slow = slowMs(r.captured, tune)
        if (sent.any { (it.limit != "none" && it.limit.isNotEmpty()) || (it.hardware && (it.encodeMs ?: 0.0) > slow) }) return null
        return (sent.maxOfOrNull { it.fps } ?: 0.0) to r.captured
    }

    /** Whether readings, the last [Tune.readings] of them, are a hardware encoder taking the whole camera's frames off. */
    fun dropsFrames(list: List<Reading>, tune: Tune = Tune()): Boolean {
        if (list.size < tune.readings) return false
        val read = list.takeLast(tune.readings).map { hardwareReading(it, tune) }
        if (read.any { it == null }) return false
        val kept = read.sumOf { it!!.first }
        val given = read.sumOf { it!!.second }
        return kept <= given * tune.share
    }

    /**
     * A camera sender's reading from its stats against the counts of the one before (null the first time). rids: its
     * encodings', lowest first, which a SimulcastEncoderAdapter names its encoders in; maxFps: the most frames a second
     * they send (0: none said), over which the source's frames aren't the encoder's to send.
     */
    fun read(
        stats: List<MeshEncoders.Stat>,
        at: Double,
        before: Map<String, Counts>?,
        rids: List<String>,
        maxFps: Double = 0.0,
    ): Pair<Reading?, Map<String, Counts>> {
        val byId = stats.associateBy { it.id }
        fun num(v: Any?): Double? = (v as? Number)?.toDouble()
        fun str(v: Any?): String? = v as? String
        val counts = mutableMapOf<String, Counts>()
        val layers = mutableListOf<Layer>()
        var codec: String? = null
        var captured = 0.0
        for (s in stats) {
            if (s.type != "outbound-rtp" || str(s.values["kind"]) != "video") continue
            val rid = str(s.values["rid"]) ?: ""
            val now = Counts(
                frames = num(s.values["framesEncoded"]) ?: 0.0,
                encodeTime = num(s.values["totalEncodeTime"]) ?: 0.0,
                bytes = num(s.values["bytesSent"]) ?: 0.0,
                at = at,
            )
            counts[rid] = now
            val mime = str(s.values["codecId"])?.let { byId[it] }?.let { str(it.values["mimeType"]) }?.lowercase()
            if (mime != null && mime.startsWith("video/")) codec = mime.removePrefix("video/")
            val sourceFps = str(s.values["mediaSourceId"])?.let { byId[it] }?.let { num(it.values["framesPerSecond"]) } ?: 0.0
            captured = maxOf(captured, sourceFps)
            val was = before?.get(rid) ?: continue
            if (at <= was.at) continue
            val encoded = maxOf(0.0, now.frames - was.frames)
            val implementation = str(s.values["encoderImplementation"]) ?: ""
            val names = MeshEncoders.adapterEncoders(implementation)
            val name = if (names.size > 1) rids.indexOf(rid).takeIf { it in names.indices }?.let { names[it] } ?: "" else implementation
            val target = num(s.values["targetBitrate"])
            layers.add(
                Layer(
                    active = s.values["active"] as? Boolean ?: true,
                    fps = encoded * 1000 / (at - was.at),
                    hardware = MeshEncoders.encoderHardware(
                        name,
                        if (names.size > 1) null else s.values["powerEfficientEncoder"] as? Boolean,
                    ) ?: false,
                    limit = str(s.values["qualityLimitationReason"]) ?: "",
                    encodeMs = if (encoded > 0) (now.encodeTime - was.encodeTime) * 1000 / encoded else null,
                    target = target?.takeIf { it > 0 },
                    sentBps = maxOf(0.0, now.bytes - was.bytes) * 8 * 1000 / (at - was.at),
                ),
            )
        }
        if (maxFps > 0) captured = minOf(captured, maxFps)
        return (if (before != null && layers.isNotEmpty()) Reading(codec, captured, layers) else null) to counts
    }
}

/**
 * Watches the room's published camera (its primary codec's sender, not a backup's) while connected, on any server: a
 * reading every [HardwareDropRule.READ_EVERY_MS], and once its hardware is seen dropping frames, remembers the codec and
 * tells ([MeshHardwareDrops.setListener]). A new sender, a camera muted or gone, or a path that went down starts the
 * readings over; a sender found dropping isn't read again.
 */
internal class MeshHardwareDropWatch(
    private val context: Context,
    /** The published camera now, and whether it is muted. */
    private val camera: () -> Pair<LocalVideoTrack, Boolean>?,
    /** Whether the publisher's connection is up. */
    private val pathUp: suspend () -> Boolean,
    /** A sender's stats. */
    private val statsOf: suspend (RtpSender) -> RTCStatsReport?,
    /** 1.0.6: a sender's part of the publisher's shared reading (MeshStatsHub), with the reports; null where it can't be told. */
    private val sharedStatsOf: suspend (RtpSender) -> List<MeshEncoders.Stat>? = { null },
    /** 1.0.9: the room's settings now, which the rule's numbers come from ([HardwareDropRule.Tune.of]). */
    private val settings: () -> MeshSettings = { MeshSettings.NONE },
) {
    private var job: Job? = null
    private var watched: RtpSender? = null
    private var counts: Map<String, HardwareDropRule.Counts>? = null
    private var warmup = HardwareDropRule.WARMUP

    /** 1.0.9: since when no camera was there to read. */
    private var idleSince: Long? = null

    private fun tune() = HardwareDropRule.Tune.of(settings())

    val running: Boolean
        @Synchronized get() = job?.isActive == true

    /**
     * No camera to read (none, muted, or its source stopped): the readings start over, and once that has lasted the
     * settings' `watch.idleEndMin` the watch ends, as the web's encoder watch does, until the next camera is published
     * ([start] again).
     */
    @Synchronized
    internal fun idle(tune: HardwareDropRule.Tune, now: Long = System.currentTimeMillis()) {
        over(null)
        val since = idleSince ?: now
        idleSince = since
        if (job?.isActive != true || now - since < tune.idleEndMs) return
        job?.cancel()
        job = null
        idleSince = null
        LKLog.d { "no camera for ${tune.idleEndMs / 60_000} min: the hardware-drop watch ends until the next one" }
    }
    private val last = mutableListOf<HardwareDropRule.Reading>()
    private val found = mutableSetOf<RtpSender>()

    /**
     * Reads every [HardwareDropRule.READ_EVERY_MS] of real time, in a scope of its own that [stop] ends, not the room's:
     * the room's dispatcher is injected, and a test's runs on a virtual clock that a reading without end never lets rest
     * (upstream's room tests timed out and ran out of memory); and a connect waits for the room's last scope to end,
     * which a child on the real clock let a test's clock run past its deadline (RoomMockE2ETest.connectAfterDisconnect).
     */
    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = CoroutineScope(Dispatchers.Default + SupervisorJob()).launch {
            while (isActive) {
                // 1.0.9: at the settings' pace (`watch.everyMs`)
                delay(tune().readEveryMs)
                read()
            }
        }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        over(null)
        found.clear()
        idleSince = null
    }

    @Synchronized
    private fun over(sender: RtpSender?) {
        watched = sender
        counts = null
        warmup = tune().warmup
        last.clear()
    }

    suspend fun read() {
        // 1.0.9: the rule's numbers from the room's settings, as they are at this reading
        val tune = tune()
        val (track, muted) = camera() ?: return idle(tune)
        val sender = track.sender ?: return idle(tune)
        val live = try {
            track.rtcTrack.state() == MediaStreamTrack.State.LIVE
        } catch (e: Exception) {
            false
        }
        if (muted || !live) return idle(tune)
        synchronized(this) { idleSince = null }
        if (synchronized(this) { sender in found }) return
        if (synchronized(this) { watched } != sender) over(sender)
        // a reading across a path gone down reads the frames the path took, not the encoder's
        if (!pathUp()) return over(sender)

        // 1.0.6: its part of the publisher's shared reading, with the encoders' reports; its own reading where the part
        // can't be told
        val (stats, at) = try {
            val shared = sharedStatsOf(sender)
            val sharedAt = shared?.firstOrNull { it.type == "outbound-rtp" }?.timestampUs
            if (shared != null && sharedAt != null) {
                shared to sharedAt / 1000
            } else {
                statsOf(sender)?.let { MeshEncoders.stats(it) to it.timestampUs / 1000 }
            }
        } catch (e: Exception) {
            null
        } ?: return
        val encodings = sender.parameters?.encodings.orEmpty()
        val rids = encodings.map { it.rid ?: "" }
        val maxFps = encodings.filter { it.active }.mapNotNull { it.maxFramerate?.toDouble() }.maxOrNull() ?: 0.0
        val codec = synchronized(this) {
            if (watched != sender) return
            val (reading, now) = HardwareDropRule.read(stats, at, counts, rids, maxFps)
            counts = now
            if (reading == null) return
            if (warmup > 0) {
                warmup--
                return
            }
            last.add(reading)
            while (last.size > tune.readings) last.removeAt(0)
            if (!HardwareDropRule.dropsFrames(last, tune)) return
            val codec = reading.codec ?: return
            found.add(sender)
            codec
        }
        MeshHardwareDrops.remember(context, codec)
        LKLog.w { "hardware $codec encoder takes the camera's frames off: the next camera goes out in software" }
        MeshHardwareDrops.found(codec)
    }
}
