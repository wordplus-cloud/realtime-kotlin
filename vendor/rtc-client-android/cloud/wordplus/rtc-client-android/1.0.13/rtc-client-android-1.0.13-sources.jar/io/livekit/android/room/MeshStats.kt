/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred

// WordPlus Mesh (1.0.6, as rtc-client 1.0.16's room/meshStats.ts): one reading of each connection's stats, shared, so
// telling the node more of what a client sends, plays and runs on adds no load to the device.
//
// Until 1.0.6 the mesh's reports read each sender and each receiver on its own (`getStats(sender, …)`), and libwebrtc
// gathers the whole connection's stats to answer each one: in a call of 8, 14 receivers and the camera's senders every
// 10 s, and the hardware-drop watch's camera every 5 s, ~100 gatherings a minute that grow with every person in the call.
// Here a connection is read at most once every [MeshStats.READ_EVERY_MS], and the encoders, the receivers, the
// hardware-drop watch and the health report each take their part of that one reading: a sender's outbound streams by its
// transceiver's mid (or its track's media source where none names a mid), a receiver's inbound stream by its track, with
// every entry they refer to (codec, transport, candidate pair, media source, the far end's reports). Rates stay right:
// each computes them between two readings by the stats' own timestamps.

internal object MeshStats {
    /** A shared reading is reused this long: just under 2 s, so each connection is read about once a round. */
    const val READ_EVERY_MS = 1900L

    /** The fields of a stats entry that name another one. */
    private val REFERENCES = listOf(
        "codecId",
        "transportId",
        "remoteId",
        "mediaSourceId",
        "selectedCandidatePairId",
        "localCandidateId",
        "remoteCandidateId",
    )

    /** Those entries with every one they refer to, and what those refer to. */
    fun withReferences(full: Map<String, MeshEncoders.Stat>, picked: List<MeshEncoders.Stat>): List<MeshEncoders.Stat> {
        val out = mutableListOf<MeshEncoders.Stat>()
        val seen = mutableSetOf<String>()
        val queue = ArrayDeque(picked)
        while (queue.isNotEmpty()) {
            val s = queue.removeFirst()
            if (!seen.add(s.id)) continue
            out.add(s)
            for (key in REFERENCES) {
                val ref = s.values[key] as? String ?: continue
                if (ref !in seen) full[ref]?.let { queue.addLast(it) }
            }
        }
        return out
    }

    /**
     * A sender's part of its connection's reading: its outbound streams, by its transceiver's mid, or where libwebrtc
     * names none on them, by its track through their media source; null when they can't be told (the same track in two
     * senders and no mid, or none yet).
     */
    fun forSender(stats: List<MeshEncoders.Stat>, mid: String?, trackId: String?, sendersOfTrack: Int): List<MeshEncoders.Stat>? {
        val full = stats.associateBy { it.id }
        val outbound = stats.filter { it.type == "outbound-rtp" }
        val picked = if (outbound.any { it.values["mid"] is String }) {
            if (mid.isNullOrEmpty()) return null
            outbound.filter { it.values["mid"] == mid }
        } else {
            if (trackId == null || sendersOfTrack != 1) return null
            val sources = stats.filter { it.type == "media-source" && it.values["trackIdentifier"] == trackId }.map { it.id }.toSet()
            outbound.filter { (it.values["mediaSourceId"] as? String) in sources }
        }
        return if (picked.isEmpty()) null else withReferences(full, picked)
    }

    /** A receiver's part: its inbound stream, by its track's id. */
    fun forReceiver(stats: List<MeshEncoders.Stat>, trackId: String): List<MeshEncoders.Stat>? {
        val full = stats.associateBy { it.id }
        val picked = stats.filter { it.type == "inbound-rtp" && it.values["trackIdentifier"] == trackId }
        return if (picked.isEmpty()) null else withReferences(full, picked)
    }
}

/**
 * The room's connections' readings, shared while on a mesh ([MeshStats]): each connection read at most once every
 * [MeshStats.READ_EVERY_MS] however many ask, a reading under way joined by whoever asks meanwhile.
 */
internal class MeshStatsHub {
    private class Reading(val at: Long, val result: CompletableDeferred<List<MeshEncoders.Stat>>)

    private val readings = mutableMapOf<Any, Reading>()

    /** gatherings made, for tests and the lab */
    @Volatile
    var reads = 0
        private set

    /** 1.0.9: how old a reading may be, the settings' `stats.everyMs` ([MeshStats.READ_EVERY_MS] where they say none). */
    @Volatile
    var everyMs = MeshStats.READ_EVERY_MS
        set(value) {
            field = maxOf(500L, value)
        }

    /** A reading of the connection [key] names: the last one while younger than [everyMs] (or under way), else [gather]'s. */
    suspend fun read(
        key: Any,
        now: Long = System.currentTimeMillis(),
        gather: suspend () -> List<MeshEncoders.Stat>,
    ): List<MeshEncoders.Stat> {
        val every = everyMs
        val (reading, mine) = synchronized(readings) {
            val last = readings[key]
            if (last != null && now - last.at < every) {
                last to false
            } else {
                // a connection gone (a full reconnect makes new ones) is forgotten with its reading
                readings.entries.removeAll { now - it.value.at >= every }
                val r = Reading(now, CompletableDeferred())
                readings[key] = r
                reads++
                r to true
            }
        }
        if (mine) {
            try {
                reading.result.complete(gather())
            } catch (e: Throwable) {
                // a failed reading answers those waiting with nothing and isn't kept: the next one asks again
                synchronized(readings) { if (readings[key] === reading) readings.remove(key) }
                reading.result.complete(emptyList())
                if (e is CancellationException) throw e
            }
        }
        return reading.result.await()
    }

    fun clear() {
        synchronized(readings) { readings.clear() }
        reads = 0
    }
}
