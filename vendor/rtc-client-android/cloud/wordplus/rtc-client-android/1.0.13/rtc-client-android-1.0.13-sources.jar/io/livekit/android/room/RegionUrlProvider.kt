/*
 * Copyright 2024-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.os.SystemClock
import androidx.annotation.VisibleForTesting
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.livekit.android.util.LKLog
import io.livekit.android.util.executeAsync
import io.livekit.android.util.rethrowIfCancellationSignal
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import livekit.LivekitRtc
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.util.concurrent.TimeUnit

/**
 * @suppress
 */
class RegionUrlProvider
@AssistedInject
constructor(
    @Assisted val serverUrl: URI,
    @Assisted var token: String,
    private val okHttpClient: OkHttpClient,
    private val json: Json,
) {
    private var regionSettings: RegionSettings? = null
    private var lastUpdateAt: Long = 0L
    private var settingsCacheTimeMs = 30000
    private val attemptedRegions = mutableSetOf<RegionInfo>()

    /**
     * WordPlus Mesh: the list came over the signal connection, which a node sends again whenever the mesh's nodes
     * change, so it isn't fetched.
     */
    @Volatile
    private var signalRegions = false

    /** WordPlus Mesh: nodes that said they are busy, left out of the servers tried next. */
    private val skippedNodes = mutableSetOf<String>()

    fun isLKCloud() = serverUrl.isLKCloud()

    @Throws(RoomException.ConnectException::class)
    suspend fun getNextBestRegionUrl() = coroutineScope {
        if (!isLKCloud()) {
            throw IllegalStateException("Region availability is only supported for LiveKit Cloud domains")
        }
        if (shouldFetch()) {
            fetchRegionSettings()
        }
        val regions = regionSettings?.regions ?: return@coroutineScope null
        val regionsLeft = regions.filter { region ->
            !attemptedRegions.any { attempted -> attempted.url == region.url }
        }

        if (regionsLeft.isEmpty()) {
            return@coroutineScope null
        }

        val nextRegion = regionsLeft.first()
        attemptedRegions.add(nextRegion)
        LKLog.d { "next region: $nextRegion" }
        return@coroutineScope nextRegion.url
    }

    @Throws(RoomException.ConnectException::class)
    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun fetchRegionSettings(): RegionSettings? {
        val request = Request.Builder()
            .url(serverUrl.getCloudConfigUrl("/regions").toString())
            .header("Authorization", "Bearer $token")
            .build()
        // WordPlus Mesh: a fetch that never answers counts as unreachable after a while, not after the client's own.
        val client = if (serverUrl.isMeshServer()) {
            okHttpClient.newBuilder().callTimeout(Mesh.REQUEST_TIMEOUT_MS, TimeUnit.MILLISECONDS).build()
        } else {
            okHttpClient
        }
        val bodyString = try {
            client.newCall(request)
                .executeAsync()
                .use { response ->
                    if (!response.isSuccessful) {
                        throw RoomException.ConnectException("Could not fetch region settings: ${response.code} ${response.message}")
                    }
                    return@use response.body?.string()
                }
        } catch (e: Exception) {
            // WordPlus Mesh: the refresh goes through the shared name, which after a crash may still lead to the dead
            // node: the last list stands rather than none.
            if (e is CancellationException || !serverUrl.isMeshServer() || regionSettings == null) throw e
            LKLog.i { "Region list unreachable, using the last one" }
            return regionSettings
        }

        if (bodyString == null) {
            throw RoomException.ConnectException("Could not fetch region settings: empty response body!")
        }

        return json.decodeFromString<RegionSettings>(bodyString).also {
            regionSettings = it
            lastUpdateAt = SystemClock.elapsedRealtime()
        }
    }

    fun clearAttemptedRegions() {
        attemptedRegions.clear()
        synchronized(skippedNodes) { skippedNodes.clear() }
    }

    fun setServerReportedRegions(regionSettings: RegionSettings) {
        // WordPlus Mesh: a leave's list has no node ids, which the list a node sends over the signal connection has.
        if (signalRegions) return
        this.regionSettings = regionSettings
        this.lastUpdateAt = SystemClock.elapsedRealtime()
    }

    private fun shouldFetch(): Boolean {
        if (signalRegions && regionSettings != null) return false
        return regionSettings == null || SystemClock.elapsedRealtime() - lastUpdateAt > settingsCacheTimeMs
    }

    // WordPlus Mesh

    /** The region list a node sent over the signal connection, taken as it comes and never fetched while it does. */
    fun setSignalRegions(regions: List<RegionInfo>) {
        LKLog.d { "Region list from the server (${regions.size})" }
        regionSettings = RegionSettings(regions)
        lastUpdateAt = SystemClock.elapsedRealtime()
        signalRegions = true
    }

    /** Whether a node sends this server's list over the signal connection. */
    fun hasSignalRegions() = signalRegions

    /** A node that said it is busy, left out of the servers tried next until the attempts are cleared. */
    fun skipNode(node: String) {
        synchronized(skippedNodes) { skippedNodes.add(node) }
    }

    /** The region this client is nearest, the list's first. */
    fun homeRegion(): String? = regionSettings?.regions?.firstOrNull()?.region

    /** A node's own entry in the list, by its id. */
    fun nodeEntry(node: String): RegionInfo? = regionSettings?.regions?.firstOrNull { it.node == node }

    /** The list, fetched if there is none yet; nothing changes if it can't be. */
    suspend fun loadRegions() {
        if (regionSettings != null) return
        try {
            fetchRegionSettings()
        } catch (e: Exception) {
            e.rethrowIfCancellationSignal()
            LKLog.d(e) { "could not fetch region settings" }
        }
    }

    /**
     * The best server not tried yet, leaving out a node (one that said it is busy). [skipUrl] (1.0.1) leaves out the
     * entry at that server's address, the one that just failed; [preferNode] (1.0.1) gives that node's entry first
     * while it is left, the node a session is on. Null when there is none.
     */
    suspend fun next(skipNode: String?, skipUrl: String? = null, preferNode: String? = null): RegionInfo? {
        skipNode?.let { skipNode(it) }
        if (shouldFetch()) {
            try {
                fetchRegionSettings()
            } catch (e: Exception) {
                e.rethrowIfCancellationSignal()
                LKLog.d(e) { "could not fetch region settings" }
            }
        }
        val regions = regionSettings?.regions ?: return null
        val skipped = synchronized(skippedNodes) { skippedNodes.toSet() }
        val left = regions.filter { region ->
            attemptedRegions.none { it.url == region.url } &&
                (region.node == null || region.node !in skipped) &&
                !(skipUrl != null && Mesh.sameServer(region.url, skipUrl))
        }
        val found = preferNode?.let { node -> left.firstOrNull { it.node == node } } ?: left.firstOrNull() ?: return null
        attemptedRegions.add(found)
        return found
    }

    /**
     * WordPlus Mesh (1.0.1, rtc-client 1.0.5): whether a server answers an HTTP request within
     * [Mesh.SERVER_PROBE_TIMEOUT_MS]: its signal URL's origin over HTTP(S). A server that is up answers any request,
     * whatever its status; one that is gone, or out of this client's reach, doesn't.
     */
    suspend fun serverAnswers(url: String): Boolean {
        val origin = Mesh.httpOrigin(url) ?: return false
        val client = okHttpClient.newBuilder()
            .callTimeout(Mesh.SERVER_PROBE_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false)
            .build()
        return try {
            client.newCall(Request.Builder().url(origin).build()).executeAsync().use { true }
        } catch (e: Exception) {
            e.rethrowIfCancellationSignal()
            false
        }
    }

    @AssistedFactory
    interface Factory {
        fun create(serverUrl: URI, token: String): RegionUrlProvider
    }
}

// WordPlus Mesh: a mesh's server counts too, one with others to fail over to, which answers `/settings/regions`.
internal fun URI.isLKCloud() = regionUrlProviderTesting || host != null && (host.endsWith(".livekit.cloud") || host.endsWith(".livekit.run")) || isMeshServer()

internal fun URI.getCloudConfigUrl(appendPath: String = ""): URI {
    val scheme = if (this.scheme.startsWith("ws")) {
        this.scheme.replaceFirst("ws", "http")
    } else {
        this.scheme
    }
    return URI(
        scheme,
        null,
        this.host,
        this.port,
        "/settings$appendPath",
        null,
        null,
    )
}

private var regionUrlProviderTesting = false

@VisibleForTesting
fun setRegionUrlProviderTesting(enable: Boolean) {
    regionUrlProviderTesting = enable
}

/**
 * @suppress
 */
@Serializable
data class RegionSettings(val regions: List<RegionInfo>) {
    companion object {
        fun fromProto(proto: LivekitRtc.RegionSettings): RegionSettings {
            return RegionSettings(
                proto.regionsList.map { region ->
                    RegionInfo(region.region, region.url, region.distance)
                },
            )
        }
    }
}

/**
 * @suppress
 */
@Serializable
data class RegionInfo(
    val region: String,
    val url: String,
    val distance: Long = 0,
    /**
     * WordPlus Mesh: the node this entry leads to, which a mesh's list names and a region of several nodes repeats
     * its region for.
     */
    val node: String? = null,
)
