/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * WordPlus Mesh (1.0.10): the sizes a camera sent as one SVC stream sends for the largest quality its viewers ask for
 * (`camera.svcTrim`, [io.livekit.android.room.track.LocalVideoTrack.setMeshSvcTrim]; better-messages-server
 * infra/SVC-TRIM.md), as the browser client works them out (@wordplus/rtc-client 1.0.24): its first sizes, each a half
 * of the next, the picture scaled down to the largest kept, so each size keeps its height and the node's layers still
 * name it. Of a 720p camera in L3T3_KEY: high sends it whole, medium L2T3_KEY of half the picture, low L1T3 of a quarter.
 */
object MeshSvcTrim {
    /** The mode and scale a camera's one encoding went out with before any trim: the publish's, under the live caps. */
    data class Whole(val mode: String, val scale: Double?)

    /** The mode and scale to send, and how many sizes that is. */
    data class Plan(val mode: String, val scale: Double?, val sizes: Int)

    private val MODE = Regex("^L(\\d)T(\\d)(h|_KEY|_KEY_SHIFT)?$")

    /** A mode's spatial layers; 1 for one this doesn't know. */
    fun spatial(mode: String): Int = MODE.matchEntire(mode)?.groupValues?.get(1)?.toInt() ?: 1

    /** A mode's first [sizes] spatial layers; one size predicts across none, so L1T3 has no suffix. Null for no mode. */
    fun mode(whole: String, sizes: Int): String? {
        val m = MODE.matchEntire(whole) ?: return null
        val spatial = m.groupValues[1].toInt()
        if (sizes >= spatial) return whole
        val temporal = m.groupValues[2]
        return if (sizes == 1) "L1T$temporal" else "L${sizes}T$temporal${m.groupValues[3]}"
    }

    /** What a camera sends for the largest quality asked (low 0, medium 1, high 2). */
    fun plan(whole: Whole, highest: Int): Plan? {
        val m = MODE.matchEntire(whole.mode) ?: return null
        val spatial = m.groupValues[1].toInt()
        val sizes = min(spatial, max(1, highest + 1))
        val mode = mode(whole.mode, sizes)
        if (sizes >= spatial || mode == null) return Plan(whole.mode, whole.scale, spatial)
        val ratio = if (m.groupValues[3] == "h") 1.5 else 2.0
        // the trim's own scale, under a live cap's when that is smaller still (the browser client's order)
        return Plan(mode, max(ratio.pow(spatial - sizes), whole.scale ?: 1.0), sizes)
    }
}
