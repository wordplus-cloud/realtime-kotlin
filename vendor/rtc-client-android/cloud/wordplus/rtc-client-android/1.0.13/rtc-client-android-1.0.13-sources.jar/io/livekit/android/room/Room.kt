/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("unused")

package io.livekit.android.room

import android.content.Context
import android.net.ConnectivityManager.NetworkCallback
import android.net.Network
import androidx.annotation.VisibleForTesting
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.livekit.android.ConnectOptions
import io.livekit.android.LiveKit
import io.livekit.android.LiveKitOverrides
import io.livekit.android.RoomOptions
import io.livekit.android.Version
import io.livekit.android.audio.AudioHandler
import io.livekit.android.audio.AudioProcessingController
import io.livekit.android.audio.AudioRecordPrewarmer
import io.livekit.android.audio.AudioSwitchHandler
import io.livekit.android.audio.AuthedAudioProcessingController
import io.livekit.android.audio.CommunicationWorkaround
import io.livekit.android.audio.startPreconnectAudioJob
import io.livekit.android.dagger.InjectionNames
import io.livekit.android.e2ee.E2EEManager
import io.livekit.android.e2ee.E2EEOptions
import io.livekit.android.events.BroadcastEventBus
import io.livekit.android.events.DisconnectReason
import io.livekit.android.events.ParticipantEvent
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.memory.CloseableManager
import io.livekit.android.renderer.TextureViewRenderer
import io.livekit.android.room.datastream.incoming.IncomingDataStreamManager
import io.livekit.android.room.datatrack.DataTrackSid
import io.livekit.android.room.datatrack.IncomingDataTrackEvent
import io.livekit.android.room.datatrack.IncomingDataTrackManager
import io.livekit.android.room.datatrack.RemoteDataTrack
import io.livekit.android.room.metrics.collectMetrics
import io.livekit.android.room.network.NetworkCallbackManagerFactory
import io.livekit.android.room.network.ReconnectPolicy
import io.livekit.android.room.participant.AudioTrackPublishDefaults
import io.livekit.android.room.participant.ConnectionQuality
import io.livekit.android.room.participant.LocalParticipant
import io.livekit.android.room.participant.Participant
import io.livekit.android.room.participant.ParticipantListener
import io.livekit.android.room.participant.RemoteParticipant
import io.livekit.android.room.participant.RpcHandler
import io.livekit.android.room.participant.VideoTrackPublishDefaults
import io.livekit.android.room.participant.addDataTrack
import io.livekit.android.room.participant.detachDataTracks
import io.livekit.android.room.participant.publishTracksInfo
import io.livekit.android.room.participant.unpublishDataTrack
import io.livekit.android.room.participant.unpublishDataTracks
import io.livekit.android.room.provisions.LKObjects
import io.livekit.android.room.rpc.RPC_REQUEST_DATA_STREAM_TOPIC
import io.livekit.android.room.rpc.RPC_RESPONSE_DATA_STREAM_TOPIC
import io.livekit.android.room.rpc.RpcClientManager
import io.livekit.android.room.rpc.RpcManager
import io.livekit.android.room.rpc.RpcServerManager
import io.livekit.android.room.track.LocalAudioTrack
import io.livekit.android.room.track.LocalAudioTrackOptions
import io.livekit.android.room.track.LocalTrackPublication
import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.room.track.LocalVideoTrackOptions
import io.livekit.android.room.track.RemoteAudioTrack
import io.livekit.android.room.track.RemoteTrackPublication
import io.livekit.android.room.track.RemoteVideoTrack
import io.livekit.android.room.track.Track
import io.livekit.android.room.track.TrackPublication
import io.livekit.android.room.types.toSDKType
import io.livekit.android.room.util.ConnectionWarmer
import io.livekit.android.util.FlowObservable
import io.livekit.android.util.LKLog
import io.livekit.android.util.flow
import io.livekit.android.util.flowDelegate
import io.livekit.android.util.invoke
import io.livekit.android.util.rethrowIfCancellationSignal
import io.livekit.android.webrtc.getFilteredStats
import io.livekit.android.webrtc.getStats
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import livekit.LivekitModels
import livekit.LivekitRtc
import livekit.org.webrtc.EglBase
import livekit.org.webrtc.MediaStream
import livekit.org.webrtc.MediaStreamTrack
import livekit.org.webrtc.RTCStatsCollectorCallback
import livekit.org.webrtc.RendererCommon
import livekit.org.webrtc.RtpReceiver
import livekit.org.webrtc.RtpTransceiver
import livekit.org.webrtc.SurfaceViewRenderer
import livekit.org.webrtc.audio.AudioDeviceModule
import java.net.URI
import java.util.Date
import javax.inject.Named
import kotlin.time.Duration

class Room
@AssistedInject
constructor(
    @Assisted private val context: Context,
    internal val engine: RTCEngine,
    private val eglBase: EglBase,
    localParticipantFactory: LocalParticipant.Factory,
    private val defaultsManager: DefaultsManager,
    @Named(InjectionNames.DISPATCHER_DEFAULT)
    private val defaultDispatcher: CoroutineDispatcher,
    @Named(InjectionNames.DISPATCHER_IO)
    private val ioDispatcher: CoroutineDispatcher,
    /**
     * The [AudioHandler] for setting up the audio as need.
     *
     * By default, this is an instance of [AudioSwitchHandler].
     *
     * This can be substituted for your own custom implementation through
     * [LiveKitOverrides.audioOptions] when creating the room with [LiveKit.create].
     *
     * @see [audioSwitchHandler]
     * @see [AudioSwitchHandler]
     */
    val audioHandler: AudioHandler,
    private val closeableManager: CloseableManager,
    private val e2EEManagerFactory: E2EEManager.Factory,
    private val communicationWorkaround: CommunicationWorkaround,
    val audioProcessingController: AudioProcessingController,
    /**
     * A holder for objects that are used internally within LiveKit.
     */
    val lkObjects: LKObjects,
    networkCallbackManagerFactory: NetworkCallbackManagerFactory,
    private val audioDeviceModule: AudioDeviceModule,
    private val regionUrlProviderFactory: RegionUrlProvider.Factory,
    private val connectionWarmer: ConnectionWarmer,
    private val audioRecordPrewarmer: AudioRecordPrewarmer,
    private val incomingDataStreamManager: IncomingDataStreamManager,
    private val incomingDataTrackManager: IncomingDataTrackManager,
    private val rpcClientManager: RpcClientManager,
    private val rpcServerManager: RpcServerManager,
    private val remoteParticipantFactory: RemoteParticipant.Factory,
) : RTCEngine.Listener, ParticipantListener, RpcManager, IncomingDataStreamManager by incomingDataStreamManager {

    private lateinit var coroutineScope: CoroutineScope
    private val eventBus = BroadcastEventBus<RoomEvent>()
    val events = eventBus.readOnly()

    init {
        engine.listener = this
        // WordPlus Mesh (1.0.9): the round-trip probe keeps its measures in the app's preferences
        MeshProbe.attach(context)

        // Register SDK-internal text-stream handlers for the RPC v2 transport. These reserve
        // the topics `lk.rpc_request` and `lk.rpc_response` from user-level handler registration.
        incomingDataStreamManager.registerTextStreamHandler(RPC_REQUEST_DATA_STREAM_TOPIC) { receiver, fromIdentity ->
            coroutineScope.launch {
                rpcServerManager.handleIncomingDataStream(receiver, fromIdentity)
            }
        }
        incomingDataStreamManager.registerTextStreamHandler(RPC_RESPONSE_DATA_STREAM_TOPIC) { receiver, fromIdentity ->
            coroutineScope.launch {
                rpcClientManager.handleIncomingDataStreamResponse(receiver, fromIdentity)
            }
        }

        // Wire each manager's clientProtocol lookup via the remote-participants store.
        val getRemoteClientProtocol: (Participant.Identity) -> Int = { id ->
            remoteParticipants[id]?.clientProtocol
                ?: ClientProtocolVersion.DEFAULT.value
        }
        rpcClientManager.getRemoteClientProtocol = getRemoteClientProtocol
        rpcServerManager.getRemoteClientProtocol = getRemoteClientProtocol
    }

    enum class State {
        CONNECTING,
        CONNECTED,
        DISCONNECTED,
        RECONNECTING,
    }

    /**
     * @suppress
     */
    enum class SimulateScenario {
        SPEAKER_UPDATE,
        NODE_FAILURE,
        MIGRATION,
        SERVER_LEAVE,
        SERVER_LEAVE_FULL_RECONNECT,
    }

    @Serializable
    @JvmInline
    value class Sid(val sid: String)

    /**
     * The session id of the room.
     *
     * Note: the sid may not be populated immediately upon [connect],
     * so using the suspend function [getSid] or listening to the flow
     * `room::sid.flow` is highly advised.
     */
    @FlowObservable
    @get:FlowObservable
    var sid: Sid? by flowDelegate(null)
        private set

    /**
     * Gets the sid of the room.
     *
     * If the sid is not yet available, will suspend until received.
     */
    suspend fun getSid(): Sid {
        return this@Room::sid.flow
            .filterNotNull()
            .first()
    }

    @FlowObservable
    @get:FlowObservable
    var name: String? by flowDelegate(null)
        private set

    @FlowObservable
    @get:FlowObservable
    var state: State by flowDelegate(State.DISCONNECTED) { new, old ->
        if (new != old) {
            when (new) {
                State.CONNECTING -> {
                    audioHandler.start()
                    communicationWorkaround.start()
                }

                State.DISCONNECTED -> {
                    audioHandler.stop()
                    communicationWorkaround.stop()
                    audioRecordPrewarmer.stop()
                }

                else -> {}
            }
        }
    }
        private set

    @FlowObservable
    @get:FlowObservable
    var metadata: String? by flowDelegate(null)
        private set

    @FlowObservable
    @get:FlowObservable
    var isRecording: Boolean by flowDelegate(false)
        private set

    /**
     * @suppress
     */
    @VisibleForTesting
    var enableMetrics: Boolean = true

    /**
     *  end-to-end encryption manager
     */
    var e2eeManager: E2EEManager? = null

    /**
     * Automatically manage quality of subscribed video tracks, subscribe to the
     * an appropriate resolution based on the size of the video elements that tracks
     * are attached to.
     *
     * Also observes the visibility of attached tracks and pauses receiving data
     * if they are not visible.
     *
     * Defaults to false.
     */
    var adaptiveStream: Boolean = false

    /**
     *  audio processing is enabled
     */
    var audioProcessorIsEnabled: Boolean = false

    /**
     * Dynamically pauses video layers that are not being consumed by any subscribers,
     * significantly reducing publishing CPU and bandwidth usage.
     *
     * Defaults to false.
     *
     * Will be enabled if SVC codecs (i.e. VP9/AV1) are used. Multi-codec simulcast
     * requires dynacast.
     */
    var dynacast: Boolean
        get() = localParticipant.dynacast
        set(value) {
            localParticipant.dynacast = value
        }

    /**
     * Options for end-to-end encryption. Must be setup prior to [connect].
     *
     * If null, e2ee will be disabled.
     */
    var e2eeOptions: E2EEOptions? = null

    /**
     * Default options to use when creating an audio track.
     */
    var audioTrackCaptureDefaults: LocalAudioTrackOptions by defaultsManager::audioTrackCaptureDefaults

    /**
     * Default options to use when publishing an audio track.
     */
    var audioTrackPublishDefaults: AudioTrackPublishDefaults by defaultsManager::audioTrackPublishDefaults

    /**
     * Default options to use when creating a video track.
     */
    var videoTrackCaptureDefaults: LocalVideoTrackOptions by defaultsManager::videoTrackCaptureDefaults

    /**
     * Default options to use when publishing a video track.
     */
    var videoTrackPublishDefaults: VideoTrackPublishDefaults by defaultsManager::videoTrackPublishDefaults

    /**
     * Default options to use when creating a screen share track.
     */
    var screenShareTrackCaptureDefaults: LocalVideoTrackOptions by defaultsManager::screenShareTrackCaptureDefaults

    /**
     * Default options to use when publishing a screen share track.
     */
    var screenShareTrackPublishDefaults: VideoTrackPublishDefaults by defaultsManager::screenShareTrackPublishDefaults

    /**
     * [ReconnectPolicy] to use when reconnecting to the server.
     */
    var reconnectPolicy: ReconnectPolicy by engine::reconnectPolicy

    /**
     * The local participant.
     */
    val localParticipant: LocalParticipant = localParticipantFactory.create(dynacast = false).apply {
        internalListener = this@Room
    }

    private var mutableRemoteParticipants by flowDelegate(emptyMap<Participant.Identity, RemoteParticipant>())

    @FlowObservable
    @get:FlowObservable
    val remoteParticipants: Map<Participant.Identity, RemoteParticipant>
        get() = mutableRemoteParticipants

    /**
     * A convenience getter for the audio handler as a [AudioSwitchHandler].
     *
     * Will return null if [audioHandler] is not a [AudioSwitchHandler].
     */
    val audioSwitchHandler: AudioSwitchHandler?
        get() = audioHandler as? AudioSwitchHandler

    val serverInfo: ServerInfo?
        get() = engine.serverInfo

    /**
     * WordPlus Mesh (1.0.2, rtc-client 1.0.8's `Room.meshCodecPolicy`): the codec policy a mesh node sends with its join
     * response (WordPlus Mesh 1.0.33's `mesh.codec_policy`), lists of codec names and a backup's name only, for the
     * product's codec rule to take as a preference. Null from a node that sends none, and from any other server.
     */
    var meshCodecPolicy: MeshCodecPolicy? = null
        private set

    /**
     * WordPlus Mesh (1.0.9): the settings the node sent this client last ([MeshSettings]: each checked, every key's
     * default where the node set none), [MeshSettings.NONE] before any and from any other server. Each change comes as
     * [RoomEvent.MeshSettingsChanged] too, with the keys whose value changed; the room holds its own cameras to the live
     * caps itself ([MeshCaps]). For the settings a connect takes before it reaches a node, [MeshSettings.cached].
     */
    var meshSettings: MeshSettings = MeshSettings.NONE
        private set

    /**
     * WordPlus Mesh (1.0.12): the sids of the tracks this room subscribes to that have stopped reaching their node, as the
     * node last said, each change as [RoomEvent.MeshSourcesDryChanged] too. The node decides it, from what arrives of each
     * track, so it says nothing of this client's own connection. Forgotten while a connection is being restored, as the
     * node says its list again on the one restored and a new session starts with none. From any other server, always empty.
     */
    @Volatile
    var meshSourcesDry: Set<String> = emptySet()
        private set

    /** WordPlus Mesh (1.0.9): the URL the product connected with, whose settings are kept for its next connect. */
    private var meshProvidedUrl: String? = null

    /** WordPlus Mesh (1.0.9): the product's own caps over its cameras ([setProductCameraCaps]), beside the server's. */
    @Volatile
    private var productCameraCaps = MeshCaps()

    /** WordPlus Mesh (1.0.9): the caps the room holds its cameras to: its settings' live caps and the product's own, the
     * stricter of each. */
    val cameraCaps: MeshCaps get() = meshSettings.cameraCaps.combined(productCameraCaps)

    /**
     * WordPlus Mesh (1.0.9): the product's own caps over its cameras, beside the settings' ([cameraCaps]), on the
     * running senders at once: a product holding a camera it encodes in software to the settings'
     * `camera.maxHeight.sw`, say. Empty: none of the product's.
     */
    fun setProductCameraCaps(caps: MeshCaps) {
        val before = cameraCaps
        productCameraCaps = caps
        if (cameraCaps != before) localParticipant.applyMeshCaps(cameraCaps)
    }

    /** WordPlus Mesh (1.0.2): the room's server is a mesh's, which takes its published videos' encoders. */
    private var onMesh = false

    /** WordPlus Mesh (1.0.2): the published videos' encoders, told to a mesh node while connected. */
    private val meshEncoders = MeshEncoderReporter(
        connected = { state == State.CONNECTED },
        videos = {
            localParticipant.trackPublications.values.mapNotNull { pub ->
                (pub.track as? LocalVideoTrack)?.let { track -> pub.sid to track }
            }
        },
        statsOf = { sender -> engine.createStatsGetter(sender).getStats() },
        // what the room receives, as it plays (1.0.5, MeshReceivers)
        received = {
            remoteParticipants.values.flatMap { it.trackPublications.values }.mapNotNull { pub ->
                when (val track = pub.track) {
                    is RemoteVideoTrack -> Triple(pub.sid, true, track.receiver)
                    is RemoteAudioTrack -> Triple(pub.sid, false, track.receiver)
                    else -> null
                }
            }
        },
        receiverStatsOf = { receiver -> engine.createStatsGetter(receiver).getStats() },
        // 1.0.6: the connections' shared readings, one request a reading, the device and the app
        connections = { engine.meshConnections() },
        connectionStats = { connection -> engine.meshConnectionStats(connection).getStats() },
        senderInfo = { sender -> engine.meshSenderInfo(sender, meshHeldTransceivers()) },
        sendReports = { encoders, receivers, health -> engine.client.sendMeshReports(encoders, receivers, health) },
        health = MeshHealthWatch(context),
        // 1.0.7: a gap this device made itself by turning a video off isn't the call's (MeshTurns)
        turnedOnAt = { sid ->
            remoteParticipants.values.firstNotNullOfOrNull { (it.trackPublications[sid] as? RemoteTrackPublication)?.meshTurns?.onAt }
        },
        // 1.0.9: the settings revision it runs, so the node's live view says how far a revision has reached
        settingsRev = { meshSettings.takeIf { it !== MeshSettings.NONE }?.rev },
    )

    /** WordPlus Mesh (1.0.5): the published camera's hardware encoder, watched for dropping its frames while connected. */
    private val meshHardwareDrops = MeshHardwareDropWatch(
        context = context,
        camera = {
            localParticipant.trackPublications.values.firstNotNullOfOrNull { pub ->
                (pub.track as? LocalVideoTrack)?.takeIf { pub.source == Track.Source.CAMERA }?.let { it to pub.muted }
            }
        },
        pathUp = { engine.publisher?.isConnected() ?: false },
        statsOf = { sender -> engine.createStatsGetter(sender).getStats() },
        // 1.0.6: its part of the publisher's shared reading, with the reports
        sharedStatsOf = { sender ->
            engine.meshConnections().first?.let { publisher ->
                val (mid, count) = engine.meshSenderInfo(sender, meshHeldTransceivers())
                val reading = meshEncoders.stats.read(publisher) {
                    MeshEncoders.stats(engine.meshConnectionStats(publisher).getStats())
                }
                MeshStats.forSender(reading, mid, sender.track()?.id(), count)
            }
        },
        // 1.0.9: the rule's numbers from the room's settings
        settings = { meshSettings },
    )

    /**
     * WordPlus Mesh (1.0.6): the transceivers the local tracks hold, each published track's own and its backup codecs',
     * where [RTCEngine.meshSenderInfo] finds a sender's mid without reading the connection's lists, which would dispose
     * them.
     */
    private fun meshHeldTransceivers(): List<RtpTransceiver> =
        localParticipant.trackPublications.values.flatMap { pub ->
            when (val track = pub.track) {
                is LocalVideoTrack -> listOfNotNull(track.transceiver) + track.simulcastTransceivers
                is LocalAudioTrack -> listOfNotNull(track.transceiver)
                else -> emptyList()
            }
        }

    private val sidToIdentity = mutableMapOf<Participant.Sid, Participant.Identity>()

    private var mutableActiveSpeakers by flowDelegate(emptyList<Participant>())

    @FlowObservable
    @get:FlowObservable
    val activeSpeakers: List<Participant>
        get() = mutableActiveSpeakers

    @Volatile
    private var hasLostConnectivity: Boolean = false
    private var connectOptions: ConnectOptions = ConnectOptions()

    private var stateLock = Mutex()

    private var regionUrlProvider: RegionUrlProvider? = null
    private var regionUrl: String? = null

    /** WordPlus Mesh: a join is walking the mesh's servers ([connectWithMeshWalk]). */
    @Volatile
    private var meshWalking = false

    private val transcriptionReceivedTimes = mutableMapOf<String, Long>()

    internal var isPrerecording by defaultsManager::isPrerecording

    private fun getCurrentRoomOptions(): RoomOptions =
        RoomOptions(
            adaptiveStream = adaptiveStream,
            dynacast = dynacast,
            e2eeOptions = e2eeOptions,
            audioTrackCaptureDefaults = audioTrackCaptureDefaults,
            videoTrackCaptureDefaults = videoTrackCaptureDefaults,
            audioTrackPublishDefaults = audioTrackPublishDefaults,
            videoTrackPublishDefaults = videoTrackPublishDefaults,
            screenShareTrackCaptureDefaults = screenShareTrackCaptureDefaults,
            screenShareTrackPublishDefaults = screenShareTrackPublishDefaults,
        )

    /**
     * prepareConnection should be called as soon as the page is loaded, in order
     * to speed up the connection attempt. This function will
     * - perform DNS resolution and pre-warm the DNS cache
     * - establish TLS connection and cache TLS keys
     *
     * With LiveKit Cloud, it will also determine the best edge data center for
     * the current client to connect to if a token is provided.
     */
    suspend fun prepareConnection(url: String, token: String? = null) {
        if (state != State.DISCONNECTED) {
            LKLog.i { "Room is not in disconnected state, ignoring prepareConnection call." }
            return
        }
        LKLog.d { "preparing connection to $url" }

        try {
            val urlActual = URI(url)
            // WordPlus Mesh: not on a mesh, whose node sends its list over the signal connection once the client is in.
            if (urlActual.isLKCloud() && !urlActual.isMeshServer() && token != null) {
                val regionUrlProvider = regionUrlProviderFactory.create(urlActual, token)
                this.regionUrlProvider = regionUrlProvider

                val regionUrl = regionUrlProvider.getNextBestRegionUrl()
                // we will not replace the regionUrl if an attempt had already started
                // to avoid overriding regionUrl after a new connection attempt had started
                if (regionUrl != null && state == State.DISCONNECTED) {
                    this.regionUrl = regionUrl
                    connectionWarmer.fetch(regionUrl)
                    LKLog.d { "prepared connection to $regionUrl" }
                }
            } else {
                connectionWarmer.fetch(url)
            }
        } catch (e: Exception) {
            e.rethrowIfCancellationSignal()
            LKLog.e(e) { "Error while preparing connection:" }
        }
    }

    /**
     * Connect to a LiveKit Room.
     *
     * @param url
     * @param token
     * @param options
     *
     * @throws IllegalStateException when connect is attempted while the room is not disconnected.
     * @throws Exception when connection fails
     */
    @Throws(Exception::class)
    suspend fun connect(url: String, token: String, options: ConnectOptions = ConnectOptions()) = coroutineScope {
        if (state != State.DISCONNECTED) {
            throw IllegalStateException("Room.connect attempted while room is not disconnected!")
        }
        // WordPlus Mesh (1.0.9): the server whose settings are kept for the next connect, as the product names it; the
        // settings themselves come with the join
        meshProvidedUrl = url
        meshSettings = MeshSettings.NONE
        localParticipant.meshSettings = MeshSettings.NONE
        val roomOptions: RoomOptions
        stateLock.withLock {
            if (state != State.DISCONNECTED) {
                throw IllegalStateException("Room.connect attempted while room is not disconnected!")
            }
            if (::coroutineScope.isInitialized) {
                val job = coroutineScope.coroutineContext.job
                coroutineScope.cancel()
                job.join()
            }

            state = State.CONNECTING
            connectOptions = options
            onMesh = isMeshServer(url)

            coroutineScope = CoroutineScope(defaultDispatcher + SupervisorJob())

            roomOptions = getCurrentRoomOptions()

            // Setup local participant.
            localParticipant.reinitialize(options)
            setupLocalParticipantEventHandling()
            setupIncomingDataTrackEventHandling()

            if (roomOptions.e2eeOptions != null) {
                e2eeManager = e2EEManagerFactory.create(roomOptions.e2eeOptions.keyProvider).apply {
                    setup(this@Room) { event ->
                        coroutineScope.launch {
                            emitWhenConnected(event)
                        }
                    }
                }
                engine.e2EEManager = e2eeManager
            }
        }

        // Use an empty coroutineExceptionHandler since we want to
        // rethrow all throwables from the connect job.
        val emptyCoroutineExceptionHandler = CoroutineExceptionHandler { _, _ -> }
        val connectJob = coroutineScope.launch(
            ioDispatcher + emptyCoroutineExceptionHandler,
        ) {
            if (audioProcessingController is AuthedAudioProcessingController) {
                audioProcessingController.authenticate(url, token)
            }

            // Don't use URL equals.
            if (regionUrlProvider?.serverUrl.toString() != url) {
                regionUrl = null
                regionUrlProvider = null
            }

            val urlObj = URI(url)
            if (urlObj.isLKCloud()) {
                if (regionUrlProvider == null) {
                    regionUrlProvider = regionUrlProviderFactory.create(urlObj, token)
                } else {
                    regionUrlProvider?.token = token
                }

                // trigger the first fetch without waiting for a response
                // if initial connection fails, this will speed up picking regional url
                // on subsequent runs
                // WordPlus Mesh: not on a mesh, whose node sends its list over the signal connection once the client
                // is in (`fetchMeshRegionsLate` for one that doesn't).
                if (!urlObj.isMeshServer()) {
                    launch {
                        try {
                            regionUrlProvider?.fetchRegionSettings()
                        } catch (e: Exception) {
                            e.rethrowIfCancellationSignal()
                            LKLog.w(e) { "could not fetch region settings" }
                        }
                    }
                }
            }

            var nextUrl: String? = regionUrl ?: url
            regionUrl = null

            // Attempted regions are scoped to this failover cycle, since the provider is reused
            // across connects. Captured locally as prepareConnection can replace the field.
            val cycleRegionUrlProvider = regionUrlProvider

            val meshProvider = cycleRegionUrlProvider?.takeIf { urlObj.isMeshServer() }
            if (meshProvider != null) {
                // WordPlus Mesh: a failed try of the walk isn't the join's failure, which comes once, when it gives up.
                meshWalking = true
                try {
                    connectWithMeshWalk(meshProvider, url, token, options, roomOptions)
                } catch (e: Exception) {
                    meshWalking = false
                    e.rethrowIfCancellationSignal()
                    eventBus.tryPostEvent(RoomEvent.FailedToConnect(this@Room, e))
                    throw e
                } finally {
                    meshWalking = false
                    // the walk's tries are this cycle's too (2.29's scoping, above)
                    meshProvider.clearAttemptedRegions()
                }
                fetchMeshRegionsLate(meshProvider)
                nextUrl = null
            }

            try {
                while (nextUrl != null) {
                    val connectUrl = nextUrl
                    nextUrl = null
                    try {
                        engine.regionUrlProvider = cycleRegionUrlProvider
                        engine.join(connectUrl, token, options, roomOptions)
                    } catch (e: Exception) {
                        e.rethrowIfCancellationSignal()

                        nextUrl = cycleRegionUrlProvider?.getNextBestRegionUrl()
                        if (nextUrl != null) {
                            LKLog.d(e) { "Connection to $connectUrl failed, retrying with another region: $nextUrl" }
                        } else {
                            throw e // rethrow since no more regions to try.
                        }
                    }
                }
            } finally {
                cycleRegionUrlProvider?.clearAttemptedRegions()
            }

            ensureActive()
            networkCallbackManager.registerCallback()
            if (options.audio) {
                var cancelPreconnect: (() -> Unit)? = null

                if (audioTrackPublishDefaults.preconnect) {
                    cancelPreconnect = startPreconnectAudioJob(roomScope = coroutineScope)
                }
                // Enable through setMicrophoneEnabled rather than publishing directly,
                // so that this serializes with any concurrent enable calls from the app
                // once the room state flips to CONNECTED.
                if (!localParticipant.setMicrophoneEnabled(true)) {
                    cancelPreconnect?.invoke()
                }
            }
            ensureActive()
            if (options.video) {
                localParticipant.setCameraEnabled(true)
            }

            coroutineScope.launch {
                if (enableMetrics) {
                    collectMetrics(room = this@Room, rtcEngine = engine)
                }
            }
        }

        val outerHandler = coroutineContext.job.invokeOnCompletion { cause ->
            // Cancel connect job if invoking coroutine is cancelled.
            if (cause is CancellationException) {
                connectJob.cancel(cause)
            }
        }

        var error: Throwable? = null
        connectJob.invokeOnCompletion { cause ->
            outerHandler.dispose()
            error = cause
        }
        connectJob.join()

        error?.let {
            if (it !is CancellationException) {
                handleDisconnect(DisconnectReason.JOIN_FAILURE)
            }
            throw it
        }
    }

    /**
     * WordPlus Mesh: a join on a mesh keeps trying until [ConnectOptions.meshJoinBudgetMs], as @wordplus/rtc-client's:
     * - a node `busy` (past its entry rate or its CPU) is left out and the list's next server tried at once, its home
     *   region's other nodes first; with every server busy, the join goes back to the home region's node that frees
     *   first and waits there (`mesh_wait=1`), which keeps it a slot of its own;
     * - a `slot` held for it, or a `full` cluster (a slot held), is come back to by that node's own name when its
     *   Retry-After says;
     * - a server that can't be reached is left for the list's next, and once every one has failed the join starts
     *   over from the best after 1 to 3 s.
     * A refusal of the token (401, 403) or a cancel ends it at once. [ConnectOptions.onMeshWait] hears each wait.
     */
    private suspend fun connectWithMeshWalk(
        provider: RegionUrlProvider,
        url: String,
        token: String,
        options: ConnectOptions,
        roomOptions: RoomOptions,
    ) {
        class Busy(val url: String, val region: String?, val freeAt: Long)

        val deadline = System.currentTimeMillis() + options.meshJoinBudgetMs
        val busy = mutableListOf<Busy>()
        var nextUrl = url

        while (true) {
            try {
                engine.regionUrlProvider = provider
                engine.join(nextUrl, token, options, roomOptions)
                return
            } catch (e: Exception) {
                e.rethrowIfCancellationSignal()
                currentCoroutineContext().ensureActive()

                val tried = nextUrl
                val refusal = e.meshRefusal()
                val now = System.currentTimeMillis()

                if (refusal?.kind == "busy" && !Mesh.isMeshWait(tried) && now < deadline) {
                    refusal.node?.let { provider.skipNode(it) }

                    val next = provider.next(skipNode = null)
                    val entry = refusal.node?.let { provider.nodeEntry(it) }
                    val home = provider.homeRegion()

                    busy.add(Busy(entry?.url ?: tried, entry?.region ?: home, now + (refusal.retryAfterMs ?: 1_000L)))

                    if (next != null) {
                        LKLog.i { "Server busy, trying ${next.url}" }
                        nextUrl = next.url
                        continue
                    }

                    val waitOn = Mesh.waitOn(busy, home, { it.region }, { it.freeAt }) ?: throw e

                    LKLog.i { "Every server busy, waiting for a slot on ${waitOn.url}" }
                    options.onMeshWait?.invoke(MeshWait(waitOn.freeAt, MeshWaitReason.BUSY))
                    nextUrl = Mesh.withMeshWait(waitOn.url)
                    continue
                }

                // Another server, unless the mesh said none has room or the token was refused.
                if (refusal == null && !Mesh.isRefusedToken(e)) {
                    val next = provider.next(skipNode = null)
                    if (next != null) {
                        LKLog.i { "Connect to $tried failed, trying ${next.url}" }
                        nextUrl = next.url
                        continue
                    }
                }

                val retryIn = Mesh.joinRetryMs(e, deadline) ?: throw e
                val reason = MeshWaitReason.fromWire(refusal?.kind) ?: MeshWaitReason.UNREACHABLE

                LKLog.i { "Connect failed (${e.message}), trying again in $retryIn ms" }
                options.onMeshWait?.invoke(MeshWait(System.currentTimeMillis() + retryIn, reason))

                delay(retryIn)

                nextUrl = if (refusal?.kind == "slot" || refusal?.kind == "full") {
                    provider.loadRegions()
                    val entry = refusal.node?.let { provider.nodeEntry(it) }
                    Mesh.withMeshWait(entry?.url ?: tried)
                } else {
                    url
                }

                provider.clearAttemptedRegions()
                busy.clear()
            }
        }
    }

    /**
     * WordPlus Mesh: the region list fetched once a join is in, if its node hasn't sent it over the signal connection
     * within `Mesh.REGIONS_WAIT_MS`: an older node, which doesn't. A failover then has a list to go on.
     */
    private fun fetchMeshRegionsLate(provider: RegionUrlProvider) {
        coroutineScope.launch(ioDispatcher) {
            delay(Mesh.REGIONS_WAIT_MS)
            if (state != State.CONNECTED || regionUrlProvider !== provider || provider.hasSignalRegions()) {
                return@launch
            }
            LKLog.d { "No region list from the server, fetching it" }
            provider.loadRegions()
        }
    }

    /**
     * Disconnect from the room.
     */
    fun disconnect() {
        if (state == State.DISCONNECTED) {
            return
        }
        engine.client.sendLeave()
        handleDisconnect(DisconnectReason.CLIENT_INITIATED)
    }

    /**
     * Copies all the options to the Room object.
     *
     * Any null values in [options] will not overwrite existing values.
     * To clear existing values on the Room object, explicitly set the value
     * directly instead of using this method.
     */
    fun setRoomOptions(options: RoomOptions) {
        options.audioTrackCaptureDefaults?.let {
            audioTrackCaptureDefaults = it
        }
        options.videoTrackCaptureDefaults?.let {
            videoTrackCaptureDefaults = it
        }

        options.audioTrackPublishDefaults?.let {
            audioTrackPublishDefaults = it
        }
        options.videoTrackPublishDefaults?.let {
            videoTrackPublishDefaults = it
        }
        options.screenShareTrackCaptureDefaults?.let {
            screenShareTrackCaptureDefaults = it
        }
        options.screenShareTrackPublishDefaults?.let {
            screenShareTrackPublishDefaults = it
        }
        options.reconnectPolicy?.let {
            reconnectPolicy = it
        }
        adaptiveStream = options.adaptiveStream
        dynacast = options.dynacast
        e2eeOptions = options.e2eeOptions
    }

    /**
     * Release all resources held by this object.
     *
     * Once called, this room object must not be used to connect to a server and a new one
     * must be created.
     */
    fun release() {
        disconnect()
        closeableManager.close()
    }

    /**
     * @suppress
     */
    override fun onJoinResponse(response: LivekitRtc.JoinResponse) {
        LKLog.i { "Connected to server, server version: ${response.serverVersion}, client version: ${Version.CLIENT_VERSION}" }

        if (response.room.sid != null) {
            sid = Sid(response.room.sid)
        } else {
            sid = null
        }
        name = response.room.name
        metadata = response.room.metadata
        // WordPlus Mesh (1.0.2): the node's codec policy, in a field LiveKit's JoinResponse hasn't got, which the
        // message keeps among its unknown fields and writes out again
        meshCodecPolicy = Mesh.codecPolicy(response.toByteArray())
        // WordPlus Mesh (1.0.9): the client's settings, in field 1002 of the join response
        Mesh.settingsInJoinResponse(response.toByteArray())?.let { takeMeshSettings(it) }

        if (e2eeManager != null && !response.sifTrailer.isEmpty) {
            e2eeManager!!.keyProvider().setSifTrailer(response.sifTrailer.toByteArray())
        }

        if (response.room.activeRecording != isRecording) {
            isRecording = response.room.activeRecording
            eventBus.postEvent(RoomEvent.RecordingStatusChanged(this, isRecording), coroutineScope)
        }

        if (!response.hasParticipant()) {
            throw RoomException.ConnectException("server didn't return a local participant")
        }

        localParticipant.updateFromInfo(response.participant)
        localParticipant.setEnabledPublishCodecs(response.enabledPublishCodecsList)

        if (response.otherParticipantsList.isNotEmpty()) {
            response.otherParticipantsList.forEach { info ->
                getOrCreateRemoteParticipant(Participant.Identity(info.identity), info)
            }
        }
    }

    private fun setupLocalParticipantEventHandling() {
        coroutineScope.launch {
            localParticipant.events.collect {
                when (it) {
                    is ParticipantEvent.TrackPublished -> {
                        // WordPlus Mesh (1.0.2): a new video's encoders are told once they run, not at the next reading
                        if (it.publication.track is LocalVideoTrack) {
                            meshEncoders.reportSoon(coroutineScope)
                        }
                        // WordPlus Mesh (1.0.9): the hardware-drop watch, ended after a while without a camera, watches this one
                        if (it.publication.source == Track.Source.CAMERA && state == State.CONNECTED) {
                            meshHardwareDrops.start()
                        }
                        emitWhenConnected(
                            RoomEvent.TrackPublished(
                                room = this@Room,
                                publication = it.publication,
                                participant = it.participant,
                            ),
                        )
                    }

                    is ParticipantEvent.LocalTrackPublicationFailed -> emitWhenConnected(
                        RoomEvent.TrackPublicationFailed(
                            room = this@Room,
                            track = it.track,
                            participant = it.participant,
                            e = it.e,
                        ),
                    )

                    is ParticipantEvent.TrackUnpublished -> emitWhenConnected(
                        RoomEvent.TrackUnpublished(
                            room = this@Room,
                            publication = it.publication,
                            participant = it.participant,
                        ),
                    )

                    is ParticipantEvent.ParticipantPermissionsChanged -> emitWhenConnected(
                        RoomEvent.ParticipantPermissionsChanged(
                            room = this@Room,
                            participant = it.participant,
                            newPermissions = it.newPermissions,
                            oldPermissions = it.oldPermissions,
                        ),
                    )

                    is ParticipantEvent.MetadataChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantMetadataChanged(
                                this@Room,
                                it.participant,
                                it.prevMetadata,
                            ),
                        )
                    }

                    is ParticipantEvent.AttributesChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantAttributesChanged(
                                this@Room,
                                it.participant,
                                it.changedAttributes,
                                it.oldAttributes,
                            ),
                        )
                    }

                    is ParticipantEvent.NameChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantNameChanged(
                                this@Room,
                                it.participant,
                                it.name,
                            ),
                        )
                    }

                    is ParticipantEvent.StateChanged -> {
                        RoomEvent.ParticipantStateChanged(
                            this@Room,
                            it.participant,
                            it.newState,
                            it.oldState,
                        )
                    }

                    else -> {
                        // do nothing
                    }
                }
            }
        }
    }

    private fun setupIncomingDataTrackEventHandling() {
        coroutineScope.launch {
            incomingDataTrackManager.events.collect { event ->
                when (event) {
                    is IncomingDataTrackEvent.TrackPublished -> attachRemoteDataTrack(event.track)
                    is IncomingDataTrackEvent.TrackUnpublished -> unpublishRemoteDataTrack(event.sid, event.track)
                }
            }
        }
    }

    private fun attachRemoteDataTrack(track: RemoteDataTrack) {
        val participant = remoteParticipants[track.publisherIdentity]
        if (participant == null) {
            LKLog.d { "Data track published by not-yet-known participant ${track.publisherIdentity}" }
            return
        }
        participant.addDataTrack(track)
    }

    private fun unpublishRemoteDataTrack(sid: DataTrackSid, track: RemoteDataTrack) {
        val participant = remoteParticipants[track.publisherIdentity] ?: return
        participant.unpublishDataTrack(sid)
        eventBus.postEvent(RoomEvent.DataTrackUnpublished(this, participant, sid), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun reattachRemoteDataTracks() {
        for (track in incomingDataTrackManager.snapshotRemoteTracks()) {
            attachRemoteDataTrack(track)
        }
    }

    private fun handleParticipantDisconnect(identity: Participant.Identity) {
        val newParticipants = mutableRemoteParticipants.toMutableMap()
        val removedParticipant = newParticipants.remove(identity) ?: return
        val unpublishedDataSids = removedParticipant.unpublishDataTracks()
        removedParticipant.trackPublications.values.toList().forEach { publication ->
            removedParticipant.unpublishTrack(publication.sid, true)
        }

        mutableRemoteParticipants = newParticipants
        for (sid in unpublishedDataSids) {
            eventBus.postEvent(RoomEvent.DataTrackUnpublished(this, removedParticipant, sid), coroutineScope)
        }
        eventBus.postEvent(RoomEvent.ParticipantDisconnected(this, removedParticipant), coroutineScope)

        localParticipant.handleParticipantDisconnect(identity)
    }

    fun getParticipantBySid(sid: String): Participant? {
        return getParticipantBySid(Participant.Sid(sid))
    }

    fun getParticipantBySid(sid: Participant.Sid): Participant? {
        if (sid == localParticipant.sid) {
            return localParticipant
        } else {
            return remoteParticipants[sidToIdentity[sid]]
        }
    }

    fun getParticipantByIdentity(identity: String): Participant? {
        return getParticipantByIdentity(Participant.Identity(identity))
    }

    fun getParticipantByIdentity(identity: Participant.Identity): Participant? {
        if (identity == localParticipant.identity) {
            return localParticipant
        } else {
            return remoteParticipants[identity]
        }
    }

    @Synchronized
    private fun getOrCreateRemoteParticipant(
        identity: Participant.Identity,
        info: LivekitModels.ParticipantInfo,
    ): RemoteParticipant {
        var participant = remoteParticipants[identity]
        if (participant != null) {
            return participant
        }

        participant = remoteParticipantFactory.create(info)
        participant.internalListener = this

        coroutineScope.launch {
            participant.events.collect {
                when (it) {
                    is ParticipantEvent.TrackPublished -> {
                        if (state == State.CONNECTED) {
                            eventBus.postEvent(
                                RoomEvent.TrackPublished(
                                    room = this@Room,
                                    publication = it.publication,
                                    participant = it.participant,
                                ),
                            )
                        }
                    }

                    is ParticipantEvent.DataTrackPublished -> eventBus.postEvent(
                        RoomEvent.DataTrackPublished(
                            room = this@Room,
                            participant = it.participant,
                            track = it.track,
                        ),
                    )

                    is ParticipantEvent.TrackStreamStateChanged -> eventBus.postEvent(
                        RoomEvent.TrackStreamStateChanged(
                            this@Room,
                            it.trackPublication,
                            it.streamState,
                        ),
                    )

                    is ParticipantEvent.TrackSubscriptionPermissionChanged -> eventBus.postEvent(
                        RoomEvent.TrackSubscriptionPermissionChanged(
                            this@Room,
                            it.participant,
                            it.trackPublication,
                            it.subscriptionAllowed,
                        ),
                    )

                    is ParticipantEvent.MetadataChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantMetadataChanged(
                                this@Room,
                                it.participant,
                                it.prevMetadata,
                            ),
                        )
                    }

                    is ParticipantEvent.AttributesChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantAttributesChanged(
                                this@Room,
                                it.participant,
                                it.changedAttributes,
                                it.oldAttributes,
                            ),
                        )
                    }

                    is ParticipantEvent.NameChanged -> {
                        emitWhenConnected(
                            RoomEvent.ParticipantNameChanged(
                                this@Room,
                                it.participant,
                                it.name,
                            ),
                        )
                    }

                    is ParticipantEvent.ParticipantPermissionsChanged -> eventBus.postEvent(
                        RoomEvent.ParticipantPermissionsChanged(
                            room = this@Room,
                            participant = it.participant,
                            newPermissions = it.newPermissions,
                            oldPermissions = it.oldPermissions,
                        ),
                    )

                    is ParticipantEvent.StateChanged -> {
                        eventBus.postEvent(
                            RoomEvent.ParticipantStateChanged(
                                room = this@Room,
                                participant = it.participant,
                                newState = it.newState,
                                oldState = it.oldState,
                            ),
                        )
                    }

                    else -> {
                        // do nothing
                    }
                }
            }
        }

        participant.updateFromInfo(info)

        val newRemoteParticipants = mutableRemoteParticipants.toMutableMap()
        newRemoteParticipants[identity] = participant
        mutableRemoteParticipants = newRemoteParticipants
        sidToIdentity[participant.sid] = identity

        return participant
    }

    private fun handleActiveSpeakersUpdate(speakerInfos: List<LivekitModels.SpeakerInfo>) {
        val speakers = mutableListOf<Participant>()
        val seenSids = mutableSetOf<Participant.Sid>()
        val localParticipant = localParticipant
        speakerInfos.forEach { speakerInfo ->
            val speakerSid = Participant.Sid(speakerInfo.sid)
            seenSids.add(speakerSid)

            val participant = getParticipantBySid(speakerSid) ?: return@forEach
            participant.audioLevel = speakerInfo.level
            participant.isSpeaking = true
            speakers.add(participant)
        }

        if (!seenSids.contains(localParticipant.sid)) {
            localParticipant.audioLevel = 0.0f
            localParticipant.isSpeaking = false
        }
        remoteParticipants.values
            .filterNot { seenSids.contains(it.sid) }
            .forEach {
                it.audioLevel = 0.0f
                it.isSpeaking = false
            }

        mutableActiveSpeakers = speakers.toList()
        eventBus.postEvent(RoomEvent.ActiveSpeakersChanged(this, mutableActiveSpeakers), coroutineScope)
    }

    private fun handleSpeakersChanged(speakerInfos: List<LivekitModels.SpeakerInfo>) {
        val updatedSpeakers = mutableMapOf<Participant.Sid, Participant>()
        activeSpeakers.forEach { participant ->
            updatedSpeakers[participant.sid] = participant
        }

        speakerInfos.forEach { speaker ->
            val speakerSid = Participant.Sid(speaker.sid)
            val participant = getParticipantBySid(speakerSid) ?: return@forEach

            participant.audioLevel = speaker.level
            participant.isSpeaking = speaker.active

            if (speaker.active) {
                updatedSpeakers[speakerSid] = participant
            } else {
                updatedSpeakers.remove(speakerSid)
            }
        }

        val updatedSpeakersList = updatedSpeakers.values.toList()
            .sortedBy { it.audioLevel }

        mutableActiveSpeakers = updatedSpeakersList.toList()
        eventBus.postEvent(RoomEvent.ActiveSpeakersChanged(this, mutableActiveSpeakers), coroutineScope)
    }

    private fun reconnect() {
        if (state == State.RECONNECTING) {
            return
        }
        engine.reconnect()
    }

    private fun handleDisconnect(reason: DisconnectReason) {
        if (state == State.DISCONNECTED) {
            return
        }
        runBlocking {
            stateLock.withLock {
                if (state == State.DISCONNECTED) {
                    return@runBlocking
                }
                networkCallbackManager.unregisterCallback()
                hasLostConnectivity = false
                meshEncoders.stop()
                meshHardwareDrops.stop()

                state = State.DISCONNECTED
                cleanupRoom()
                engine.close()

                localParticipant.dispose()

                // Ensure all observers see the disconnected before closing scope.
                eventBus.postEvent(RoomEvent.Disconnected(this@Room, null, reason), coroutineScope).join()
                coroutineScope.cancel()
            }
        }
    }

    /**
     * Removes all participants and tracks from the room.
     */
    private fun cleanupRoom() {
        takeMeshSourcesDry(emptySet())
        e2eeManager?.dispose()
        e2eeManager = null
        localParticipant.cleanup()
        remoteParticipants.keys.toMutableSet() // copy keys to avoid concurrent modifications.
            .forEach { sid -> handleParticipantDisconnect(sid) }

        sid = null
        metadata = null
        name = null
        isRecording = false
        sidToIdentity.clear()
        incomingDataStreamManager.clearOpenStreams()
    }

    private suspend fun sendSyncState() {
        // Whether we're sending subscribed tracks or tracks to unsubscribe.
        val sendUnsub = connectOptions.autoSubscribe
        val participantTracksList = mutableListOf<LivekitModels.ParticipantTracks>()
        for (participant in remoteParticipants.values) {
            val builder = LivekitModels.ParticipantTracks.newBuilder()
            builder.participantSid = participant.sid.value
            for (trackPub in participant.trackPublications.values) {
                val remoteTrackPub = (trackPub as? RemoteTrackPublication) ?: continue

                // Use isDesired (subscription intent) instead of isSubscribed (actual state)
                // to avoid race condition during quick reconnect where tracks aren't attached yet.
                if (remoteTrackPub.isDesired != sendUnsub) {
                    builder.addTrackSids(remoteTrackPub.sid)
                }
            }

            if (builder.trackSidsCount > 0) {
                participantTracksList.add(builder.build())
            }
        }

        // backwards compatibility for protocol version < 6
        val trackSids = participantTracksList.map { it.trackSidsList }
            .flatten()

        val subscription = LivekitRtc.UpdateSubscription.newBuilder()
            .setSubscribe(!sendUnsub)
            .addAllParticipantTracks(participantTracksList)
            .addAllTrackSids(trackSids)
            .build()
        val publishedTracks = localParticipant.publishTracksInfo()
        engine.sendSyncState(subscription, publishedTracks)
    }

    /**
     * Sends a simulated scenario for the server to use.
     *
     * To be used for internal testing purposes only.
     * @suppress
     */
    fun sendSimulateScenario(scenario: LivekitRtc.SimulateScenario) {
        engine.client.sendSimulateScenario(scenario)
    }

    /**
     * Sends a simulated scenario for the server to use.
     *
     * To be used for internal testing purposes only.
     * @suppress
     */
    fun sendSimulateScenario(scenario: SimulateScenario) {
        val builder = LivekitRtc.SimulateScenario.newBuilder()
        when (scenario) {
            SimulateScenario.SPEAKER_UPDATE -> builder.speakerUpdate = 5
            SimulateScenario.NODE_FAILURE -> builder.nodeFailure = true
            SimulateScenario.MIGRATION -> builder.migration = true
            SimulateScenario.SERVER_LEAVE -> builder.serverLeave = true
            SimulateScenario.SERVER_LEAVE_FULL_RECONNECT -> builder.leaveRequestFullReconnect = true
        }
        sendSimulateScenario(builder.build())
    }

    /**
     * @suppress
     */
    @AssistedFactory
    interface Factory {
        fun create(context: Context): Room
    }

    // ------------------------------------- General Utility functions -------------------------------------//

    /**
     * Control muting/unmuting all audio output.
     *
     * Note: using this mute will only mute local audio output, and will still receive the data from
     * remote audio tracks. Consider turning off [ConnectOptions.autoSubscribe] and manually unsubscribing
     * if you need more fine-grained control over the data usage.
     **/
    fun setSpeakerMute(muted: Boolean) {
        audioDeviceModule.setSpeakerMute(muted)
    }

    /**
     * Control muting/unmuting the audio input.
     *
     * Note: using this mute will only zero the microphone audio data, and will still send data to
     * remote participants (although they will not hear anything). Consider using [TrackPublication.muted]
     * for more fine-grained control over the data usage.
     */
    fun setMicrophoneMute(muted: Boolean) {
        audioDeviceModule.setMicrophoneMute(muted)
    }

    // ------------------------------------- NetworkCallback -------------------------------------//
    private val networkCallbackManager = networkCallbackManagerFactory.invoke(
        object : NetworkCallback() {
            override fun onLost(network: Network) {
                // lost connection, flip to reconnecting
                hasLostConnectivity = true
            }

            override fun onAvailable(network: Network) {
                // only actually reconnect after connection is re-established
                if (!hasLostConnectivity) {
                    return
                }
                LKLog.i { "network connection available, reconnecting" }
                reconnect()
                hasLostConnectivity = false
            }
        },
    )

    // ----------------------------------- RpcManager ------------------------------------//
    override fun registerRpcMethod(method: String, handler: RpcHandler) {
        localParticipant.registerRpcMethod(method, handler)
    }

    override fun unregisterRpcMethod(method: String) {
        localParticipant.unregisterRpcMethod(method)
    }

    override suspend fun performRpc(destinationIdentity: Participant.Identity, method: String, payload: String, responseTimeout: Duration, maxRoundTripLatency: Duration): String {
        return localParticipant.performRpc(destinationIdentity, method, payload, responseTimeout, maxRoundTripLatency)
    }

    // ----------------------------------- RTCEngine.Listener ------------------------------------//

    /**
     * @suppress
     */
    override fun onEngineConnected() {
        state = State.CONNECTED
        // WordPlus Mesh (1.0.2): encoder reports while connected to a mesh
        if (onMesh) meshEncoders.start(coroutineScope)
        // WordPlus Mesh (1.0.5): the camera's hardware encoder, on any server
        meshHardwareDrops.start()
        eventBus.postEvent(RoomEvent.Connected(this), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onEngineReconnected() {
        state = State.CONNECTED
        if (onMesh) meshEncoders.start(coroutineScope)
        meshHardwareDrops.start()
        eventBus.postEvent(RoomEvent.Reconnected(this), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onEngineReconnecting() {
        state = State.RECONNECTING
        eventBus.postEvent(RoomEvent.Reconnecting(this), coroutineScope)
        // WordPlus Mesh (1.0.12): the node says its list again on the connection restored
        takeMeshSourcesDry(emptySet())
    }

    /**
     * @suppress
     */
    override fun onAddTrack(receiver: RtpReceiver, track: MediaStreamTrack, streams: Array<out MediaStream>) {
        if (streams.isEmpty()) {
            LKLog.i { "add track with empty streams?" }
            return
        }

        var (participantSid, streamId) = unpackStreamId(streams.first().id)
        var trackSid = track.id()

        if (streamId != null && streamId.startsWith("TR")) {
            trackSid = streamId
        }
        val participant = getParticipantBySid(participantSid) as? RemoteParticipant

        if (participant == null) {
            LKLog.e { "Tried to add a track for a participant that is not present. sid: $participantSid" }
            return
        }

        val statsGetter = engine.createStatsGetter(receiver)
        participant.addSubscribedMediaTrack(
            track,
            trackSid!!,
            autoManageVideo = adaptiveStream,
            statsGetter = statsGetter,
            receiver = receiver,
        )
    }

    /**
     * @suppress
     */
    override fun onUpdateParticipants(updates: List<LivekitModels.ParticipantInfo>) {
        for (info in updates) {
            val participantSid = Participant.Sid(info.sid)
            // LiveKit server doesn't send identity info prior to version 1.5.2 in disconnect updates
            // so we try to map an empty identity to an already known sID manually

            @Suppress("NAME_SHADOWING") var info = info
            if (info.identity.isNullOrBlank()) {
                info = with(info.toBuilder()) {
                    identity = sidToIdentity[participantSid]?.value ?: ""
                    build()
                }
            }

            val participantIdentity = Participant.Identity(info.identity)

            if (localParticipant.identity == participantIdentity) {
                localParticipant.updateFromInfo(info)
                continue
            }

            val isNewParticipant = !remoteParticipants.contains(participantIdentity)

            if (info.state == LivekitModels.ParticipantInfo.State.DISCONNECTED) {
                remoteParticipants[participantIdentity]?.disconnectReason = info.disconnectReasonValue
                handleParticipantDisconnect(participantIdentity)
            } else {
                val participant = getOrCreateRemoteParticipant(participantIdentity, info)
                if (isNewParticipant) {
                    eventBus.postEvent(RoomEvent.ParticipantConnected(this, participant), coroutineScope)
                } else {
                    participant.updateFromInfo(info)
                    sidToIdentity[participantSid] = participantIdentity
                }
            }
        }
    }

    /**
     * @suppress
     */
    override fun onActiveSpeakersUpdate(speakers: List<LivekitModels.SpeakerInfo>) {
        handleActiveSpeakersUpdate(speakers)
    }

    /**
     * @suppress
     */
    override fun onRemoteMuteChanged(trackSid: String, muted: Boolean) {
        localParticipant.onRemoteMuteChanged(trackSid, muted)
    }

    /**
     * @suppress
     */
    override fun onRoomUpdate(update: LivekitModels.Room) {
        if (update.sid != null) {
            sid = Sid(update.sid)
        }
        val oldMetadata = metadata
        metadata = update.metadata

        val oldIsRecording = isRecording
        isRecording = update.activeRecording

        if (oldMetadata != metadata) {
            eventBus.postEvent(RoomEvent.RoomMetadataChanged(this, metadata, oldMetadata), coroutineScope)
        }

        if (oldIsRecording != isRecording) {
            eventBus.postEvent(RoomEvent.RecordingStatusChanged(this, isRecording), coroutineScope)
        }
    }

    /**
     * @suppress
     */
    override fun onConnectionQuality(updates: List<LivekitRtc.ConnectionQualityInfo>) {
        updates.forEach { info ->
            val quality = ConnectionQuality.fromProto(info.quality)
            val participant = getParticipantBySid(info.participantSid) ?: return@forEach
            participant.connectionQuality = quality
            eventBus.postEvent(RoomEvent.ConnectionQualityChanged(this, participant, quality), coroutineScope)
        }
    }

    /**
     * @suppress
     */
    override fun onSpeakersChanged(speakers: List<LivekitModels.SpeakerInfo>) {
        handleSpeakersChanged(speakers)
    }

    /**
     * @suppress
     */
    override fun onUserPacket(packet: LivekitModels.UserPacket, kind: LivekitModels.DataPacket.Kind, encryptionType: LivekitModels.Encryption.Type) {
        val participant = getParticipantBySid(packet.participantSid) as? RemoteParticipant
        val data = packet.payload.toByteArray()
        val topic = if (packet.hasTopic()) {
            packet.topic
        } else {
            null
        }

        val event = RoomEvent.DataReceived(this, data, participant, topic, encryptionType)
        eventBus.postEvent(event, coroutineScope)
        participant?.onDataReceived(event)
    }

    /**
     * @suppress
     */
    override fun onDataStreamPacket(dp: LivekitModels.DataPacket, encryptionType: LivekitModels.Encryption.Type) {
        when (dp.valueCase) {
            LivekitModels.DataPacket.ValueCase.STREAM_HEADER -> {
                incomingDataStreamManager.handleStreamHeader(dp.streamHeader, Participant.Identity(dp.participantIdentity), encryptionType)
            }

            LivekitModels.DataPacket.ValueCase.STREAM_CHUNK -> {
                incomingDataStreamManager.handleDataChunk(dp.streamChunk, encryptionType)
            }

            LivekitModels.DataPacket.ValueCase.STREAM_TRAILER -> {
                incomingDataStreamManager.handleStreamTrailer(dp.streamTrailer, encryptionType)
            }

            // Ignore other cases.
            else -> {}
        }
    }

    /**
     * @suppress
     */
    override fun onTranscriptionReceived(transcription: LivekitModels.Transcription) {
        if (transcription.segmentsList.isEmpty()) {
            LKLog.d { "Received transcription segments are empty." }
            return
        }

        val participant = getParticipantByIdentity(transcription.transcribedParticipantIdentity)
        val publication = participant?.trackPublications?.get(transcription.trackId)
        val segments = transcription.segmentsList
            .map { it.toSDKType(firstReceivedTime = transcriptionReceivedTimes[it.id] ?: Date().time) }

        // Update receive times
        for (segment in segments) {
            if (segment.final) {
                transcriptionReceivedTimes.remove(segment.id)
            } else {
                transcriptionReceivedTimes[segment.id] = segment.firstReceivedTime
            }
        }

        val event = RoomEvent.TranscriptionReceived(
            room = this,
            transcriptionSegments = segments,
            participant = participant,
            publication = publication,
        )
        eventBus.tryPostEvent(event)
        participant?.onTranscriptionReceived(event)
        publication?.onTranscriptionReceived(event)
    }

    override fun onRpcPacketReceived(dp: LivekitModels.DataPacket) {
        localParticipant.handleDataPacket(dp)
    }

    /**
     * @suppress
     */
    override fun onStreamStateUpdate(streamStates: List<LivekitRtc.StreamStateInfo>) {
        for (streamState in streamStates) {
            val participant = getParticipantBySid(streamState.participantSid) ?: continue
            val track = participant.trackPublications[streamState.trackSid] ?: continue

            track.track?.streamState = Track.StreamState.fromProto(streamState.state)
        }
    }

    /**
     * @suppress
     */
    override fun onSubscribedQualityUpdate(subscribedQualityUpdate: LivekitRtc.SubscribedQualityUpdate) {
        localParticipant.handleSubscribedQualityUpdate(subscribedQualityUpdate)
    }

    /**
     * WordPlus Mesh (1.0.2, rtc-client 1.0.7): the node says whether anyone hears one of this participant's audio
     * tracks (any codec enabled, or none), which it says only to a client whose join named `audio-pause` (WordPlus
     * Mesh 1.0.32): a node pauses a video nobody watches through dynacast, and nothing did that for a microphone.
     *
     * @suppress
     */
    override fun onSubscribedAudioCodecUpdate(update: LivekitRtc.SubscribedAudioCodecUpdate) {
        val pub = localParticipant.trackPublications[update.trackSid] as? LocalTrackPublication ?: return
        val track = pub.track as? LocalAudioTrack ?: return
        track.setMeshHeard(update.subscribedAudioCodecsList.any { it.enabled })
    }

    /**
     * WordPlus Mesh (1.0.6, rtc-client 1.0.16): the node's pace for the reports (MeshEncoderReporter's tick).
     *
     * @suppress
     */
    override fun onMeshReportPace(every: Int) {
        meshEncoders.setPace(every)
    }

    /**
     * WordPlus Mesh (1.0.9): the client's settings on a running call.
     *
     * @suppress
     */
    override fun onMeshSettings(json: String) {
        takeMeshSettings(json)
    }

    /**
     * WordPlus Mesh (1.0.12): the tracks it subscribes to that stopped reaching its node.
     *
     * @suppress
     */
    override fun onMeshSourcesDry(dry: Set<String>) {
        takeMeshSourcesDry(dry)
    }

    /** Keeps what the node says of the tracks that stopped reaching it, telling the product only when that changed. */
    @VisibleForTesting
    internal fun takeMeshSourcesDry(dry: Set<String>) {
        if (dry == meshSourcesDry) return
        meshSourcesDry = dry
        eventBus.postEvent(RoomEvent.MeshSourcesDryChanged(this, dry), coroutineScope)
    }

    /**
     * Takes the settings a node sent, whole: keeps them for the next connect to this server, holds this room's cameras
     * to their live caps, starts the round-trip probe when they name nodes to measure, and tells the product what
     * changed.
     */
    private fun takeMeshSettings(json: String) {
        val next = MeshSettings.parse(json) ?: run {
            LKLog.w { "settings from the server not read (${json.length} characters)" }
            return
        }
        val before = meshSettings
        meshSettings = next
        meshProvidedUrl?.let { MeshSettings.keep(context, json, it) }
        val changed = next.changed(before)
        LKLog.d { "settings rev ${next.rev}, ${next.values.size} set, changed: ${changed.sorted()}" }
        if (next.cameraCaps != before.cameraCaps) {
            localParticipant.applyMeshCaps(cameraCaps)
        }
        // what the encoder of a running camera gives up first, live (`camera.degradation`)
        localParticipant.meshSettings = next
        if ("camera.degradation" in changed) {
            localParticipant.applyMeshDegradation()
        }
        // whether a camera in one SVC stream sends only the sizes its viewers ask for, live (`camera.svcTrim`)
        if ("camera.svcTrim" in changed) {
            localParticipant.applyMeshSvcTrim()
        }
        // how often the connections' stats are read (`stats.everyMs`)
        meshEncoders.stats.everyMs = next.number("stats.everyMs")?.toLong() ?: MeshStats.READ_EVERY_MS
        if (next.bool("probe.enabled") == true && next.probe.isNotEmpty()) {
            MeshProbe.measure(context, next.probe, next.int("probe.samples") ?: 3, next.int("probe.cacheMin") ?: 20)
        }
        if (changed.isNotEmpty() || before.rev != next.rev) {
            if (::coroutineScope.isInitialized) {
                eventBus.postEvent(RoomEvent.MeshSettingsChanged(this, next, changed), coroutineScope)
            }
        }
    }

    /**
     * @suppress
     */
    override fun onSubscriptionPermissionUpdate(subscriptionPermissionUpdate: LivekitRtc.SubscriptionPermissionUpdate) {
        val participant = getParticipantBySid(subscriptionPermissionUpdate.participantSid) as? RemoteParticipant ?: return
        participant.onSubscriptionPermissionUpdate(subscriptionPermissionUpdate)
    }

    /**
     * @suppress
     */
    override fun onSubscriptionError(subscriptionResponse: LivekitRtc.SubscriptionResponse) {
        val participant = remoteParticipants.values
            .firstOrNull { it.trackPublications.containsKey(subscriptionResponse.trackSid) } as? RemoteParticipant
            ?: return
        participant.onSubscriptionError(subscriptionResponse)
    }

    /**
     * @suppress
     */
    override fun onEngineDisconnected(reason: DisconnectReason) {
        LKLog.v { "engine did disconnect: $reason" }
        handleDisconnect(reason)
    }

    /**
     * @suppress
     */
    override fun onFailToConnect(error: Throwable) {
        // WordPlus Mesh: the walk tries again, and says when it gives up.
        if (meshWalking) return
        // scope will likely be closed already here, so force it out of scope.
        eventBus.tryPostEvent(RoomEvent.FailedToConnect(this, error))
    }

    /**
     * @suppress
     */
    override suspend fun onSignalConnected(isResume: Boolean) {
        if (isResume) {
            // during resume reconnection, need to send sync state upon signal connection.
            sendSyncState()
        }
    }

    /**
     * @suppress
     */
    override fun onFullReconnecting() {
        localParticipant.prepareForFullReconnect()
        remoteParticipants.values.forEach { it.detachDataTracks() }
        remoteParticipants.keys.toMutableSet() // copy keys to avoid concurrent modifications.
            .forEach { identity -> handleParticipantDisconnect(identity) }
    }

    /**
     * @suppress
     */
    override suspend fun onPostReconnect(isFullReconnect: Boolean) {
        // WordPlus Mesh (1.0.2): all of the encoders again, to a node that may hold no session of this client yet
        if (onMesh) meshEncoders.start(coroutineScope)
        if (isFullReconnect) {
            localParticipant.republishTracks()
        } else {
            val remoteParticipants = remoteParticipants.values.toList()
            for (participant in remoteParticipants) {
                val pubs = participant.trackPublications.values.toList()
                for (pub in pubs) {
                    val remotePub = pub as? RemoteTrackPublication ?: continue
                    if (remotePub.subscribed) {
                        remotePub.sendUpdateTrackSettings.invoke()
                    }
                }
            }
        }
    }

    /**
     * @suppress
     */
    override fun onLocalTrackSubscribed(response: LivekitRtc.TrackSubscribed) {
        val publication = localParticipant.trackPublications[response.trackSid] as? LocalTrackPublication

        if (publication == null) {
            LKLog.w { "Could not find local track publication for subscribed event " }
            return
        }

        coroutineScope.launch {
            emitWhenConnected(RoomEvent.LocalTrackSubscribed(this@Room, publication, this@Room.localParticipant))
        }
        this.localParticipant.onLocalTrackSubscribed(publication)
    }

    /**
     * @suppress
     */
    override fun onLocalTrackUnpublished(trackUnpublished: LivekitRtc.TrackUnpublishedResponse) {
        localParticipant.handleLocalTrackUnpublished(trackUnpublished)
    }

    // ------------------------------- ParticipantListener --------------------------------//
    /**
     * This is called for both Local and Remote participants
     * @suppress
     */
    override fun onMetadataChanged(participant: Participant, prevMetadata: String?) {
    }

    /** @suppress */
    override fun onTrackMuted(publication: TrackPublication, participant: Participant) {
        eventBus.postEvent(RoomEvent.TrackMuted(this, publication, participant), coroutineScope)
    }

    /** @suppress */
    override fun onTrackUnmuted(publication: TrackPublication, participant: Participant) {
        eventBus.postEvent(RoomEvent.TrackUnmuted(this, publication, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackUnpublished(publication: RemoteTrackPublication, participant: RemoteParticipant) {
        eventBus.postEvent(RoomEvent.TrackUnpublished(this, publication, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackPublished(publication: LocalTrackPublication, participant: LocalParticipant) {
        if (e2eeManager != null) {
            e2eeManager!!.addPublishedTrack(publication.track!!, publication, participant, this)
        }
        eventBus.postEvent(RoomEvent.TrackPublished(this, publication, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackUnpublished(publication: LocalTrackPublication, participant: LocalParticipant) {
        e2eeManager?.removePublishedTrack(publication.track!!, publication, participant, this)
        eventBus.postEvent(RoomEvent.TrackUnpublished(this, publication, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackSubscribed(track: Track, publication: RemoteTrackPublication, participant: RemoteParticipant) {
        if (e2eeManager != null) {
            e2eeManager!!.addSubscribedTrack(track, publication, participant, this)
        }
        eventBus.postEvent(RoomEvent.TrackSubscribed(this, track, publication, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackSubscriptionFailed(
        sid: String,
        exception: Exception,
        participant: RemoteParticipant,
    ) {
        eventBus.postEvent(RoomEvent.TrackSubscriptionFailed(this, sid, exception, participant), coroutineScope)
    }

    /**
     * @suppress
     */
    override fun onTrackUnsubscribed(
        track: Track,
        publication: RemoteTrackPublication,
        participant: RemoteParticipant,
    ) {
        e2eeManager?.removeSubscribedTrack(track, publication, participant, this)
        eventBus.postEvent(RoomEvent.TrackUnsubscribed(this, track, publication, participant), coroutineScope)
    }

    /**
     * Initialize a [SurfaceViewRenderer] for rendering a video from this room.
     */
    // TODO(@dl): can this be moved out of Room/SDK?
    fun initVideoRenderer(viewRenderer: SurfaceViewRenderer) {
        viewRenderer.init(eglBase.eglBaseContext, null)
        viewRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewRenderer.setEnableHardwareScaler(false)
    }

    /**
     * Initialize a [TextureViewRenderer] for rendering a video from this room.
     */
    // TODO(@dl): can this be moved out of Room/SDK?
    fun initVideoRenderer(viewRenderer: TextureViewRenderer) {
        viewRenderer.init(eglBase.eglBaseContext, null)
        viewRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewRenderer.setEnableHardwareScaler(false)
    }

    private suspend fun emitWhenConnected(event: RoomEvent) {
        if (state == State.CONNECTED) {
            eventBus.postEvent(event)
        }
    }

    /**
     * Get stats for the publisher peer connection.
     *
     * @see getSubscriberRTCStats
     * @see getFilteredStats
     */
    fun getPublisherRTCStats(callback: RTCStatsCollectorCallback) = engine.getPublisherRTCStats(callback)

    /**
     * Get stats for the subscriber peer connection.
     *
     * @see getPublisherRTCStats
     * @see getFilteredStats
     */
    fun getSubscriberRTCStats(callback: RTCStatsCollectorCallback) = engine.getSubscriberRTCStats(callback)

    // Debug options

    /**
     * @suppress
     */
    @VisibleForTesting
    fun setReconnectionType(reconnectType: ReconnectType) {
        engine.reconnectType = reconnectType
    }
}

sealed class RoomException(message: String? = null, cause: Throwable? = null) :
    Exception(message, cause) {
    class ConnectException(message: String? = null, cause: Throwable? = null) :
        RoomException(message, cause)
}

internal fun unpackStreamId(packed: String): Pair<String, String?> {
    val parts = packed.split('|')
    if (parts.size != 2) {
        return Pair(packed, null)
    }
    return Pair(parts[0], parts[1])
}
