/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.content.res.Configuration
import android.content.res.Resources
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

// WordPlus Mesh: what this client does differently on a mesh's servers, as @wordplus/rtc-client does in a browser
// (the mesh's clients/js). The protocol is upstream's own; a mesh node answers `/settings/regions` as LiveKit Cloud
// does, refuses a join it can't place now with HTTP 429, and sends its region list over the signal connection.

/**
 * The domains a mesh serves: `rtc.wordplus.cloud` and the names under it, and any a product adds.
 */
object MeshDomains {
    private val domains = mutableSetOf("rtc.wordplus.cloud")

    /** Adds domains served by a mesh, beside the built-in ones. */
    @JvmStatic
    fun add(vararg list: String) {
        synchronized(domains) {
            for (domain in list) {
                val clean = domain.lowercase().trim('.')
                if (clean.isNotEmpty()) domains.add(clean)
            }
        }
    }

    internal fun contains(host: String): Boolean = synchronized(domains) {
        domains.any { host == it || host.endsWith(".$it") }
    }
}

/** WordPlus Mesh: a server under a mesh's domain, `rtc.wordplus.cloud` and the names under it. */
fun URI.isMeshServer(): Boolean = host?.lowercase()?.let { MeshDomains.contains(it) } ?: false

/** WordPlus Mesh: [isMeshServer] for a URL as a string. */
fun isMeshServer(url: String): Boolean = try {
    URI(url).isMeshServer()
} catch (e: Exception) {
    false
}

/**
 * Why a join on a mesh started to wait: every server tried was [BUSY] and a slot is held on one, a node holds a
 * [SLOT] for it, the cluster is [FULL] (and a slot is held), or no server of the list could be reached at all.
 */
enum class MeshWaitReason(val wire: String) {
    BUSY("busy"),
    SLOT("slot"),
    FULL("full"),
    UNREACHABLE("unreachable"),
    ;

    companion object {
        internal fun fromWire(wire: String?): MeshWaitReason? = entries.firstOrNull { it.wire == wire }
    }
}

/** A join on a mesh waiting, until when (epoch ms), and why ([ConnectOptions.onMeshWait]). */
data class MeshWait(val until: Long, val reason: MeshWaitReason)

/**
 * The product placing a call (1.0.2, rtc-client 1.0.6's `meshApp`), which a mesh node is told on each join of the room
 * (`rtc_app`) for its live view: `MeshApp("better-messages", "3.1.4")`.
 */
data class MeshApp(val name: String, val version: String? = null)

/**
 * A mesh node's codec policy (1.0.2, rtc-client 1.0.8's `MeshCodecPolicy`), [Room.meshCodecPolicy]: each list the codecs
 * it would have a camera or a screen go out in, first choice first (`h265:hw` only from hardware), and what goes behind a
 * camera. A preference: the product takes the first its device sends.
 *
 * Since 1.0.6 (rtc-client 1.0.16's, WordPlus Mesh 1.0.53): the node's switches for the product's camera check and its
 * camera moving to another codec during a call ([check], [adapt]: JSON booleans only, null from a node that says
 * neither), which nothing in this client acts on, and its numbers by name ([tune]), which the product holds each to its
 * own range: `failsafeS`, for one, the longest a viewer shows a camera moving to another codec as "Optimizing video
 * quality...".
 */
data class MeshCodecPolicy(
    val camera: List<String>? = null,
    val screen: List<String>? = null,
    val backup: String? = null,
    val check: Boolean? = null,
    val adapt: Boolean? = null,
    /** At most 32, each a name of 24 characters at most and a finite number; null where the node sends no `tune`. */
    val tune: Map<String, Double>? = null,
)

/** A mesh node's refusal of a join, from its 429 (`X-Mesh-Refused`, `X-Mesh-Node`, `Retry-After`). */
data class MeshRefusal(
    /** `busy`, `slot` or `full`; null from a server that names none. */
    val kind: String?,
    /** The refusing node's id, as the region list names it. */
    val node: String?,
    /** How long until the node takes the join, in ms, when it said. */
    val retryAfterMs: Long?,
) {
    companion object {
        internal fun of(kind: String?, node: String?, retryAfter: String?): MeshRefusal = MeshRefusal(
            kind = kind?.takeIf { it in setOf("busy", "slot", "full") },
            node = node?.takeIf { it.isNotEmpty() },
            retryAfterMs = retryAfterMs(retryAfter),
        )

        /** A Retry-After header in ms: seconds, or an HTTP date; null if neither. */
        internal fun retryAfterMs(header: String?, now: Long = System.currentTimeMillis()): Long? {
            val value = header?.trim()?.takeIf { it.isNotEmpty() } ?: return null
            value.toDoubleOrNull()?.let { if (it >= 0) return (it * 1000).toLong() }
            return try {
                val format = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
                format.timeZone = TimeZone.getTimeZone("GMT")
                format.parse(value)?.time?.let { maxOf(0L, it - now) }
            } catch (e: Exception) {
                null
            }
        }
    }
}

/**
 * WordPlus Mesh: a join a mesh node refused for now (HTTP 429), with what it said.
 */
class MeshRefusedException(val refusal: MeshRefusal, message: String?, cause: Throwable? = null) :
    RoomException(message, cause)

/** WordPlus Mesh: the mesh's refusal anywhere in a failed join's causes, or null. */
fun Throwable.meshRefusal(): MeshRefusal? {
    var error: Throwable? = this
    while (error != null) {
        if (error is MeshRefusedException) return error.refusal
        error = error.cause.takeIf { it !== error }
    }
    return null
}

internal object Mesh {
    /** How long a join keeps trying before it reports its last error, unless the product says otherwise. */
    const val JOIN_BUDGET_MS = 30_000L

    /**
     * How long a resume waits for its server before moving on, at least: a live node answers within about a second,
     * even across continents, and a dead one would otherwise hold the attempt past the mesh's hold of its participants.
     */
    const val RESUME_TIMEOUT_MS = 5_000L

    /**
     * How long a resume waits for its server (1.0.1, rtc-client 1.0.5's resumeWaitMs): four of the round trips the
     * connection last measured, at least [RESUME_TIMEOUT_MS] and at most the connect's own timeout. A connection whose
     * round trip had grown to seconds, a phone behind a full queue, took 5 s for a server that is gone and moved on
     * from one that was up (a large audio chat, 2026-10-17: 2 to 28 s).
     */
    fun resumeWaitMs(rttMs: Long, capMs: Long): Long = minOf(capMs, maxOf(RESUME_TIMEOUT_MS, 4 * maxOf(rttMs, 0L)))

    /** How long a probe of whether a server answers may take (1.0.1). */
    const val SERVER_PROBE_TIMEOUT_MS = 3_000L

    /** How many servers a failed resume probes before it stays where it is (1.0.1, rtc-client 1.0.12). */
    const val RESUME_MOVE_TRIES = 3

    /**
     * Whether a failed resume goes to another server of the region list (1.0.1, rtc-client 1.0.5): only when its own
     * server has stopped answering and that one answers. When its own still answers, the server is up and the resume
     * failed on the way. When neither answers, it is this client's network that is down, and every server would fail
     * alike: walking the list then took a phone in a call on France's node to Limburg and on to Canada during its own
     * outage, and kept it there for the rest of the call (a large audio chat, 2026-10-17).
     */
    fun resumeMoves(ownAnswers: Boolean, nextAnswers: Boolean): Boolean = !ownAnswers && nextAnswers

    /** Whether two signal URLs name the same server, by host and port (1.0.1, rtc-client 1.0.12). */
    fun sameServer(a: String, b: String): Boolean = try {
        val x = URI(a)
        val y = URI(b)
        x.host.equals(y.host, ignoreCase = true) && x.port == y.port
    } catch (e: Exception) {
        a == b
    }

    /** A signal URL's origin over HTTP(S), which [RegionUrlProvider.serverAnswers] asks; null for one it can't read. */
    fun httpOrigin(url: String): String? = try {
        val uri = URI(url)
        val scheme = when (uri.scheme?.lowercase()) {
            "wss", "https" -> "https"
            "ws", "http" -> "http"
            else -> null
        }
        if (scheme == null || uri.host == null) null else URI(scheme, null, uri.host, uri.port, "/", null, null).toString()
    } catch (e: Exception) {
        null
    }

    /**
     * How long the region list's fetch, or the validation after a failed join, may take before it counts as
     * unreachable: stock waits the HTTP client's own, and a dead server held the next attempt that long.
     */
    const val REQUEST_TIMEOUT_MS = 3_000L

    /** How long after a join a node has to send its region list before it is fetched instead. */
    const val REGIONS_WAIT_MS = 3_000L

    /** The mesh's wait when every node is full, if its 429 names none. */
    const val FULL_RETRY_MS = 5_000L

    /**
     * How many resumes a reconnect makes on a mesh, each on the list's next server, before a full reconnect: the mesh
     * takes over a session it doesn't hold, so a resume elsewhere keeps the session where a full reconnect makes a new
     * one, which the others see leave.
     */
    const val RESUME_TRIES = 4

    /**
     * How long an encrypted room's publisher waits before it closes, its video senders' tracks off (1.0.11). WebRTC's
     * RTPSenderVideoFrameTransformerDelegate hands each encrypted frame to a task queue of its own, and the task holds a
     * reference to it. A frame still on its way as the sender is destroyed can leave that task the last reference, and
     * the delegate then deletes its queue on the queue's own thread. On Android that thread joins itself and the process
     * aborts (platform_thread.cc, pthread_join, 0 vs. 35, on thread VideoFrameTrans). As of WebRTC M150 nothing guards it,
     * and no call from here reaches that queue, so this only gives the frames time to leave.
     */
    const val ENCRYPTED_VIDEO_DRAIN_MS = 250L

    /** The signal response field a node sends its region list in: one LiveKit's protocol hasn't got. */
    const val REGIONS_FIELD = 100

    /**
     * The signal response field a node tells a client how often to send its reports in (1.0.6, rtc-client 1.0.16's
     * `MESH_REPORTS_FIELD`, WordPlus Mesh 1.0.53): JSON, `{"every": ms}`, 0 for not at all; every 10 s in a small call,
     * less often in a big room. Any other client skips it.
     */
    const val REPORTS_FIELD = 101

    private val json = Json { ignoreUnknownKeys = true }

    /** The pace a signal response asks for the reports at ([REPORTS_FIELD]), ms; null when the message is another. */
    fun reportPaceInSignalMessage(bytes: ByteArray): Int? {
        val raw = lengthDelimitedField(REPORTS_FIELD, bytes) ?: return null
        return try {
            val every = (json.parseToJsonElement(raw.decodeToString()) as? JsonObject)?.get("every")?.jsonPrimitive?.doubleOrNull
            every?.takeIf { it.isFinite() && it >= 0 }?.toInt()
        } catch (e: Exception) {
            null
        }
    }

    /**
     * A reading's reports as one signal request's bytes, each JSON in its own field ([MeshEncoders.FIELD],
     * [MeshReceivers.FIELD], [MeshHealth.FIELD]); null when there is none.
     */
    fun reports(encoders: String?, receivers: String?, health: String?): ByteArray? {
        val parts = listOfNotNull(
            encoders?.let { lengthDelimited(MeshEncoders.FIELD, it.encodeToByteArray()) },
            receivers?.let { lengthDelimited(MeshReceivers.FIELD, it.encodeToByteArray()) },
            health?.let { lengthDelimited(MeshHealth.FIELD, it.encodeToByteArray()) },
        )
        return if (parts.isEmpty()) null else parts.reduce { a, b -> a + b }
    }

    /**
     * How long to wait before trying a failed join again, or null when it isn't one to try again or the deadline
     * comes first: a full mesh after its Retry-After, within a second after it (or 5 s, give or take half); a server
     * that couldn't be reached after 1 to 3 s.
     */
    fun joinRetryMs(error: Throwable, deadline: Long, now: Long = System.currentTimeMillis()): Long? {
        val refusal = error.meshRefusal()
        val delay = when {
            refusal != null -> refusal.retryAfterMs?.let { it + Random.nextLong(1_000) }
                ?: (FULL_RETRY_MS * (0.5 + Random.nextDouble())).toLong()
            isRefusedToken(error) -> return null
            else -> 1_000L + Random.nextLong(2_000)
        }
        return if (now + delay < deadline) delay else null
    }

    /**
     * A refusal of the token or the room, which no server will take: the validation's 401 or 403, which a failed join
     * to a mesh's server reports with its status (`SignalClient.onFailure`).
     */
    fun isRefusedToken(error: Throwable): Boolean =
        generateSequence(error) { it.cause.takeIf { cause -> cause !== it } }
            .any { Regex("^HTTP (401|403)\\b").containsMatchIn(it.message ?: "") }

    /** The busy server to wait on: the home region's that frees first, another region's only if it had none. */
    fun <T> waitOn(busy: List<T>, home: String?, region: (T) -> String?, freeAt: (T) -> Long): T? {
        val near = busy.filter { home != null && region(it) == home }
        return (near.ifEmpty { busy }).minByOrNull(freeAt)
    }

    /** The server's URL with `mesh_wait=1`, which keeps the join a slot of its own on that node while it waits. */
    fun withMeshWait(url: String): String {
        val uri = URI(url)
        val query = (uri.rawQuery?.split('&')?.filter { it.isNotEmpty() && !it.startsWith("mesh_wait=") } ?: emptyList()) + "mesh_wait=1"
        return URI(uri.scheme, uri.rawAuthority, uri.rawPath, null, null).toString() + "?" + query.joinToString("&")
    }

    /** Whether this is a server the join said it will wait on ([withMeshWait]). */
    fun isMeshWait(url: String): Boolean = try {
        URI(url).rawQuery?.split('&')?.contains("mesh_wait=1") == true
    } catch (e: Exception) {
        false
    }

    /** The URL without its query, which upstream's signal URL is built on. */
    fun withoutQuery(url: String): String = try {
        val uri = URI(url)
        URI(uri.scheme, uri.rawAuthority, uri.rawPath, null, null).toString()
    } catch (e: Exception) {
        url
    }

    /**
     * The WordPlus RTC client for Android's own version, which a mesh node is told on each join (`rtc_client`) beside
     * upstream's, which the client reports as its SDK's and servers gate protocol features on. build.sh refuses a patch
     * whose version here isn't the one its revisions list.
     */
    const val CLIENT_VERSION = "1.0.13"

    /**
     * What this client can do beyond upstream's, which a mesh node is told on each join (`mesh_caps`, 1.0.2, as
     * rtc-client 1.0.7 and 1.0.8): it stops sending an audio track nobody hears when its node says so
     * (`LocalAudioTrack.setMeshHeard`), its room hands the node's codec policy to the product
     * ([Room.meshCodecPolicy]), since 1.0.9 it reads its settings ([Room.meshSettings], fields 1002 and 102), and since
     * 1.0.12 which tracks stopped reaching its node ([Room.meshSourcesDry], field 103).
     */
    const val CAPS = "audio-pause,codec-policy,settings,source-dry"

    /** The signal response field a node tells a viewer in which of the tracks it subscribes to have stopped reaching the
     * node (1.0.12, rtc-client 1.0.25): JSON, `{"dry": ["TR_..."]}`, its whole list each time, empty when none has. */
    const val SOURCES_DRY_FIELD = 103

    /** The tracks a signal response says stopped reaching the node ([SOURCES_DRY_FIELD]); null when the message is another. */
    fun sourcesDryInSignalMessage(bytes: ByteArray): Set<String>? {
        val raw = lengthDelimitedField(SOURCES_DRY_FIELD, bytes) ?: return null
        return try {
            val dry = (json.parseToJsonElement(raw.decodeToString()) as? JsonObject)?.get("dry") as? JsonArray
            dry?.mapNotNull { (it as? JsonPrimitive)?.takeIf { p -> p.isString }?.content }?.toSet()
        } catch (e: Exception) {
            null
        }
    }

    /** The join response field a node sends a client its settings in (1.0.9, WordPlus Mesh's client settings): JSON,
     * [MeshSettings]. LiveKit's JoinResponse has no field of that number; 1001 is the codec policy. */
    const val SETTINGS_JOIN_FIELD = 1002

    /** The signal response field a node sends a client its settings in on a running call, whenever they change (1.0.9):
     * the same JSON. 100 is the region list, 101 the report pace. */
    const val SETTINGS_FIELD = 102

    /** The settings a join response's bytes carry ([SETTINGS_JOIN_FIELD]), as JSON, if any. */
    fun settingsInJoinResponse(joinResponse: ByteArray): String? =
        lengthDelimitedField(SETTINGS_JOIN_FIELD, joinResponse)?.decodeToString()

    /** The settings a signal response sends on a running call ([SETTINGS_FIELD]), as JSON; null when the message is
     * another. */
    fun settingsInSignalMessage(bytes: ByteArray): String? = lengthDelimitedField(SETTINGS_FIELD, bytes)?.decodeToString()

    /**
     * What a join to a mesh's server says beside upstream's parameters (upstream already names the network's type,
     * `network`):
     * - `mesh_client`: it walks and waits, so a busy node may refuse it;
     * - `mesh_hwdec`: the codecs it decodes in hardware;
     * - `mesh_wait`: it waits on this node (from the URL the walk gave it);
     * - `rtc_client`, `mesh_caps`, `rtc_app`, `device_type` (1.0.2, rtc-client 1.0.6 to 1.0.8): its own version, what it
     *   can do, the room's product and the device kind, for the node's live view;
     * - `mesh_hwenc` (1.0.2, rtc-client 1.0.8): the codecs it encodes in hardware.
     * Nothing for any other server.
     */
    fun queryParams(url: String, options: io.livekit.android.ConnectOptions): List<Pair<String, String>> {
        if (!isMeshServer(url)) return emptyList()
        val params = mutableListOf("mesh_client" to "1")
        if (options.meshHardwareDecoders.isNotEmpty()) params.add("mesh_hwdec" to options.meshHardwareDecoders.joinToString(","))
        if (options.meshHardwareEncoders.isNotEmpty()) params.add("mesh_hwenc" to options.meshHardwareEncoders.joinToString(","))
        params.add("rtc_client" to CLIENT_VERSION)
        params.add("mesh_caps" to CAPS)
        appParam(options.meshApp)?.let { params.add("rtc_app" to it) }
        deviceType()?.let { params.add("device_type" to it) }
        // 1.0.9: the round trips to each region this network measured lately (MeshProbe), for the mesh's placement
        MeshProbe.joinParam()?.let { params.add("mesh_rtt" to it) }
        if (isMeshWait(url)) params.add("mesh_wait" to "1")
        return params
    }

    /**
     * A room's product as a join names it (`rtc_app`, rtc-client 1.0.6's meshAppParam), "better-messages/3.1.4":
     * letters, digits and . _ - only, 40 of each; none without a name.
     */
    fun appParam(app: MeshApp?): String? {
        fun clean(s: String?) = (s ?: "").filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it in "._-" }.take(40)
        val name = clean(app?.name)
        return if (name.isEmpty()) null else "$name/${clean(app?.version)}"
    }

    /**
     * The device kind a join names (`device_type`, rtc-client 1.0.6): a tablet from a smallest width of 600 dp, as
     * Android's own resources tell them apart, a phone below it; none for a television, a watch or a car.
     */
    fun deviceType(): String? = try {
        val configuration = Resources.getSystem().configuration
        deviceType(configuration.uiMode and Configuration.UI_MODE_TYPE_MASK, configuration.smallestScreenWidthDp)
    } catch (e: Exception) {
        null
    }

    /** The device kind of a UI mode type and a smallest screen width in dp. */
    fun deviceType(uiModeType: Int, smallestWidthDp: Int): String? = when (uiModeType) {
        Configuration.UI_MODE_TYPE_NORMAL, Configuration.UI_MODE_TYPE_UNDEFINED, Configuration.UI_MODE_TYPE_DESK ->
            if (smallestWidthDp >= 600) "tablet" else "phone"
        else -> null
    }

    /**
     * The join response field a node sends its codec policy in (1.0.2, WordPlus Mesh 1.0.33's `mesh.codec_policy`): one
     * LiveKit's JoinResponse hasn't got, so any other client skips it.
     */
    const val CODEC_POLICY_FIELD = 1001

    /**
     * The codec policy a join response's bytes carry ([CODEC_POLICY_FIELD]), if any: only lists of names (eight, 16
     * characters each), a name, two booleans and numbers by name ([codecTune]) are kept, so whatever else a server
     * sends can't reach a product's codec choice.
     */
    fun codecPolicy(joinResponse: ByteArray): MeshCodecPolicy? {
        val raw = lengthDelimitedField(CODEC_POLICY_FIELD, joinResponse) ?: return null
        val obj = try {
            json.parseToJsonElement(raw.decodeToString()) as? JsonObject
        } catch (e: Exception) {
            null
        } ?: return null
        fun names(value: JsonElement?): List<String>? = (value as? JsonArray)
            ?.mapNotNull { (it as? JsonPrimitive)?.takeIf { p -> p.isString }?.content }
            ?.filter { it.length <= 16 }
            ?.take(8)
        // a JSON true or false (1.0.6), never a string that reads as one, as the browser's client takes only a boolean
        fun flag(value: JsonElement?): Boolean? = (value as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull
        val backup = (obj["backup"] as? JsonPrimitive)?.takeIf { it.isString }?.content?.takeIf { it.length <= 16 }
        return MeshCodecPolicy(
            camera = names(obj["camera"]),
            screen = names(obj["screen"]),
            backup = backup,
            check = flag(obj["check"]),
            adapt = flag(obj["adapt"]),
            tune = codecTune(obj["tune"]),
        )
    }

    /**
     * The codec policy's numbers by name (1.0.6, as rtc-client 1.0.16's meshCodecPolicy reads `tune`): an object's
     * first 32 keys, in the order the node writes them (sorted, Go's encoding of a map), each kept where its name has 24
     * characters at most and its value is a finite number (no boolean, string or null). Null where `tune` is not an
     * object.
     */
    fun codecTune(value: JsonElement?): Map<String, Double>? {
        val given = value as? JsonObject ?: return null
        val tune = LinkedHashMap<String, Double>()
        for ((name, entry) in given.entries.take(32)) {
            if (name.length > 24) continue
            val number = (entry as? JsonPrimitive)?.takeIf { !it.isString }?.doubleOrNull ?: continue
            if (number.isFinite()) tune[name] = number
        }
        return tune
    }

    /** The region list a node sent in a signal response ([REGIONS_FIELD]), or null when the message is another. */
    fun regionsInSignalMessage(bytes: ByteArray): List<RegionInfo>? =
        lengthDelimitedField(REGIONS_FIELD, bytes)?.let { regions(it.decodeToString()) }

    /** The first length-delimited field [no] of a protobuf message's bytes, or null when it has none or can't be read. */
    fun lengthDelimitedField(no: Int, bytes: ByteArray): ByteArray? {
        var at = 0

        fun varint(): Long? {
            var value = 0L
            var shift = 0
            while (at < bytes.size && shift < 64) {
                val byte = bytes[at++].toInt() and 0xFF
                value = value or ((byte and 0x7F).toLong() shl shift)
                if (byte and 0x80 == 0) return value
                shift += 7
            }
            return null
        }

        while (at < bytes.size) {
            val tag = varint() ?: return null
            val field = (tag ushr 3).toInt()
            when ((tag and 0x7).toInt()) {
                0 -> varint() ?: return null
                1 -> at += 8
                2 -> {
                    val length = varint()?.toInt() ?: return null
                    if (length < 0 || at + length > bytes.size) return null
                    if (field == no) return bytes.copyOfRange(at, at + length)
                    at += length
                }
                5 -> at += 4
                else -> return null
            }
        }
        return null
    }

    /**
     * A length-delimited field's bytes as a message carries it: its tag, its length, then the data (1.0.3's encoder
     * reports go so, in a request with no message of LiveKit's).
     */
    fun lengthDelimited(no: Int, data: ByteArray): ByteArray {
        fun varint(value: Long): ByteArray {
            val out = java.io.ByteArrayOutputStream()
            var n = value
            while (n >= 0x80) {
                out.write(((n and 0x7F) or 0x80).toInt())
                n = n ushr 7
            }
            out.write(n.toInt())
            return out.toByteArray()
        }
        return varint((no.toLong() shl 3) or 2) + varint(data.size.toLong()) + data
    }

    /** A region list as `/settings/regions` answers it, each entry with the node it leads to. */
    fun regions(text: String): List<RegionInfo>? = try {
        json.decodeFromString(RegionSettings.serializer(), text).regions.takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }
}
