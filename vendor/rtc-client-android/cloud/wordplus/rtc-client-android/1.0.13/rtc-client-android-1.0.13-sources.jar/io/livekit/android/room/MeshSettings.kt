/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.content.Context
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull
import java.net.URI
import kotlin.math.roundToInt

// WordPlus Mesh (1.0.9): the settings a mesh node hands this client for its calls, from the mesh's settings document
// (the mesh's pkg/clientsettings), so a product takes its numbers from the server and not from its own constants. They
// come with the join response (field 1002) and again on a running call whenever they change (signal response field
// 102), the same JSON: {"rev": 57, "applyNow": true, "set": {"camera.capHeight": 720}, "probe": [...]}. A client takes
// each message whole: a setting the next one leaves out goes back to its default. Every value is checked again here,
// against the schema compiled in (MeshSettingsSchema.kt, generated from the mesh's schema.json): a key this client
// doesn't know is left out, a value of the wrong type is the key's default, a number outside its range is held to it.
// The device's own rules (which codecs it can send, VP8 in an encrypted room) stay the product's, above every value.

/** When a client takes a change of a setting: at once, at the next camera or screen turned on, at the next camera or
 * microphone open, at the next connect, or at the next call. */
enum class MeshSettingClass { LIVE, PUBLISH, CAPTURE, JOIN, ROOM }

internal enum class MeshSettingType { NUMBER, INT, BOOL, ENUMERATION, CODECS, CODECRULES, LAYERS, INTS }

/** One key of the schema (generated into [MeshSettingsSchema.keys]). */
internal data class MeshSettingKey(
    val type: MeshSettingType,
    val keyClass: MeshSettingClass,
    val min: Double?,
    val max: Double?,
    val values: List<String>?,
    val maxLength: Int,
    val defaultJson: String,
)

/** A camera ladder's layer: its height in lines, its bitrate and frame rate. */
data class MeshLayer(val height: Int, val kbps: Int, val fps: Int)

/** One of `camera.codecRules`: the camera's codec list for the machines whose given fields all match. */
data class MeshCodecRule(val os: String?, val browser: String?, val gpu: String?, val device: String?, val camera: List<String>)

/** A node to measure the round trip to (`probe`, while `probe.enabled` is on for this client): one a region, its
 * origin over HTTP(S), whose `/mesh/ping` is measured. */
data class MeshProbeTarget(val region: String, val url: String)

/** A setting's value, as checked. */
sealed class MeshSettingValue {
    data class Number(val value: Double) : MeshSettingValue()
    data class Bool(val value: Boolean) : MeshSettingValue()
    data class Word(val value: String) : MeshSettingValue()
    data class Names(val value: List<String>) : MeshSettingValue()
    data class Numbers(val value: List<Int>) : MeshSettingValue()
    data class Layers(val value: List<MeshLayer>) : MeshSettingValue()
    data class CodecRules(val value: List<MeshCodecRule>) : MeshSettingValue()
}

/**
 * The settings a mesh node sent this client last ([Room.meshSettings]), each value checked against the schema, and
 * every key's default where the node set none.
 */
data class MeshSettings(
    /** The settings document's revision (0: the node holds none, and only overrides apply); the client reports it in
     * its health report (`cfg`). */
    val rev: Long,
    /** The revision's publish settings may reach a camera or screen already on, by a republish
     * ([republishDelayMs]); without it they wait for its next turn on. */
    val applyNow: Boolean,
    /** What the node set, checked: the keys this client knows, with values their keys take. */
    val values: Map<String, MeshSettingValue>,
    /** The nodes to measure the round trip to, one a region; empty unless `probe.enabled` is on for this client. */
    val probe: List<MeshProbeTarget>,
) {
    /** Whether the node set the key (a key at its default is not set). */
    fun isSet(key: String): Boolean = values.containsKey(key)

    /** Whether the server speaks for the key: it set it, or a settings document is in use ([rev] above 0), in which a
     * key it doesn't set is the schema's default. Without either, a product keeps its own value for the key, so a
     * client on a node with no document behaves as it did before it read settings. */
    fun speaks(key: String): Boolean = isSet(key) || rev > 0

    /** A key's value: the node's, or its default; null where the default is the client's own rule (null). */
    fun value(key: String): MeshSettingValue? = values[key] ?: MeshSettingsSchemaDefaults.defaults[key]

    fun number(key: String): Double? = (value(key) as? MeshSettingValue.Number)?.value
    fun int(key: String): Int? = number(key)?.roundToInt()
    fun bool(key: String): Boolean? = (value(key) as? MeshSettingValue.Bool)?.value
    fun word(key: String): String? = (value(key) as? MeshSettingValue.Word)?.value
    fun names(key: String): List<String>? = (value(key) as? MeshSettingValue.Names)?.value
    fun numbers(key: String): List<Int>? = (value(key) as? MeshSettingValue.Numbers)?.value
    fun layers(key: String): List<MeshLayer>? = (value(key) as? MeshSettingValue.Layers)?.value
    fun codecRules(key: String): List<MeshCodecRule>? = (value(key) as? MeshSettingValue.CodecRules)?.value

    /** The keys whose value (the node's or the default) differs from [other]'s. */
    fun changed(from: MeshSettings): Set<String> = (values.keys + from.values.keys).filter { value(it) != from.value(it) }.toSet()

    /** The live caps over the camera's encodings (`camera.capHeight`, `camera.capFps`, `camera.capKbps`), 0 for none. */
    val cameraCaps: MeshCaps
        get() = MeshCaps(
            height = (int("camera.capHeight") ?: 0).coerceAtLeast(0),
            fps = (int("camera.capFps") ?: 0).coerceAtLeast(0),
            kbps = (int("camera.capKbps") ?: 0).coerceAtLeast(0),
        )

    /** The reconnect waits (`reconnect.delaysMs`), for the room's reconnect policy. */
    val reconnectDelaysMs: List<Long>? get() = numbers("reconnect.delaysMs")?.map { it.toLong() }

    companion object {
        /** No settings from any node: every key at its default. */
        val NONE = MeshSettings(0, false, emptyMap(), emptyList())

        /** When a client takes a change of the key; null for a key this client doesn't know. */
        fun keyClass(key: String): MeshSettingClass? = MeshSettingsSchema.keys[key]?.keyClass

        /** The degradation preference a word of `camera.degradation` names, null for `default` (the publish's own). */
        fun degradation(word: String?): livekit.org.webrtc.RtpParameters.DegradationPreference? = when (word) {
            "balanced" -> livekit.org.webrtc.RtpParameters.DegradationPreference.BALANCED
            "maintain-framerate" -> livekit.org.webrtc.RtpParameters.DegradationPreference.MAINTAIN_FRAMERATE
            "maintain-resolution" -> livekit.org.webrtc.RtpParameters.DegradationPreference.MAINTAIN_RESOLUTION
            else -> null
        }

        /**
         * How long after a revision with `applyNow` this client re-publishes a camera or screen whose publish settings
         * it changed: a moment within 60 s by its identity's hash, so a room doesn't switch all at once.
         */
        fun republishDelayMs(identity: String): Long {
            var hash = 2_166_136_261L
            for (byte in identity.toByteArray(Charsets.UTF_8)) {
                hash = hash xor (byte.toLong() and 0xff)
                hash = (hash * 16_777_619L) and 0xffffffffL
            }
            return hash % 60_000L
        }

        /** The settings a message's JSON holds, each value checked; null when it isn't settings at all. */
        fun parse(json: String): MeshSettings? {
            if (json.length > 512 * 1024) return null
            val obj = try {
                Json.parseToJsonElement(json) as? JsonObject
            } catch (e: Exception) {
                null
            } ?: return null
            val revPrimitive = obj["rev"] as? JsonPrimitive ?: return null
            if (revPrimitive.isString || revPrimitive.booleanOrNull != null) return null
            val rev = revPrimitive.longOrNull ?: revPrimitive.doubleOrNull?.toLong() ?: return null
            val values = mutableMapOf<String, MeshSettingValue>()
            (obj["set"] as? JsonObject)?.forEach { (name, raw) ->
                val key = MeshSettingsSchema.keys[name] ?: return@forEach
                check(raw, key)?.let { values[name] = it }
            }
            val probe = mutableListOf<MeshProbeTarget>()
            (obj["probe"] as? JsonArray)?.take(16)?.forEach { entry ->
                val target = entry as? JsonObject ?: return@forEach
                val region = (target["region"] as? JsonPrimitive)?.takeIf { it.isString }?.content ?: return@forEach
                val url = (target["url"] as? JsonPrimitive)?.takeIf { it.isString }?.content?.let { probeOrigin(it) } ?: return@forEach
                if (isRegionName(region)) probe.add(MeshProbeTarget(region, url))
            }
            val applyNow = (obj["applyNow"] as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull == true
            return MeshSettings(rev.coerceAtLeast(0), applyNow, values, probe)
        }

        private fun numberOf(e: JsonElement?): Double? {
            val p = e as? JsonPrimitive ?: return null
            if (p.isString || p is JsonNull || p.booleanOrNull != null) return null
            return p.doubleOrNull?.takeIf { it.isFinite() }
        }

        /**
         * A value as its key takes it, or null where it doesn't (the default then applies): numbers held to the range,
         * whole where the key wants whole, a word of the key's in its spelling, codecs the client knows.
         */
        internal fun check(raw: JsonElement, key: MeshSettingKey): MeshSettingValue? {
            fun held(v: Double, whole: Boolean): Double {
                var out = if (whole) Math.round(v).toDouble() else v
                key.min?.let { out = maxOf(out, it) }
                key.max?.let { out = minOf(out, it) }
                return out
            }
            return when (key.type) {
                MeshSettingType.NUMBER, MeshSettingType.INT ->
                    numberOf(raw)?.let { MeshSettingValue.Number(held(it, key.type == MeshSettingType.INT)) }
                MeshSettingType.BOOL ->
                    (raw as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull?.let { MeshSettingValue.Bool(it) }
                MeshSettingType.ENUMERATION -> {
                    val word = (raw as? JsonPrimitive)?.takeIf { it.isString }?.content?.trim() ?: return null
                    key.values?.firstOrNull { it.equals(word, ignoreCase = true) }?.let { MeshSettingValue.Word(it) }
                }
                MeshSettingType.CODECS -> codecs(raw).takeIf { it.isNotEmpty() }?.let { MeshSettingValue.Names(it) }
                MeshSettingType.CODECRULES -> {
                    val list = raw as? JsonArray ?: return null
                    val rules = list.take(16).mapNotNull { entry ->
                        val rule = entry as? JsonObject ?: return@mapNotNull null
                        val camera = codecs(rule["camera"] ?: JsonArray(emptyList()))
                        if (camera.isEmpty()) return@mapNotNull null
                        fun word(name: String): String? = (rule[name] as? JsonPrimitive)?.takeIf { it.isString }?.content
                            ?.lowercase()?.trim()?.takeIf { it.isNotEmpty() && it.length <= 16 }
                        MeshCodecRule(word("os"), word("browser"), word("gpu"), word("device"), camera)
                    }
                    MeshSettingValue.CodecRules(rules)
                }
                MeshSettingType.LAYERS -> {
                    val list = raw as? JsonArray ?: return null
                    if (list.isEmpty() || (key.maxLength > 0 && list.size > key.maxLength)) return null
                    val layers = mutableListOf<MeshLayer>()
                    for (entry in list) {
                        val layer = entry as? JsonObject ?: return null
                        val h = numberOf(layer["h"]) ?: return null
                        val kbps = numberOf(layer["kbps"]) ?: return null
                        val fps = numberOf(layer["fps"]) ?: return null
                        val next = MeshLayer(
                            Math.round(h).toInt().coerceIn(90, 2160),
                            Math.round(kbps).toInt().coerceIn(30, 20000),
                            Math.round(fps).toInt().coerceIn(1, 60),
                        )
                        if (layers.isNotEmpty() && next.height <= layers.last().height) return null
                        layers.add(next)
                    }
                    MeshSettingValue.Layers(layers)
                }
                MeshSettingType.INTS -> {
                    val list = raw as? JsonArray ?: return null
                    if (list.isEmpty() || (key.maxLength > 0 && list.size > key.maxLength)) return null
                    val out = mutableListOf<Int>()
                    for (entry in list) out.add(held(numberOf(entry) ?: return null, whole = true).toInt())
                    MeshSettingValue.Numbers(out)
                }
            }
        }

        private val CODEC_NAMES = setOf("vp8", "h264", "h265", "vp9", "av1")

        /** 1 to 8 codecs the client knows (vp8, h264, h265, vp9, av1, each with :hw or not), in lower case, none twice. */
        internal fun codecs(raw: JsonElement): List<String> {
            val list = raw as? JsonArray ?: return emptyList()
            val out = mutableListOf<String>()
            for (entry in list) {
                val text = (entry as? JsonPrimitive)?.takeIf { it.isString }?.content ?: continue
                val name = text.lowercase().trim()
                val parts = name.split(":")
                if (parts[0] !in CODEC_NAMES || !(parts.size == 1 || (parts.size == 2 && parts[1] == "hw")) || name in out) continue
                out.add(name)
                if (out.size == 8) break
            }
            return out
        }

        internal fun isRegionName(s: String): Boolean =
            s.isNotEmpty() && s.length <= 40 && s.all { it in 'a'..'z' || it in '0'..'9' || it == '-' }

        /** A probe target's origin over HTTP(S): a node's signal URL (wss://...) or its origin as given. */
        internal fun probeOrigin(text: String): String? {
            val uri = try {
                URI(text)
            } catch (e: Exception) {
                return null
            }
            val host = uri.host?.takeIf { it.isNotEmpty() } ?: return null
            val scheme = when (uri.scheme?.lowercase()) {
                "wss", "https" -> "https"
                "ws", "http" -> "http"
                else -> return null
            }
            return if (uri.port > 0) "$scheme://$host:${uri.port}" else "$scheme://$host"
        }

        // Kept for the next connect

        /** How old the settings kept for a server may be when the next connect takes them. */
        const val KEPT_FOR_MS = 7L * 24 * 3600 * 1000

        private const val PREFERENCES = "wordplus-mesh"

        private fun keptName(url: String): String? = try {
            URI(url).host?.lowercase()?.let { "wordplus-mesh-settings:$it" }
        } catch (e: Exception) {
            null
        }

        /**
         * The settings this client last had from the server at [url], at most 7 days old: what a product connects with,
         * for the settings of the join and room classes, which a connect can't take from a node it hasn't reached yet.
         */
        fun cached(context: Context, url: String, now: Long = System.currentTimeMillis()): MeshSettings? {
            val name = keptName(url) ?: return null
            return try {
                val prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                val at = prefs.getLong("$name:at", -1)
                if (at < 0 || now - at > KEPT_FOR_MS || at > now + 60_000) null else prefs.getString(name, null)?.let { parse(it) }
            } catch (e: Exception) {
                null
            }
        }

        /** Keeps the settings the server at [url] sent, as it sent them. */
        internal fun keep(context: Context, json: String, url: String, now: Long = System.currentTimeMillis()) {
            val name = keptName(url) ?: return
            try {
                context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
                    .putString(name, json)
                    .putLong("$name:at", now)
                    .apply()
            } catch (e: Exception) {
                // a context with no preferences (a test's) keeps nothing
            }
        }
    }
}

/** Each key's default, read once from the schema compiled in. */
internal object MeshSettingsSchemaDefaults {
    val defaults: Map<String, MeshSettingValue> by lazy {
        MeshSettingsSchema.keys.mapNotNull { (name, key) ->
            val raw = try {
                Json.parseToJsonElement(key.defaultJson)
            } catch (e: Exception) {
                return@mapNotNull null
            }
            if (raw is JsonNull) null else MeshSettings.check(raw, key)?.let { name to it }
        }.toMap()
    }
}
