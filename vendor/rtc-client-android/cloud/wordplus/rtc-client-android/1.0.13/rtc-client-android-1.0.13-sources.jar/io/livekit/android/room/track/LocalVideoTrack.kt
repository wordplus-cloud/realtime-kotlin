/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room.track

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.livekit.android.memory.CloseableManager
import io.livekit.android.memory.SurfaceTextureHelperCloser
import io.livekit.android.room.DefaultsManager
import io.livekit.android.room.MeshSvcTrim
import io.livekit.android.room.track.video.CameraCapturerUtils
import io.livekit.android.room.track.video.CameraCapturerUtils.CameraDeviceInfo
import io.livekit.android.room.track.video.CameraCapturerUtils.createCameraEnumerator
import io.livekit.android.room.track.video.CameraCapturerUtils.findCamera
import io.livekit.android.room.track.video.CameraCapturerWithSize
import io.livekit.android.room.track.video.CaptureDispatchObserver
import io.livekit.android.room.track.video.ScaleCropVideoProcessor
import io.livekit.android.room.track.video.VideoCapturerWithSize
import io.livekit.android.room.util.EncodingUtils
import io.livekit.android.util.FlowObservable
import io.livekit.android.util.LKLog
import io.livekit.android.util.flowDelegate
import io.livekit.android.webrtc.peerconnection.RTCThreadToken
import livekit.LivekitRtc
import livekit.LivekitRtc.SubscribedCodec
import livekit.org.webrtc.CameraVideoCapturer
import livekit.org.webrtc.CameraVideoCapturer.CameraEventsHandler
import livekit.org.webrtc.EglBase
import livekit.org.webrtc.MediaStreamTrack
import livekit.org.webrtc.PeerConnectionFactory
import livekit.org.webrtc.RtpParameters
import livekit.org.webrtc.RtpSender
import livekit.org.webrtc.RtpTransceiver
import livekit.org.webrtc.SurfaceTextureHelper
import livekit.org.webrtc.VideoCapturer
import livekit.org.webrtc.VideoProcessor
import livekit.org.webrtc.VideoSink
import livekit.org.webrtc.VideoSource
import java.util.UUID
import livekit.LivekitModels.VideoQuality as ProtoVideoQuality

/**
 * A representation of a local video track (generally input coming from camera or screen).
 *
 * [startCapture] should be called before use.
 */
open class LocalVideoTrack
@AssistedInject
constructor(
    @Assisted capturer: VideoCapturer,
    @Assisted private var source: VideoSource,
    @Assisted name: String,
    @Assisted options: LocalVideoTrackOptions,
    @Assisted rtcTrack: livekit.org.webrtc.VideoTrack,
    private val peerConnectionFactory: PeerConnectionFactory,
    private val context: Context,
    private val eglBase: EglBase,
    private val defaultsManager: DefaultsManager,
    private val trackFactory: Factory,
    /**
     * If this is assigned, you must ensure that this observer is associated with the [capturer],
     * as this will be used to receive frames in [addRenderer].
     **/
    @Assisted private var dispatchObserver: CaptureDispatchObserver? = null,
    rtcThreadToken: RTCThreadToken,
) : VideoTrack(name, rtcTrack, rtcThreadToken) {

    var capturer = capturer
        private set

    override var rtcTrack: livekit.org.webrtc.VideoTrack = rtcTrack
        internal set

    internal var codec: String? = null
    private var subscribedCodecs: List<SubscribedCodec>? = null
    private val simulcastCodecs = mutableMapOf<VideoCodec, SimulcastTrackInfo>()

    @FlowObservable
    @get:FlowObservable
    var options: LocalVideoTrackOptions by flowDelegate(options)

    val dimensions: Dimensions
        get() {
            (capturer as? VideoCapturerWithSize)?.let { capturerWithSize ->
                val size = capturerWithSize.findCaptureFormat(
                    options.captureParams.width,
                    options.captureParams.height,
                )
                return Dimensions(size.width, size.height)
            }
            return Dimensions(options.captureParams.width, options.captureParams.height)
        }

    internal var transceiver: RtpTransceiver? = null
    internal val sender: RtpSender?
        get() = transceiver?.sender

    /**
     * The transceivers created for additional backup codecs (e.g. when using SVC with a backup codec).
     */
    internal val simulcastTransceivers: List<RtpTransceiver>
        get() = simulcastCodecs.values.mapNotNull { it.transceiver }

    /**
     * WordPlus Mesh (1.0.2): the senders whose encoders a mesh node is told of, this track's own and each backup codec's
     * with its name.
     */
    internal fun meshSenders(): List<Pair<RtpSender, String?>> =
        listOfNotNull(sender?.let { it to null }) +
            simulcastCodecs.mapNotNull { (codec, info) -> info.sender?.let { it to codec.codecName } }

    internal val closeableManager = CloseableManager()

    /**
     * Starts the [capturer] with the capture params contained in [options].
     */
    open fun startCapture() {
        capturer.startCapture(
            options.captureParams.width,
            options.captureParams.height,
            options.captureParams.maxFps,
        )
    }

    /**
     * Stops the [capturer].
     */
    open fun stopCapture() {
        capturer.stopCapture()
    }

    override fun stop() {
        capturer.stopCapture()
        super.stop()
    }

    override fun dispose() {
        super.dispose()
        capturer.dispose()
        source.dispose()
        closeableManager.close()
    }

    override fun addRenderer(renderer: VideoSink) {
        if (dispatchObserver != null) {
            dispatchObserver?.registerSink(renderer)
        } else {
            super.addRenderer(renderer)
        }
    }

    override fun removeRenderer(renderer: VideoSink) {
        if (dispatchObserver != null) {
            dispatchObserver?.unregisterSink(renderer)
        } else {
            super.removeRenderer(renderer)
        }
    }

    /**
     * If this is a camera track, switches to the new camera determined by [deviceId]
     */
    @Deprecated("Use LocalVideoTrack.switchCamera instead.", ReplaceWith("switchCamera(deviceId = deviceId)"))
    fun setDeviceId(deviceId: String) {
        restartTrack(options.copy(deviceId = deviceId))
    }

    /**
     * Switch to a different camera. Only works if this track is backed by a camera capturer.
     *
     * If neither deviceId or position is provided, or the specified camera cannot be found,
     * this will switch to the next camera, if one is available.
     */
    fun switchCamera(deviceId: String? = null, position: CameraPosition? = null) {
        val cameraCapturer = capturer as? CameraVideoCapturer ?: run {
            LKLog.w { "Attempting to switch camera on a non-camera video track!" }
            return
        }

        var targetDevice: CameraDeviceInfo? = null
        val enumerator = createCameraEnumerator(context)
        if (deviceId != null || position != null) {
            targetDevice = enumerator.findCamera(deviceId, position, fallback = false)
        }

        if (targetDevice == null) {
            val deviceNames = enumerator.deviceNames
            if (deviceNames.size < 2) {
                LKLog.w { "No available cameras to switch to!" }
                return
            }
            val currentIndex = deviceNames.indexOf(options.deviceId)
            val targetDeviceId = deviceNames[(currentIndex + 1) % deviceNames.size]
            targetDevice = enumerator.findCamera(targetDeviceId, fallback = false)
        }

        val targetDeviceId = targetDevice?.deviceId
        fun updateCameraOptions() {
            val newOptions = options.copy(
                deviceId = targetDeviceId,
                position = targetDevice?.position,
            )
            options = newOptions
        }

        val cameraSwitchHandler = object : CameraVideoCapturer.CameraSwitchHandler {
            override fun onCameraSwitchDone(isFrontFacing: Boolean) {
                // For cameras we control, wait until the first frame to ensure everything is okay.
                if (cameraCapturer is CameraCapturerWithSize) {
                    cameraCapturer.cameraEventsDispatchHandler
                        .registerHandler(
                            object : CameraEventsHandler {
                                override fun onFirstFrameAvailable() {
                                    updateCameraOptions()
                                    cameraCapturer.cameraEventsDispatchHandler.unregisterHandler(this)
                                }

                                override fun onCameraError(p0: String?) {
                                    cameraCapturer.cameraEventsDispatchHandler.unregisterHandler(this)
                                }

                                override fun onCameraDisconnected() {
                                    cameraCapturer.cameraEventsDispatchHandler.unregisterHandler(this)
                                }

                                override fun onCameraFreezed(p0: String?) {
                                }

                                override fun onCameraOpening(p0: String?) {
                                }

                                override fun onCameraClosed() {
                                    cameraCapturer.cameraEventsDispatchHandler.unregisterHandler(this)
                                }
                            },
                        )
                } else {
                    updateCameraOptions()
                }
            }

            override fun onCameraSwitchError(errorDescription: String?) {
                LKLog.w { "switching camera failed: $errorDescription" }
            }
        }
        if (targetDevice == null) {
            LKLog.w { "No target camera found!" }
            return
        } else {
            cameraCapturer.switchCamera(cameraSwitchHandler, targetDeviceId)
        }
    }

    /**
     * Restart a track with new options.
     */
    fun restartTrack(
        options: LocalVideoTrackOptions = defaultsManager.videoTrackCaptureDefaults.copy(),
        videoProcessor: VideoProcessor? = null
    ) {
        if (isDisposed) {
            LKLog.e { "Attempting to restart track that was already disposed, aborting." }
            return
        }

        val oldCapturer = capturer
        val oldSource = source
        val oldRtcTrack = rtcTrack

        oldCapturer.stopCapture()
        oldCapturer.dispose()
        oldSource.dispose()

        oldRtcTrack.setEnabled(false)

        // We always own our copy of rtcTrack, so we need to dispose it.
        // Note: For the first rtcTrack we pass to the PeerConnection, PeerConnection actually
        // passes it down to the native, and then ends up holding onto a separate copy at the
        // Java layer. This means our initial rtcTrack isn't owned by PeerConnection, and is
        // our responsibility to dispose.
        oldRtcTrack.dispose()

        // Close resources associated to the old track. new track resources is registered in createTrack.
        val oldCloseable = closeableManager.unregisterResource(oldRtcTrack)
        oldCloseable?.close()

        val newTrack = createCameraTrack(
            peerConnectionFactory,
            context,
            name,
            options,
            eglBase,
            trackFactory,
            videoProcessor
        )

        // migrate video sinks to the new track
        for (sink in sinks) {
            oldRtcTrack.removeSink(sink)
            newTrack.addRenderer(sink)
        }

        capturer = newTrack.capturer
        source = newTrack.source
        rtcTrack = newTrack.rtcTrack
        this.options = options
        startCapture()
        sender?.setTrack(newTrack.rtcTrack, false)
    }

    internal fun setPublishingLayers(
        qualities: List<LivekitRtc.SubscribedQuality>,
    ) {
        val sender = transceiver?.sender ?: return

        setPublishingLayersForSender(sender, qualities)
    }

    /** WordPlus Mesh (1.0.9): dynacast's last word for each sender, and the layers the live caps turned off, by its id. */
    private val meshQualities = mutableMapOf<String, List<LivekitRtc.SubscribedQuality>>()
    private val meshCappedOff = mutableMapOf<String, Set<String>>()

    /**
     * WordPlus Mesh (1.0.10): whether the room's settings trim this camera's SVC sizes to its viewers (`camera.svcTrim`,
     * [setMeshSvcTrim]), the mode and scale each sender's one SVC encoding went out with before a trim, by its id, and
     * the senders whose WebRTC kept its mode, which go out whole from then on.
     */
    @Volatile
    private var meshSvcTrim = false
    private val svcWhole = mutableMapOf<String, MeshSvcTrim.Whole>()
    private val svcRefused = mutableSetOf<String>()

    /**
     * WordPlus Mesh (1.0.10): a camera sent as one SVC stream (VP9, AV1) sends only the sizes up to the largest its
     * viewers ask for, while the room's settings say so (`camera.svcTrim`; better-messages-server infra/SVC-TRIM.md), as
     * the browser client does (@wordplus/rtc-client 1.0.24): 360p asked of a 720p camera in L3T3_KEY sends L2T3_KEY of
     * half the picture, 180p L1T3 of a quarter. Turned off, it goes out whole again at once. A screen is never trimmed.
     */
    internal fun setMeshSvcTrim(on: Boolean) {
        if (on == meshSvcTrim) return
        meshSvcTrim = on
        val sender = this.sender ?: return
        val last = synchronized(meshQualities) { meshQualities[sender.id()] } ?: return
        setPublishingLayersForSender(sender, last)
    }

    /** The mode and scale a sender's one SVC encoding should go out in for the largest quality asked; null to leave it. */
    private fun svcPlan(id: String, encoding: RtpParameters.Encoding, highest: Int): MeshSvcTrim.Plan? = synchronized(meshQualities) {
        val mode = encoding.scalabilityMode ?: return@synchronized null
        if (!meshSvcTrim || options.isScreencast || id in svcRefused) {
            // whole again after a trim, once off
            val whole = svcWhole.remove(id) ?: return@synchronized null
            return@synchronized MeshSvcTrim.Plan(whole.mode, whole.scale, MeshSvcTrim.spatial(whole.mode))
        }
        val whole = svcWhole.getOrPut(id) { MeshSvcTrim.Whole(mode, encoding.scaleResolutionDownBy) }
        MeshSvcTrim.plan(whole, highest)
    }

    /**
     * WordPlus Mesh (1.0.9): holds this camera's senders to the live caps ([io.livekit.android.room.MeshCaps]): each
     * sender's encodings computed again by [encodingsFor] (null: the main sender's, else a backup codec's) under the
     * caps, then dynacast's last word on top, so a layer nobody watches stays paused and one the caps turned off stays
     * off. Caps lifted, the senders go back to what their options compute.
     */
    internal fun applyMeshCaps(caps: io.livekit.android.room.MeshCaps, encodingsFor: (String?) -> List<RtpParameters.Encoding>?) {
        if (isDisposed) return
        val lines = minOf(dimensions.width, dimensions.height)
        val senders = listOfNotNull(sender?.let { null as String? to it }) +
            simulcastCodecs.mapNotNull { (codec, info) -> info.sender?.let { codec.codecName to it } }
        for ((codec, sender) in senders) {
            val base = encodingsFor(codec) ?: continue
            val off = caps.apply(base, lines)
            try {
                val id = sender.id()
                synchronized(meshQualities) { meshCappedOff[id] = off }
                val parameters = sender.parameters ?: continue
                val encodings = parameters.encodings ?: continue
                encodings.forEachIndexed { index, current ->
                    val updated = base.firstOrNull { it.rid != null && it.rid == current.rid } ?: base.getOrNull(index)?.takeIf { base.size == encodings.size }
                        ?: return@forEachIndexed
                    current.scaleResolutionDownBy = updated.scaleResolutionDownBy
                    current.maxBitrateBps = updated.maxBitrateBps
                    current.maxFramerate = updated.maxFramerate
                    current.active = updated.active
                }
                // 1.0.10: a camera in one SVC stream goes out whole under the caps, a trim over that (setMeshSvcTrim),
                // which dynacast's last word below gives back
                if (encodings.size == 1) {
                    synchronized(meshQualities) { svcWhole[id]?.let { svcWhole[id] = it.copy(scale = encodings[0].scaleResolutionDownBy) } }
                }
                sender.parameters = parameters
                synchronized(meshQualities) { meshQualities[id] }?.let { setPublishingLayersForSender(sender, it) }
            } catch (e: Exception) {
                LKLog.w(e) { "could not hold the camera to its caps" }
            }
        }
    }

    private fun setPublishingLayersForSender(
        sender: RtpSender,
        qualities: List<LivekitRtc.SubscribedQuality>,
    ) {
        if (isDisposed) {
            LKLog.i { "attempted to set publishing layer for disposed video track." }
            return
        }
        try {
            // WordPlus Mesh (1.0.9): the last word kept for the caps, and a layer the caps turned off stays off
            val cappedOff = synchronized(meshQualities) {
                val id = sender.id()
                meshQualities[id] = qualities
                meshCappedOff[id] ?: emptySet()
            }
            val parameters = sender.parameters ?: return
            val encodings = parameters.encodings ?: return
            var hasChanged = false
            var trimmedTo: String? = null

            if (encodings.firstOrNull()?.scalabilityMode != null) {
                val encoding = encodings.first()
                var maxQuality = ProtoVideoQuality.OFF
                for (quality in qualities) {
                    if (quality.enabled && (maxQuality == ProtoVideoQuality.OFF || quality.quality.number > maxQuality.number)) {
                        maxQuality = quality.quality
                    }
                }

                if (maxQuality == ProtoVideoQuality.OFF) {
                    if (encoding.active) {
                        LKLog.v { "setting svc track to disabled" }
                        encoding.active = false
                        hasChanged = true
                    }
                } else if (!encoding.active) {
                    LKLog.v { "setting svc track to enabled" }
                    encoding.active = true
                    hasChanged = true
                }
                // WordPlus Mesh (1.0.10): the sizes up to the largest asked while camera.svcTrim is on, whole again once
                // off; a stream turned off keeps its sizes, so it comes back on in one change
                if (maxQuality != ProtoVideoQuality.OFF && encodings.size == 1) {
                    svcPlan(sender.id(), encoding, maxQuality.number)?.let { plan ->
                        if (encoding.scalabilityMode != plan.mode) {
                            encoding.scalabilityMode = plan.mode
                            trimmedTo = plan.mode
                            hasChanged = true
                        }
                        if (encoding.scaleResolutionDownBy != plan.scale) {
                            encoding.scaleResolutionDownBy = plan.scale
                            hasChanged = true
                        }
                    }
                }
            } else {
                // simulcast dynacast encodings
                for (quality in qualities) {
                    val rid = EncodingUtils.ridForVideoQuality(quality.quality) ?: continue
                    val encoding = encodings.firstOrNull { it.rid == rid }
                        // use low quality layer settings for non-simulcasted streams
                        ?: encodings.takeIf { it.size == 1 && quality.quality == ProtoVideoQuality.LOW }?.first()
                        ?: continue
                    val enabled = quality.enabled && rid !in cappedOff
                    if (encoding.active != enabled) {
                        hasChanged = true
                        encoding.active = enabled
                        LKLog.v { "setting layer ${quality.quality} to $enabled" }
                    }
                }
            }

            if (hasChanged) {
                // This refreshes the native code with the new information
                sender.parameters = parameters
                // WordPlus Mesh (1.0.10): a WebRTC that keeps its mode sends this camera whole from then on
                val asked = trimmedTo
                if (asked != null) {
                    val kept = sender.parameters?.encodings?.firstOrNull()?.scalabilityMode
                    val refusedNow = kept != null && kept != asked && synchronized(meshQualities) { svcRefused.add(sender.id()) }
                    if (refusedNow) {
                        LKLog.w { "WebRTC kept its SVC mode for $asked: the camera goes out whole" }
                        setPublishingLayersForSender(sender, qualities)
                    }
                }
            }
        } catch (e: Exception) {
            LKLog.w(e) { "Exception caught while setting publishing layers." }
            return
        }
    }

    internal fun setPublishingCodecs(codecs: List<SubscribedCodec>): List<VideoCodec> {
        LKLog.v { "setting publishing codecs: $codecs" }

        // only enable simulcast codec for preferred codec set
        if (this.codec == null && codecs.isNotEmpty()) {
            setPublishingLayers(codecs.first().qualitiesList)
            return emptyList()
        }

        this.subscribedCodecs = codecs

        val newCodecs = mutableListOf<VideoCodec>()

        for (codec in codecs) {
            if (this.codec == codec.codec) {
                setPublishingLayers(codec.qualitiesList)
            } else {
                val videoCodec = try {
                    VideoCodec.fromCodecName(codec.codec)
                } catch (e: Exception) {
                    LKLog.w { "unknown publishing codec ${codec.codec}!" }
                    continue
                }

                LKLog.d { "try setPublishingCodec for ${codec.codec}" }
                val simulcastInfo = this.simulcastCodecs[videoCodec]
                if (simulcastInfo?.sender == null) {
                    for (q in codec.qualitiesList) {
                        if (q.enabled) {
                            newCodecs.add(videoCodec)
                            break
                        }
                    }
                } else {
                    LKLog.d { "try setPublishingLayersForSender ${codec.codec}" }
                    setPublishingLayersForSender(
                        simulcastInfo.sender!!,
                        codec.qualitiesList,
                    )
                }
            }
        }
        return newCodecs
    }

    internal fun addSimulcastTrack(codec: VideoCodec, encodings: List<RtpParameters.Encoding>): SimulcastTrackInfo? {
        if (this.simulcastCodecs.containsKey(codec)) {
            LKLog.w { "$codec already added, skipping." }
            return null
        }
        val simulcastTrackInfo = SimulcastTrackInfo(
            codec = codec.codecName,
            rtcTrack = rtcTrack,
            encodings = encodings,
        )
        simulcastCodecs[codec] = simulcastTrackInfo
        return simulcastTrackInfo
    }

    /**
     * Clears the backup codec state so it is re-established from scratch on the next publish,
     * rather than reusing senders whose transceivers were stopped on unpublish.
     */
    internal fun clearSimulcastCodecs() {
        subscribedCodecs = null
        simulcastCodecs.clear()
    }

    @AssistedFactory
    interface Factory {
        fun create(
            capturer: VideoCapturer,
            source: VideoSource,
            name: String,
            options: LocalVideoTrackOptions,
            rtcTrack: livekit.org.webrtc.VideoTrack,
            dispatchObserver: CaptureDispatchObserver?,
        ): LocalVideoTrack
    }

    companion object {

        internal fun createCameraTrack(
            peerConnectionFactory: PeerConnectionFactory,
            context: Context,
            name: String,
            options: LocalVideoTrackOptions,
            rootEglBase: EglBase,
            trackFactory: Factory,
            videoProcessor: VideoProcessor? = null,
        ): LocalVideoTrack {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                throw SecurityException("Camera permissions are required to create a camera video track.")
            }

            val (capturer, newOptions) = CameraCapturerUtils.createCameraCapturer(context, options) ?: TODO()

            return createTrack(
                peerConnectionFactory = peerConnectionFactory,
                context = context,
                name = name,
                capturer = capturer,
                options = newOptions,
                rootEglBase = rootEglBase,
                trackFactory = trackFactory,
                videoProcessor = videoProcessor,
            )
        }

        internal fun createTrack(
            peerConnectionFactory: PeerConnectionFactory,
            context: Context,
            name: String,
            capturer: VideoCapturer,
            options: LocalVideoTrackOptions = LocalVideoTrackOptions(),
            rootEglBase: EglBase,
            trackFactory: Factory,
            videoProcessor: VideoProcessor? = null,
        ): LocalVideoTrack {
            val source = peerConnectionFactory.createVideoSource(options.isScreencast)

            val finalVideoProcessor = if (options.captureParams.adaptOutputToDimensions) {
                ScaleCropVideoProcessor(
                    targetWidth = options.captureParams.width,
                    targetHeight = options.captureParams.height,
                ).apply {
                    childVideoProcessor = videoProcessor
                }
            } else {
                videoProcessor
            }
            source.setVideoProcessor(finalVideoProcessor)

            val surfaceTextureHelper = SurfaceTextureHelper.create("VideoCaptureThread", rootEglBase.eglBaseContext)

            // Dispatch raw frames to local renderer only if not using a user-provided VideoProcessor.
            val dispatchObserver = if (videoProcessor == null) {
                CaptureDispatchObserver().apply {
                    registerObserver(source.capturerObserver)
                }
            } else {
                null
            }

            capturer.initialize(
                surfaceTextureHelper,
                context,
                dispatchObserver ?: source.capturerObserver,
            )
            val rtcTrack = peerConnectionFactory.createVideoTrack(UUID.randomUUID().toString(), source)

            val track = trackFactory.create(
                capturer = capturer,
                source = source,
                options = options,
                name = name,
                rtcTrack = rtcTrack,
                dispatchObserver = dispatchObserver,
            )

            track.closeableManager.registerResource(
                rtcTrack,
                SurfaceTextureHelperCloser(surfaceTextureHelper),
            )
            return track
        }
    }
}

internal data class SimulcastTrackInfo(
    var codec: String,
    var rtcTrack: MediaStreamTrack,
    var sender: RtpSender? = null,
    var transceiver: RtpTransceiver? = null,
    var encodings: List<RtpParameters.Encoding>? = null,
)
