/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import livekit.org.webrtc.RtpParameters
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * WordPlus Mesh (1.0.9): the live caps over a camera's encodings (`camera.capHeight`, `camera.capFps`,
 * `camera.capKbps`; 0 for none), which the server sets for one person, a room or a kind of device, and which reach a
 * running camera at once, with no republish: no layer taller than the height (scaled down to it, or turned off when a
 * lower layer already comes near it), none faster than the frame rate, none spending more than the bitrate. The room
 * holds them over every camera it publishes, whatever its publish options or dynacast say after.
 */
data class MeshCaps(val height: Int = 0, val fps: Int = 0, val kbps: Int = 0) {
    val isEmpty: Boolean get() = height <= 0 && fps <= 0 && kbps <= 0

    /** Both caps at once: each the stricter of the two where either sets it (the server's and the product's own,
     * [Room.setProductCameraCaps]). */
    fun combined(other: MeshCaps): MeshCaps {
        fun stricter(a: Int, b: Int) = if (a > 0 && b > 0) min(a, b) else max(max(a, b), 0)
        return MeshCaps(stricter(height, other.height), stricter(fps, other.fps), stricter(kbps, other.kbps))
    }

    /**
     * Holds encodings computed for a camera of [lines] (its capture's shorter side) to the caps, in place, and answers
     * the rids it turned off, which dynacast must leave off. A layer scaled down spends its bitrate scaled with it, as
     * the ladder's own layers do (by the height's ratio to the power 1.5).
     */
    fun apply(encodings: List<RtpParameters.Encoding>, lines: Int): Set<String> {
        if (isEmpty || encodings.isEmpty() || lines <= 0) return emptySet()
        val off = mutableSetOf<String>()
        if (height > 0) {
            val source = lines.toDouble()
            fun layerOf(e: RtpParameters.Encoding) = source / max(e.scaleResolutionDownBy ?: 1.0, 1.0)
            val kept = mutableListOf<Double>()
            for (encoding in encodings.sortedBy { layerOf(it) }) {
                val layer = layerOf(encoding)
                if (layer <= height) {
                    kept.add(layer)
                    continue
                }
                val rid = encoding.rid
                if (rid != null && kept.any { it >= height * COVERS }) {
                    encoding.active = false
                    off.add(rid)
                    continue
                }
                encoding.scaleResolutionDownBy = source / height
                encoding.maxBitrateBps?.let { encoding.maxBitrateBps = (it * (height / layer).pow(1.5)).toInt() }
                kept.add(height.toDouble())
            }
        }
        if (fps > 0) {
            for (encoding in encodings) {
                val now = encoding.maxFramerate ?: 0
                encoding.maxFramerate = if (now > 0) min(now, fps) else fps
            }
        }
        if (kbps > 0) {
            for (encoding in encodings) {
                val now = encoding.maxBitrateBps ?: 0
                encoding.maxBitrateBps = if (now > 0) min(now, kbps * 1000) else kbps * 1000
            }
        }
        return off
    }

    companion object {
        /** A lower layer at least this share of the height covers the cap: the layer above goes off rather than being
         * scaled down onto it. */
        const val COVERS = 0.95
    }
}
