/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated from WordPlus Mesh's pkg/clientsettings/schema.json (version 1) by clients/settings-schema.mjs:
// don't edit, regenerate.

package io.livekit.android.room

internal object MeshSettingsSchema {
    const val VERSION = 1

    val keys: Map<String, MeshSettingKey> = mapOf(
        "camera.codecs" to MeshSettingKey(MeshSettingType.CODECS, MeshSettingClass.PUBLISH, null, null, null, 0, """["h264:hw","vp8"]"""),
        "camera.codecRules" to MeshSettingKey(MeshSettingType.CODECRULES, MeshSettingClass.PUBLISH, null, null, null, 0, """null"""),
        "camera.backup" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.PUBLISH, null, null, listOf("vp8", "h264"), 0, """"vp8""""),
        "screen.codecs" to MeshSettingKey(MeshSettingType.CODECS, MeshSettingClass.PUBLISH, null, null, null, 0, """null"""),
        "check.enabled" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.PUBLISH, null, null, null, 0, """true"""),
        "adapt.enabled" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.LIVE, null, null, null, 0, """true"""),
        "tune.checkMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 2000.0, 5000.0, null, 0, """4000"""),
        "tune.passSent" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.PUBLISH, 0.3, 1.0, null, 0, """0.8"""),
        "tune.passCpu" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.PUBLISH, 0.0, 1.0, null, 0, """0.5"""),
        "tune.passEncode" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.PUBLISH, 0.1, 1.0, null, 0, """0.6"""),
        "tune.dropWatchS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 10.0, 120.0, null, 0, """30"""),
        "tune.cpuWatchS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 10.0, 120.0, null, 0, """20"""),
        "tune.cpuShare" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.LIVE, 0.1, 1.0, null, 0, """0.5"""),
        "tune.switchesMax" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 3.0, null, 0, """2"""),
        "tune.switchGapS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 30.0, 1800.0, null, 0, """120"""),
        "tune.warmupS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 10.0, 300.0, null, 0, """30"""),
        "tune.failsafeS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 3.0, 30.0, null, 0, """10"""),
        "tune.republishTimeoutS" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 3.0, 30.0, null, 0, """8"""),
        "tune.rememberPassDays" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 90.0, null, 0, """30"""),
        "tune.rememberDropsDays" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 90.0, null, 0, """30"""),
        "tune.rememberCpuDays" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 90.0, null, 0, """7"""),
        "tune.forgetBefore" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 4503599627370496.0, null, 0, """0"""),
        "camera.ladder.1080" to MeshSettingKey(MeshSettingType.LAYERS, MeshSettingClass.PUBLISH, null, null, null, 3, """[{"h":270,"kbps":400,"fps":30},{"h":540,"kbps":1200,"fps":30}]"""),
        "camera.ladder.720" to MeshSettingKey(MeshSettingType.LAYERS, MeshSettingClass.PUBLISH, null, null, null, 3, """[{"h":180,"kbps":200,"fps":30},{"h":360,"kbps":600,"fps":30}]"""),
        "camera.topKbps.h264.1080" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """3500"""),
        "camera.topKbps.h264.720" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """1800"""),
        "camera.topKbps.vp8.1080" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """4000"""),
        "camera.topKbps.vp8.720" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """2000"""),
        "camera.topKbps.vp9.1080" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """2800"""),
        "camera.topKbps.vp9.720" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """1400"""),
        "camera.topKbps.av1.1080" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """2400"""),
        "camera.topKbps.av1.720" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """1200"""),
        "camera.topKbps.h265.1080" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """2500"""),
        "camera.topKbps.h265.720" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 300.0, 20000.0, null, 0, """1300"""),
        "camera.fps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 5.0, 60.0, null, 0, """30"""),
        "camera.svcMode" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.PUBLISH, null, null, listOf("L3T3_KEY", "L3T3", "L2T3_KEY", "L2T2_KEY", "L1T3", "L1T2"), 0, """"L3T3_KEY""""),
        "camera.svcTrim" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.LIVE, null, null, null, 0, """false"""),
        "camera.maxHeight.hw" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 360.0, 2160.0, null, 0, """1080"""),
        "camera.maxHeight.sw" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 360.0, 2160.0, null, 0, """720"""),
        "camera.vp9FullHdAfterCheck" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.PUBLISH, null, null, null, 0, """true"""),
        "camera.captureHeight" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.CAPTURE, 360.0, 2160.0, null, 0, """1080"""),
        "camera.captureFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.CAPTURE, 5.0, 60.0, null, 0, """30"""),
        "camera.minFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.CAPTURE, 0.0, 60.0, null, 0, """24"""),
        "camera.degradation" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.LIVE, null, null, listOf("default", "balanced", "maintain-framerate", "maintain-resolution"), 0, """"default""""),
        "camera.capHeight" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 2160.0, null, 0, """0"""),
        "camera.capFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 60.0, null, 0, """0"""),
        "camera.capKbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 20000.0, null, 0, """0"""),
        "screen.maxKbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 500.0, 20000.0, null, 0, """10000"""),
        "screen.fps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 60.0, null, 0, """30"""),
        "screen.contentHint" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.LIVE, null, null, listOf("motion", "detail", "text"), 0, """"motion""""),
        "screen.degradation" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.LIVE, null, null, listOf("default", "balanced", "maintain-framerate", "maintain-resolution"), 0, """"maintain-resolution""""),
        "screen.simulcastFromWidth" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 0.0, 7680.0, null, 0, """1280"""),
        "screen.simulcastFromHeight" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 0.0, 4320.0, null, 0, """640"""),
        "screen.lowLayerKbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 100.0, 10000.0, null, 0, """1500"""),
        "screen.lowLayerFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 1.0, 60.0, null, 0, """15"""),
        "screen.vp8Simulcast" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.PUBLISH, null, null, null, 0, """false"""),
        "screen.captureHeight" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.CAPTURE, 360.0, 2160.0, null, 0, """1080"""),
        "screen.captureFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.CAPTURE, 5.0, 60.0, null, 0, """30"""),
        "mic.kbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 16.0, 256.0, null, 0, """64"""),
        "mic.red" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.PUBLISH, null, null, null, 0, """true"""),
        "mic.dtx" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.PUBLISH, null, null, null, 0, """true"""),
        "mic.echoCancellation" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.CAPTURE, null, null, null, 0, """true"""),
        "mic.noiseSuppression" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.CAPTURE, null, null, null, 0, """true"""),
        "mic.autoGainControl" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.CAPTURE, null, null, null, 0, """true"""),
        "mic.voiceIsolation" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.CAPTURE, null, null, null, 0, """true"""),
        "screenAudio.kbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 32.0, 320.0, null, 0, """128"""),
        "view.pixelDensityMax" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.LIVE, 1.0, 3.0, null, 0, """1.5"""),
        "view.pauseHiddenAfterMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 60000.0, null, 0, """5000"""),
        "view.hiddenKeepsLowest" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.LIVE, null, null, null, 0, """false"""),
        "playout.jitterMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 2000.0, null, 0, """150"""),
        "playout.tickMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 500.0, 10000.0, null, 0, """2000"""),
        "playout.slackMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 1000.0, null, 0, """100"""),
        "playout.stepMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 5.0, 500.0, null, 0, """20"""),
        "playout.maxHoldMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 10000.0, null, 0, """4000"""),
        "lipsync.toleranceMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 200.0, null, 0, """10"""),
        "lipsync.samples" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 10.0, null, 0, """2"""),
        "lipsync.gain" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.LIVE, 0.1, 1.0, null, 0, """0.7"""),
        "lipsync.maxStepMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 5.0, 500.0, null, 0, """80"""),
        "watch.everyMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1000.0, 60000.0, null, 0, """5000"""),
        "watch.warmups" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 10.0, null, 0, """2"""),
        "watch.dropShare" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.LIVE, 0.1, 1.0, null, 0, """0.7"""),
        "watch.minCapturedFps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 60.0, null, 0, """5"""),
        "watch.maxEncodeMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 5.0, 200.0, null, 0, """25"""),
        "watch.minTargetKbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 5000.0, null, 0, """100"""),
        "watch.minSent" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.LIVE, 0.0, 1.0, null, 0, """0.25"""),
        "watch.idleEndMin" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 120.0, null, 0, """10"""),
        "check.connectMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 500.0, 5000.0, null, 0, """1500"""),
        "check.warmupMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 0.0, 2000.0, null, 0, """400"""),
        "check.keepUpMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 0.0, 2000.0, null, 0, """500"""),
        "check.windowMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 500.0, 5000.0, null, 0, """1200"""),
        "check.minFrames" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 1.0, 60.0, null, 0, """6"""),
        "check.bandwidthShare" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.PUBLISH, 0.1, 1.0, null, 0, """0.5"""),
        "check.pollMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 20.0, 1000.0, null, 0, """100"""),
        "check.headroom" to MeshSettingKey(MeshSettingType.NUMBER, MeshSettingClass.PUBLISH, 0.1, 1.0, null, 0, """0.8"""),
        "check.fallbackKbps" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.PUBLISH, 100.0, 10000.0, null, 0, """1500"""),
        "connect.signalTimeoutMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.JOIN, 5000.0, 60000.0, null, 0, """20000"""),
        "connect.pcTimeoutMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.JOIN, 5000.0, 60000.0, null, 0, """20000"""),
        "connect.joinBudgetMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.JOIN, 30000.0, 600000.0, null, 0, """300000"""),
        "connect.giveUpMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.JOIN, 5000.0, 120000.0, null, 0, """20000"""),
        "reconnect.delaysMs" to MeshSettingKey(MeshSettingType.INTS, MeshSettingClass.JOIN, 0.0, 60000.0, null, 20, """[0,300,1200,2700,4800,7000,7000,7000,7000,7000]"""),
        "ice.transportPolicy" to MeshSettingKey(MeshSettingType.ENUMERATION, MeshSettingClass.JOIN, null, null, listOf("all", "relay"), 0, """"all""""),
        "reports.everyMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 0.0, 600000.0, null, 0, """null"""),
        "stats.everyMs" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1000.0, 60000.0, null, 0, """1900"""),
        "probe.enabled" to MeshSettingKey(MeshSettingType.BOOL, MeshSettingClass.LIVE, null, null, null, 0, """false"""),
        "probe.samples" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 10.0, null, 0, """3"""),
        "probe.cacheMin" to MeshSettingKey(MeshSettingType.INT, MeshSettingClass.LIVE, 1.0, 1440.0, null, 0, """20"""),
    )
}
