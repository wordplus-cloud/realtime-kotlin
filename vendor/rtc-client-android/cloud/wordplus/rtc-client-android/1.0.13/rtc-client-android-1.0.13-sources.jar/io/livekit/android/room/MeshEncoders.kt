/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import io.livekit.android.room.track.LocalVideoTrack
import io.livekit.android.util.LKLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import livekit.org.webrtc.RTCStatsReport
import livekit.org.webrtc.RtpReceiver
import livekit.org.webrtc.RtpSender
import kotlin.math.roundToInt

// WordPlus Mesh (1.0.2, as rtc-client 1.0.10 and 1.0.11's room/meshEncoders.ts): which encoder each published video
// runs on, hardware or software, and how each layer encodes, told to the node for its live view (2026-10-18; and
// 2026-10-19, after a call where many people sent few frames a second), so a call's people show how each one
// publishes. Only the device knows it, in its senders' stats:
// `encoderImplementation` ("SimulcastEncoderAdapter (libvpx, MediaCodec, MediaCodec)", one encoder a layer from the
// smallest up) and `powerEfficientEncoder`, each layer's frames, height and what holds it back, and its totals of
// encode time, key frames made and key frames asked for, from which a reading takes what changed since the last. Read
// every [MeshEncoders.REPORT_EVERY_MS] while connected, sent when it changed and again after a reconnect, in a signal
// request with no message of LiveKit's and the JSON in [MeshEncoders.FIELD]: a node before 1.0.35 handles it as
// nothing. Only to a mesh's servers.

internal object MeshEncoders {
    const val REPORT_EVERY_MS = 10_000L

    /** The signal request field the report goes in (WordPlus Mesh's `MeshEncodersFieldNumber`). */
    const val FIELD = 1001

    /** One stats object as libwebrtc gives it: its id, its type and its members, and when it was read (µs). */
    data class Stat(val id: String, val type: String, val values: Map<String, Any?>, val timestampUs: Double = 0.0)

    @Serializable
    data class Layer(
        val rid: String,
        val encoder: String? = null,
        val hw: Boolean? = null,
        /** while it encodes: its frames a second, its height, and what holds it back ("cpu", "bandwidth", "other") */
        val fps: Int? = null,
        val height: Int? = null,
        val limit: String? = null,
        /** since the last reading: ms of encoding a frame, key frames made, key frames asked for (PLI, FIR) */
        val encodeMs: Double? = null,
        val keyFrames: Int? = null,
        val plis: Int? = null,
        /**
         * since the last reading (1.0.6, rtc-client 1.0.16): frames it encoded and sent (sent fewer than encoded: its
         * sending queue held them), and the bitrate its encoder aims at now, kbit/s
         */
        val encoded: Int? = null,
        val sent: Int? = null,
        val target: Int? = null,
    )

    /** How long a codec's encoder was held back since the last reading, ms, by what (1.0.6). */
    @Serializable
    data class Limits(val cpu: Int? = null, val bandwidth: Int? = null, val other: Int? = null)

    @Serializable
    data class CodecReport(
        val codec: String,
        val encoder: String,
        val layers: List<Layer>,
        /** the frames a second its source gives the encoder (media-source stats) */
        val captured: Int? = null,
        /**
         * what its sending did since the last reading, its layers together (1.0.6, [sendingOf]): the frames its source
         * gave, the ms its encoder was held back by each cause, the ms a packet waited in its sending queue on average,
         * the share of its packets sent again (%), and its oversized frames
         */
        val frames: Int? = null,
        val limitMs: Limits? = null,
        val queueMs: Double? = null,
        val resent: Double? = null,
        val huge: Int? = null,
        /** 1.0.10: the mode a camera in one SVC stream goes out in now (L2T3_KEY once trimmed to two sizes) */
        val svc: String? = null,
    )

    /** The mode a capture was opened at: its size and the frames a second asked of the device. */
    @Serializable
    data class Mode(val width: Int, val height: Int, val fps: Int? = null)

    /**
     * stalls, stallMs: since the last reading (1.0.6), the times its source stopped giving frames by itself (the camera,
     * its driver or the system held it, not the person: [SourceWatch]), and the ms it gave none
     */
    @Serializable
    data class TrackReport(
        val sid: String,
        val codecs: List<CodecReport>,
        val mode: Mode? = null,
        val stalls: Int? = null,
        val stallMs: Int? = null,
    )

    @Serializable
    private data class Body(val tracks: List<TrackReport>)

    /**
     * A layer's running totals in its stats, from which [sinceLast] takes what changed between two readings; and (1.0.6)
     * framesSent, packetsSent, totalPacketSendDelay, retransmittedPacketsSent, hugeFramesSent, qualityLimitationDurations,
     * and its media source's frames.
     */
    data class Totals(
        val encodeTime: Double? = null,
        val frames: Double? = null,
        val keyFrames: Double? = null,
        val plis: Double? = null,
        val sent: Double? = null,
        val packets: Double? = null,
        val sendDelay: Double? = null,
        val resent: Double? = null,
        val huge: Double? = null,
        val limits: Map<String, Double>? = null,
        val sourceFrames: Double? = null,
    )

    data class Since(val encodeMs: Double? = null, val keyFrames: Int? = null, val plis: Int? = null)

    /** What a layer sent between two readings (1.0.6), which its codec's sending sums ([sendingOf]). */
    data class Sent(
        val encoded: Int? = null,
        val sent: Int? = null,
        val packets: Double? = null,
        /** s its packets waited in the sending queue, summed */
        val sendDelay: Double? = null,
        val resent: Double? = null,
        val huge: Double? = null,
        /** s its encoder was held back, by what ("cpu", "bandwidth", "other") */
        val limits: Map<String, Double>? = null,
        /** frames its source gave (the media source's own total) */
        val sourceFrames: Double? = null,
    )

    /** What a codec's sending did since the last reading (1.0.6, [sendingOf]). */
    data class Sending(
        val frames: Int? = null,
        val limitMs: Limits? = null,
        val queueMs: Double? = null,
        val resent: Double? = null,
        val huge: Int? = null,
    )

    data class Outbound(
        val rid: String,
        val height: Int,
        val encoder: String? = null,
        val powerEfficient: Boolean? = null,
        val active: Boolean = true,
        val fps: Double? = null,
        val limit: String? = null,
        val captured: Double? = null,
        val mime: String = "",
        val encodeMs: Double? = null,
        val keyFrames: Int? = null,
        val plis: Int? = null,
        /** the bitrate its encoder aims at now, bit/s, and what it sent since the last reading (1.0.6) */
        val target: Double? = null,
        val sent: Sent = Sent(),
    )

    private val json = Json { explicitNulls = false }

    private val SOFTWARE = Regex("^(libvpx|openh264|libaom|svt|ffmpeg|libx26|dav1d|rav1e|fake)", RegexOption.IGNORE_CASE)

    /** Whether an encoder named so runs in hardware: null when the device named none. */
    fun encoderHardware(name: String?, powerEfficient: Boolean?): Boolean? {
        if (name.isNullOrEmpty()) return powerEfficient
        return !SOFTWARE.containsMatchIn(name.trim())
    }

    private val ADAPTER = Regex("^SimulcastEncoderAdapter\\s*\\((.*)\\)\\s*$")

    /** The encoders a SimulcastEncoderAdapter names, in its streams' order; the name itself for any other. */
    fun adapterEncoders(name: String): List<String> {
        val m = ADAPTER.find(name.trim()) ?: return listOf(name.trim())
        return m.groupValues[1].split(',').map { it.trim() }.filter { it.isNotEmpty() }
    }

    /**
     * What a layer did between two readings of its totals: the time it took to encode a frame, in ms, and the key frames
     * it made and was asked for. Nothing from a first reading, nor from a total the device doesn't keep or that went
     * back (a sender started over).
     */
    fun sinceLast(prev: Totals?, now: Totals): Since {
        if (prev == null) return Since()
        fun delta(a: Double?, b: Double?): Double? = if (a != null && b != null && b >= a) b - a else null
        val frames = delta(prev.frames, now.frames)
        val time = delta(prev.encodeTime, now.encodeTime)
        val encodeMs = if (frames != null && frames > 0 && time != null) Math.round((time / frames) * 10_000) / 10.0 else null
        return Since(encodeMs, delta(prev.keyFrames, now.keyFrames)?.toInt(), delta(prev.plis, now.plis)?.toInt())
    }

    /**
     * What a layer sent between two readings of its totals (1.0.6, rtc-client 1.0.16's `sinceLast`): the frames it
     * encoded and sent, its packets, how long they waited to go, those sent again, its oversized frames, how long its
     * encoder was held back and by what, and the frames its source gave. Nothing from a first reading, nor from a total
     * the device doesn't keep or that went back.
     */
    fun sentSince(prev: Totals?, now: Totals): Sent {
        if (prev == null) return Sent()
        fun delta(a: Double?, b: Double?): Double? = if (a != null && b != null && b >= a) b - a else null
        val limits = if (prev.limits != null && now.limits != null) {
            listOf("cpu", "bandwidth", "other").mapNotNull { k ->
                delta(prev.limits[k], now.limits[k])?.takeIf { it > 0 }?.let { k to it }
            }.toMap()
        } else {
            null
        }
        return Sent(
            encoded = delta(prev.frames, now.frames)?.toInt(),
            sent = delta(prev.sent, now.sent)?.toInt(),
            packets = delta(prev.packets, now.packets),
            sendDelay = delta(prev.sendDelay, now.sendDelay),
            resent = delta(prev.resent, now.resent),
            huge = delta(prev.huge, now.huge),
            limits = limits,
            sourceFrames = delta(prev.sourceFrames, now.sourceFrames),
        )
    }

    /**
     * What a codec's sending did since the last reading, its layers summed (1.0.6, rtc-client 1.0.16's `sendingOf`): the
     * frames its source gave, the ms its encoder was held back by each cause (the layer held back most: they share one
     * encoder's adapter), the ms a packet waited to go on average, the share sent again (%) and its oversized frames.
     * Each only where there is something.
     */
    fun sendingOf(sent: List<Sent>): Sending {
        var packets = 0.0
        var delay = 0.0
        var resent = 0.0
        var huge = 0.0
        var frames: Double? = null
        val held = mutableMapOf<String, Int>()
        for (s in sent) {
            packets += s.packets ?: 0.0
            delay += s.sendDelay ?: 0.0
            resent += s.resent ?: 0.0
            huge += s.huge ?: 0.0
            s.sourceFrames?.let { frames = maxOf(frames ?: 0.0, it) }
            for (k in listOf("cpu", "bandwidth", "other")) {
                val ms = Math.round((s.limits?.get(k) ?: 0.0) * 1000).toInt()
                if (ms > (held[k] ?: 0)) held[k] = ms
            }
        }
        return Sending(
            frames = frames?.toInt(),
            limitMs = if (held.isEmpty()) null else Limits(held["cpu"], held["bandwidth"], held["other"]),
            queueMs = if (packets > 0) Math.round(delay * 10_000 / packets) / 10.0 else null,
            resent = if (packets > 0 && resent > 0) Math.round(resent * 1000 / packets) / 10.0 else null,
            huge = if (huge > 0) huge.toInt() else null,
        )
    }

    private val RID_ORDER = listOf("q", "h", "f")

    /**
     * Whether a layer encodes now: the adapter names the encoders of those alone, and a layer the server paused
     * (dynacast) can still read active for a moment after it stopped, so its frames decide where it says them.
     */
    private fun sending(o: Outbound) = o.active && (o.fps == null || o.fps > 0)

    /**
     * One sender's layers, each with its own encoder where the adapter's list matches the layers that encode, or the one
     * encoder every one of them runs on; a device that names none still gets its layers' frames and size told, its
     * encoder "".
     */
    fun layersOf(outbound: List<Outbound>): Pair<String, List<Layer>>? {
        if (outbound.isEmpty()) return null
        val named = outbound.firstOrNull { !it.encoder.isNullOrEmpty() }
        fun order(o: Outbound) = RID_ORDER.indexOf(o.rid).let { if (it < 0) RID_ORDER.size + o.height else it }
        val sorted = outbound.sortedWith(compareBy<Outbound>({ order(it) }, { it.height }))
        val list = named?.encoder?.let { adapterEncoders(it) } ?: emptyList()
        val active = sorted.indices.filter { sending(sorted[it]) }
        val one = list.isNotEmpty() && list.toSet().size == 1

        val layers = sorted.mapIndexed { i, o ->
            val encoder = when {
                one -> list[0]
                list.isNotEmpty() && list.size == active.size && i in active -> list[active.indexOf(i)]
                list.isNotEmpty() && list.size == sorted.size -> list[i]
                else -> null
            }
            var layer = Layer(rid = o.rid)
            if (encoder != null) {
                layer = layer.copy(
                    encoder = encoder.take(80),
                    hw = encoderHardware(encoder, if (list.size == 1) o.powerEfficient else null),
                )
            }
            // what it encodes now, what holds it back, and how it encodes since the last reading
            if (sending(o) && o.fps != null) {
                layer = layer.copy(
                    fps = o.fps.roundToInt(),
                    height = o.height.takeIf { it > 0 },
                    limit = o.limit?.takeIf { it != "none" },
                    encodeMs = o.encodeMs,
                    keyFrames = o.keyFrames,
                    plis = o.plis,
                    // 1.0.6: frames encoded and sent since the last reading (fewer sent: its queue held them) and what it
                    // aims at
                    encoded = o.sent.encoded,
                    sent = o.sent.sent,
                    target = o.target?.takeIf { it > 0 }?.let { (it / 1000).roundToInt() },
                )
            }
            layer
        }
        return (named?.encoder?.take(200) ?: "") to layers
    }

    /**
     * A sender's video layers from its stats, with what changed since [before] (its layers' totals at the last reading,
     * by rid), and its totals now.
     */
    fun outboundOf(stats: List<Stat>, before: Map<String, Totals>?): Pair<List<Outbound>, Map<String, Totals>> {
        val byId = stats.associateBy { it.id }
        fun num(v: Any?): Double? = (v as? Number)?.toDouble()
        fun str(v: Any?): String? = v as? String
        val out = mutableListOf<Outbound>()
        val totals = mutableMapOf<String, Totals>()
        for (s in stats) {
            if (s.type != "outbound-rtp" || str(s.values["kind"]) != "video") continue
            val codec = str(s.values["codecId"])?.let { byId[it] }
            val source = str(s.values["mediaSourceId"])?.let { byId[it] }
            val rid = str(s.values["rid"]) ?: ""
            val pli = num(s.values["pliCount"])
            val fir = num(s.values["firCount"])
            val now = Totals(
                encodeTime = num(s.values["totalEncodeTime"]),
                frames = num(s.values["framesEncoded"]),
                keyFrames = num(s.values["keyFramesEncoded"]),
                plis = if (pli != null || fir != null) (pli ?: 0.0) + (fir ?: 0.0) else null,
                sent = num(s.values["framesSent"]),
                packets = num(s.values["packetsSent"]),
                sendDelay = num(s.values["totalPacketSendDelay"]),
                resent = num(s.values["retransmittedPacketsSent"]),
                huge = num(s.values["hugeFramesSent"]),
                limits = (s.values["qualityLimitationDurations"] as? Map<*, *>)?.entries?.mapNotNull { (k, v) ->
                    val d = num(v)
                    if (k is String && d != null) k to d else null
                }?.toMap(),
                sourceFrames = num(source?.values?.get("frames")),
            )
            totals[rid] = now
            val since = sinceLast(before?.get(rid), now)
            out.add(
                Outbound(
                    rid = rid,
                    height = num(s.values["frameHeight"])?.toInt() ?: 0,
                    encoder = str(s.values["encoderImplementation"]),
                    powerEfficient = s.values["powerEfficientEncoder"] as? Boolean,
                    active = s.values["active"] as? Boolean ?: true,
                    fps = num(s.values["framesPerSecond"]),
                    limit = str(s.values["qualityLimitationReason"]),
                    captured = num(source?.values?.get("framesPerSecond")),
                    mime = str(codec?.values?.get("mimeType")) ?: "",
                    encodeMs = since.encodeMs,
                    keyFrames = since.keyFrames,
                    plis = since.plis,
                    target = num(s.values["targetBitrate"]),
                    sent = sentSince(before?.get(rid), now),
                ),
            )
        }
        return out to totals
    }

    /** 1.0.10: the SVC mode a sender of one encoding goes out in now; null for simulcast or none. */
    fun svcModeOf(sender: RtpSender): String? = try {
        sender.parameters?.encodings?.singleOrNull()?.scalabilityMode?.takeIf { Regex("^L\\dT\\d").containsMatchIn(it) }
    } catch (e: Exception) {
        null
    }

    /** One sender's report, its codec's name given (a backup's) or read from its stats; null with no video layers. */
    fun codecReport(outbound: List<Outbound>, named: String?): CodecReport? {
        val (encoder, layers) = layersOf(outbound) ?: return null
        val mime = outbound.firstOrNull { it.mime.isNotEmpty() }?.mime ?: ""
        val codec = (named ?: mime.replaceFirst(Regex("^video/", RegexOption.IGNORE_CASE), "")).lowercase()
        val captured = outbound.mapNotNull { it.captured }.maxOrNull()
        // 1.0.6: what its sending did since the last reading
        val sending = sendingOf(outbound.map { it.sent })
        return CodecReport(
            codec = codec,
            encoder = encoder,
            layers = layers,
            captured = captured?.roundToInt(),
            frames = sending.frames,
            limitMs = sending.limitMs,
            queueMs = sending.queueMs,
            resent = sending.resent,
            huge = sending.huge,
        )
    }

    /** The report as a node reads it: `{"tracks":[...]}`, its keys in one order, so two readings that say the same compare equal. */
    fun json(tracks: List<TrackReport>): String = json.encodeToString(Body(tracks))

    fun stats(report: RTCStatsReport): List<Stat> =
        report.statsMap.values.map { Stat(it.id, it.type, it.members, it.timestampUs) }
}

/**
 * WordPlus Mesh (1.0.6, as rtc-client 1.0.16's `sourceStalls`): whether a published video's source stopped giving frames
 * by itself, the camera, its driver or the system holding it (another app took the camera, a call or the system
 * interrupted it), never the person (a muted track isn't watched). The browser says so in its track's mute events; a
 * native capturer says nothing alike, so it is read from the connection's shared readings: the source's own frame count
 * (media-source `frames`) not moving between two readings while the track is on. A reading every 10 s: a stop shorter
 * than that between two readings goes unseen, one longer is counted from the reading before.
 */
internal class SourceWatch {
    private var frames: Double? = null
    private var at: Double? = null
    private var stalls = 0
    private var ms = 0.0
    private var stalledAt: Double? = null

    /** A reading of the source's frame count at [at] (ms); [on]: the track is on (unmuted), else the watch starts over. */
    fun read(frames: Double?, at: Double, on: Boolean) {
        if (!on || frames == null) {
            this.frames = null
            this.at = null
            stalledAt = null
            return
        }
        val before = this.frames
        val then = this.at
        this.frames = frames
        this.at = at
        if (before == null || then == null || at <= then) return
        if (frames <= before) {
            if (stalledAt == null) {
                stalls++
                stalledAt = then
            }
        } else {
            stalledAt?.let { ms += maxOf(0.0, then - it) }
            stalledAt = null
        }
    }

    /** Whether it stopped since it was last asked, or is stopped now. */
    val stalled: Boolean get() = stalls > 0 || stalledAt != null

    /** The stops since it was last asked and their ms, one still going on counted to [now], the rest in the next. */
    fun take(now: Double): Pair<Int, Int> {
        val total = ms + (stalledAt?.let { maxOf(0.0, now - it) } ?: 0.0)
        val out = stalls to total.roundToInt()
        stalls = 0
        ms = 0.0
        if (stalledAt != null) stalledAt = now
        return out
    }
}

/**
 * WordPlus Mesh (1.0.2; 1.0.6 as rtc-client 1.0.16's `meshReportTick`): the reports to a mesh node while connected.
 * Every [MeshEncoders.REPORT_EVERY_MS] a look, and the reports go when the node's pace says ([setPace]: 10 s in a small
 * call, less often in a big room, never at 0), or at once when what happened can't wait: a thermal state serious or
 * worse, an audio device plugged in or out ([MeshHealthWatch]), its own camera stopping by itself ([SourceWatch]), a
 * freeze in what it plays; and 3 s after a video is published. One message a reading ([sendReports]): the encoders when
 * they changed, what it receives, the device and the app; all of it again after a reconnect, to a node that may hold no
 * session of it yet. Every reading is its part of the connections' shared readings ([MeshStatsHub]).
 */
internal class MeshEncoderReporter(
    /** Whether the room is connected to its server now. */
    private val connected: () -> Boolean,
    /** The room's published videos: their sids and tracks. */
    private val videos: () -> List<Pair<String, LocalVideoTrack>>,
    /** A sender's own stats, where its part of the shared reading can't be told. */
    private val statsOf: suspend (RtpSender) -> RTCStatsReport?,
    /** The tracks the room receives (1.0.5, [MeshReceivers]): their sids, whether each is a video, and their receivers. */
    private val received: () -> List<Triple<String, Boolean, RtpReceiver>> = { emptyList() },
    /** A receiver's own stats, where its part of the shared reading can't be told. */
    private val receiverStatsOf: suspend (RtpReceiver) -> RTCStatsReport? = { null },
    /**
     * 1.0.6: the publisher's and the subscriber's connections now, by which their shared readings are kept (a full
     * reconnect makes new ones), and a connection's whole stats.
     */
    private val connections: () -> Pair<Any?, Any?> = { null to null },
    private val connectionStats: suspend (Any) -> RTCStatsReport? = { null },
    /** A sender's mid on the publisher, and how many of the publisher's senders send its track. */
    private val senderInfo: suspend (RtpSender) -> Pair<String?, Int> = { null to 0 },
    /** Sends a reading's reports in one request (encoders, receivers, health, each JSON or none); whether it went. */
    private val sendReports: (String?, String?, String?) -> Boolean = { _, _, _ -> false },
    /** The device and the app, from the system's own callbacks (1.0.6). */
    val health: MeshHealthWatch = MeshHealthWatch(null),
    /** 1.0.7: when this device last turned a received track back on after turning it off itself, by its sid ([MeshTurns]). */
    private val turnedOnAt: (String) -> Double? = { null },
    /** 1.0.9: the settings revision the room runs ([MeshSettings.rev]), null before it has settings. */
    private val settingsRev: () -> Long? = { null },
) {
    private var job: Job? = null

    @Volatile
    private var sent: String? = null
    private val totals = mutableMapOf<RtpSender, Map<String, MeshEncoders.Totals>>()

    /** each received track's totals at the last reading, by its receiver */
    private val receivers = mutableMapOf<RtpReceiver, MeshReceivers.Totals>()

    /** 1.0.7: the turn-on whose gap a reading told, by its receiver (guarded with [receivers]) */
    private val resumes = mutableMapOf<RtpReceiver, Double>()

    /** The connections' readings, shared by these reports and the hardware-drop watch (1.0.6). */
    val stats = MeshStatsHub()

    /** 1.0.6: the node's pace (ms), when the reports last went, the freezes in what it plays at the last look */
    @Volatile
    private var every = MeshEncoders.REPORT_EVERY_MS.toInt()

    @Volatile
    private var reportedAt: Long? = null
    private var freezesSeen: Double? = null

    /** each published video's source, by its track's id */
    private val sources = mutableMapOf<String, SourceWatch>()

    /**
     * Connected to a mesh, or connected again after a reconnect: everything is told again at the next reading, the
     * device too, to a node that may know nothing of it.
     */
    @Synchronized
    fun start(scope: CoroutineScope) {
        sent = null
        reportedAt = null
        health.start()
        health.tellMachineAgain()
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                delay(MeshEncoders.REPORT_EVERY_MS)
                tick()
            }
        }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        sent = null
        reportedAt = null
        every = MeshEncoders.REPORT_EVERY_MS.toInt()
        health.stop()
        stats.clear()
        synchronized(totals) { totals.clear() }
        synchronized(receivers) { receivers.clear() }
        synchronized(sources) {
            sources.clear()
            freezesSeen = null
        }
    }

    /** The node's pace for the reports, ms (0: none), as it says in its signal response ([Mesh.REPORTS_FIELD]). */
    fun setPace(every: Int) {
        this.every = maxOf(0, every)
    }

    /** A new video's encoders are told within a few seconds, once they run, not at the next reading. */
    fun reportSoon(scope: CoroutineScope) {
        if (job?.isActive != true || every <= 0) return
        scope.launch {
            delay(3_000)
            report()
        }
    }

    /** A connection's shared reading as entries; empty where it can't be read. */
    private suspend fun read(connection: Any): List<MeshEncoders.Stat> = stats.read(connection) {
        connectionStats(connection)?.let { MeshEncoders.stats(it) } ?: emptyList()
    }

    /**
     * A look every [MeshEncoders.REPORT_EVERY_MS]: the sources and the freezes from the connections' shared readings, and
     * the reports when they are due or something can't wait. A look between two reports costs a reading of each
     * connection, which the reports then share; the next report says everything since the last that went.
     */
    suspend fun tick(now: Long = System.currentTimeMillis()) {
        val every = every
        if (every <= 0 || !connected()) return
        val urgent = troubled()
        val due = reportedAt?.let { now - it >= every - MeshEncoders.REPORT_EVERY_MS / 2 } ?: true
        if (!due && !urgent) return
        reportedAt = now
        report()
    }

    /**
     * Whether something since the last report can't wait for the next one; also keeps each published video's source
     * watch and the freezes seen up to date, from the connections' shared readings.
     */
    suspend fun troubled(): Boolean {
        var urgent = health.troubled()
        val (publisher, subscriber) = connections()
        // the publisher is read only for a video it publishes (a stream's viewer publishes none)
        val videos = videos()
        if (publisher != null && videos.isNotEmpty()) {
            val published = read(publisher)
            val at = System.currentTimeMillis().toDouble()
            for ((_, track) in videos) {
                val id = try {
                    track.rtcTrack.id()
                } catch (e: Exception) {
                    continue
                }
                val source = published.firstOrNull { it.type == "media-source" && it.values["trackIdentifier"] == id }
                val frames = (source?.values?.get("frames") as? Number)?.toDouble()
                val stalled = synchronized(sources) {
                    val watch = sources.getOrPut(id) { SourceWatch() }
                    watch.read(frames, at, track.enabled)
                    watch.stalled
                }
                urgent = urgent || stalled
            }
        }
        // a freeze in what it plays
        if (subscriber != null) {
            val freezes = read(subscriber).filter { it.type == "inbound-rtp" }
                .mapNotNull { (it.values["freezeCount"] as? Number)?.toDouble() }.sum()
            val before = synchronized(sources) {
                val before = freezesSeen
                freezesSeen = freezes
                before
            }
            urgent = urgent || (before != null && freezes > before)
        }
        return urgent
    }

    /** The reading's reports in one message: the encoders when they changed, what it receives, the device and the app. */
    suspend fun report() {
        if (!connected()) return
        val (tracks, json) = readEncoders()
        val receivers = readReceivers()
        // the device and the app, with each connection's path from its shared reading
        val (publisher, subscriber) = connections()
        val paths = mutableMapOf<String, List<MeshEncoders.Stat>>()
        publisher?.let { paths["pub"] = read(it) }
        subscriber?.let { paths["sub"] = read(it) }
        // 1.0.9: the settings revision it runs, in every report once it has settings
        val device = health.reading(paths).copy(cfg = settingsRev())

        val last = sent
        val changed = json.takeIf { it != last && (tracks.isNotEmpty() || last != null) }
        val went = sendReports(
            changed,
            receivers.takeIf { it.isNotEmpty() }?.let { MeshReceivers.json(it) },
            device.takeIf { !it.isEmpty }?.let { MeshHealth.json(it) },
        )
        if (!went) {
            LKLog.d { "Could not send the reports" }
        } else if (changed != null) {
            sent = changed
        }
    }

    /**
     * The published videos' encoders, each sender's its part of the publisher's shared reading (or its own reading where
     * the part can't be told), with its source's stops since the last report.
     */
    private suspend fun readEncoders(): Pair<List<MeshEncoders.TrackReport>, String> {
        val tracks = mutableListOf<MeshEncoders.TrackReport>()
        val publisher = connections().first
        for ((sid, track) in videos()) {
            val codecs = mutableListOf<MeshEncoders.CodecReport>()
            for ((sender, named) in track.meshSenders()) {
                val entries = try {
                    val part = publisher?.let { connection ->
                        val (mid, count) = senderInfo(sender)
                        MeshStats.forSender(read(connection), mid, sender.track()?.id(), count)
                    }
                    part ?: statsOf(sender)?.let { MeshEncoders.stats(it) }
                } catch (e: Exception) {
                    null
                } ?: continue
                val before = synchronized(totals) { totals[sender] }
                val (outbound, now) = MeshEncoders.outboundOf(entries, before)
                synchronized(totals) { totals[sender] = now }
                MeshEncoders.codecReport(outbound, named)?.let { report ->
                    // 1.0.10: the mode a camera in one SVC stream goes out in now
                    val svc = if (named == null && (report.codec == "vp9" || report.codec == "av1")) MeshEncoders.svcModeOf(sender) else null
                    codecs.add(if (svc != null) report.copy(svc = svc) else report)
                }
            }
            if (codecs.isEmpty()) continue
            val params = track.options.captureParams
            // its source stopping by itself since the last report (SourceWatch)
            val stalled = try {
                val id = track.rtcTrack.id()
                synchronized(sources) { sources[id]?.take(System.currentTimeMillis().toDouble()) }
            } catch (e: Exception) {
                null
            }?.takeIf { it.first > 0 || it.second > 0 }
            tracks.add(
                MeshEncoders.TrackReport(
                    sid,
                    codecs,
                    MeshEncoders.Mode(params.width, params.height, params.maxFps),
                    stalls = stalled?.first,
                    stallMs = stalled?.second,
                ),
            )
        }
        return tracks to MeshEncoders.json(tracks)
    }

    /**
     * WordPlus Mesh (1.0.5, rtc-client 1.0.15's `reportMeshReceivers`): what each received track is like where it plays
     * ([MeshReceivers]), at the reports' readings: every one that received anything since the last, numbers only; each its
     * part of the subscriber's shared reading (1.0.6).
     */
    private suspend fun readReceivers(): List<MeshReceivers.Track> {
        val tracks = mutableListOf<MeshReceivers.Track>()
        val seen = mutableSetOf<RtpReceiver>()
        val subscriber = connections().second
        for ((sid, video, receiver) in received()) {
            val inbound = try {
                val id = receiver.track()?.id()
                val part = if (subscriber != null && id != null) MeshStats.forReceiver(read(subscriber), id) else null
                part?.let { MeshReceivers.inbound(it) } ?: receiverStatsOf(receiver)?.let { MeshReceivers.inbound(it) }
            } catch (e: Exception) {
                null
            } ?: continue
            val (values, at) = inbound
            seen.add(receiver)
            val now = MeshReceivers.totals(values, at, System.currentTimeMillis().toDouble())
            val before = synchronized(receivers) { receivers[receiver] }
            // 1.0.7: when this device last turned it back on itself, unless a reading told that gap already
            val onAt = turnedOnAt(sid)
            val told = synchronized(receivers) { resumes[receiver] }
            val read = MeshReceivers.reading(
                sid,
                video,
                before,
                now,
                if (video) MeshReceivers.height(values) else null,
                onAt?.takeIf { it != told },
            )
            synchronized(receivers) {
                receivers[receiver] = now
                if (read?.hiddenGaps != null && onAt != null) resumes[receiver] = onAt
            }
            read?.let { tracks.add(it) }
        }
        // receivers gone since are forgotten, not kept for the room's lifetime
        synchronized(receivers) {
            receivers.keys.retainAll(seen)
            resumes.keys.retainAll(seen)
        }
        return tracks
    }
}
