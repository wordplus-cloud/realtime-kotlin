/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import livekit.org.webrtc.RTCStatsReport
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

// WordPlus Mesh (1.0.5, as rtc-client 1.0.15's room/meshReceivers.ts): what each received track is like where it plays,
// told to the node for its live view (2026-10-21: monitoring a call's quality without anyone watching it). The node
// knows what it sends a viewer; only the device knows whether the picture freezes, how many frames it shows and whether
// the sound breaks up, in its receivers' stats: framesDecoded, frameHeight, freezeCount and totalFreezesDuration,
// framesDropped, concealedSamples less silentConcealedSamples over totalSamplesReceived, packetsLost, and
// jitterBufferDelay over jitterBufferEmittedCount. Numbers only.
//
// Read at the encoders' readings (every [MeshEncoders.REPORT_EVERY_MS]), each reading what changed since the one before,
// and sent in a signal request with no message of LiveKit's and the JSON in [MeshReceivers.FIELD]: a node before 1.0.46
// handles it as nothing. Only to a mesh's servers.

internal object MeshReceivers {
    /** The signal request field the report goes in (WordPlus Mesh's `MeshReceiversFieldNumber`). */
    const val FIELD = 1002

    /** A received track's running totals in its inbound-rtp stats, from which [reading] takes what changed. */
    data class Totals(
        val at: Double,
        val packets: Double,
        val lost: Double,
        val frames: Double? = null,
        val freezes: Double? = null,
        val freezeSeconds: Double? = null,
        val dropped: Double? = null,
        val samples: Double? = null,
        val concealed: Double? = null,
        val jitterDelay: Double? = null,
        val jitterEmitted: Double? = null,
        /**
         * 1.0.6 (rtc-client 1.0.16): totalDecodeTime, the gaps between frames shown (their sum and sum of squares, s),
         * pauses (5 s or more), key frames and retransmissions asked for, samples stretched and squeezed; and two that
         * aren't totals: the network's jitter now (s) and whether the decoder is the device's (powerEfficientDecoder)
         */
        val decodeTime: Double? = null,
        val gaps: Double? = null,
        val gapsSquared: Double? = null,
        val pauses: Double? = null,
        val pauseSeconds: Double? = null,
        val plis: Double? = null,
        val nacks: Double? = null,
        val stretched: Double? = null,
        val jitter: Double? = null,
        val hwDec: Boolean? = null,
        /**
         * 1.0.7 (rtc-client 1.0.17): this device's clock at the reading (ms since 1970), the one it turns tracks off and
         * on by: the stats' own timestamps run on WebRTC's clock
         */
        val readAt: Double? = null,
    )

    /**
     * 1.0.7: how long after this device turns a video back on its first frame may still come, ending the gap it made
     * (the node resumes it and its sender sends a key frame), ms. A frame landing after a reading is the next reading's.
     */
    const val RESUME_MS = 3000.0

    /** One received track over a reading, as the node reads it (its `MeshPlayed`): what the device keeps not is left out. */
    @Serializable
    data class Track(
        val sid: String,
        val kind: String,
        val fps: Double? = null,
        val height: Int? = null,
        val freezes: Int? = null,
        val freezeMs: Int? = null,
        val dropped: Int? = null,
        val concealed: Double? = null,
        val lost: Double? = null,
        val jbMs: Int? = null,
        /**
         * since the last reading (1.0.6), a video's: ms of decoding a frame and whether its decoder is hardware, how
         * unevenly its frames were shown (the spread of the gaps between them, ms), pauses of 5 s or more and their ms,
         * the key frames and retransmissions it asked for; a sound's: the share of what it played stretched or squeezed
         * to keep in time (%); both: the network's jitter, ms
         */
        val decodeMs: Double? = null,
        val hwDec: Boolean? = null,
        val unevenMs: Int? = null,
        val pauses: Int? = null,
        val pauseMs: Int? = null,
        val plis: Int? = null,
        val nacks: Int? = null,
        val stretched: Double? = null,
        val jitterMs: Int? = null,
        /**
         * 1.0.7, a video's: the gaps this device made itself by turning it off (its view hidden or gone) and their ms,
         * told apart from pauses and freezes and left out of unevenMs
         */
        val hiddenGaps: Int? = null,
        val hiddenGapMs: Int? = null,
    )

    @Serializable
    private data class Body(val tracks: List<Track>)

    private val json = Json { explicitNulls = false }

    private fun num(v: Any?): Double? = (v as? Number)?.toDouble()?.takeIf { it.isFinite() }

    private fun round1(v: Double) = (v * 10).roundToInt() / 10.0

    /** A receiver's totals from its inbound-rtp stats' members, read at [at] (ms), and at [readAt] on this device's clock (1.0.7). */
    fun totals(values: Map<String, Any?>, at: Double, readAt: Double? = null): Totals {
        val concealed = num(values["concealedSamples"])
        return Totals(
            at = at,
            packets = num(values["packetsReceived"]) ?: 0.0,
            lost = max(0.0, num(values["packetsLost"]) ?: 0.0),
            frames = num(values["framesDecoded"]),
            freezes = num(values["freezeCount"]),
            freezeSeconds = num(values["totalFreezesDuration"]),
            dropped = num(values["framesDropped"]),
            samples = num(values["totalSamplesReceived"]),
            // concealment while the other side was silent costs nothing anyone hears
            concealed = concealed?.let { it - (num(values["silentConcealedSamples"]) ?: 0.0) },
            jitterDelay = num(values["jitterBufferDelay"]),
            jitterEmitted = num(values["jitterBufferEmittedCount"]),
            decodeTime = num(values["totalDecodeTime"]),
            gaps = num(values["totalInterFrameDelay"]),
            gapsSquared = num(values["totalSquaredInterFrameDelay"]),
            pauses = num(values["pauseCount"]),
            pauseSeconds = num(values["totalPausesDuration"]),
            plis = num(values["pliCount"]),
            nacks = num(values["nackCount"]),
            stretched = stretched(values),
            jitter = num(values["jitter"]),
            hwDec = values["powerEfficientDecoder"] as? Boolean,
            readAt = readAt,
        )
    }

    /** Samples inserted to slow the sound down and removed to speed it up, together. */
    private fun stretched(values: Map<String, Any?>): Double? {
        val inserted = num(values["insertedSamplesForDeceleration"])
        val removed = num(values["removedSamplesForAcceleration"])
        if (inserted == null && removed == null) return null
        return (inserted ?: 0.0) + (removed ?: 0.0)
    }

    /** The height of the picture a receiver decodes now, from its inbound-rtp stats' members. */
    fun height(values: Map<String, Any?>): Int? = num(values["frameHeight"])?.toInt()

    /**
     * What a received track did between two readings of its totals; nothing from a first reading, or from totals that
     * went back (a receiver started over). [resumedAt] (1.0.7) is when this device last turned the video back on after
     * turning it off itself ([MeshTurns.onAt]), unless a reading told that gap already.
     */
    fun reading(sid: String, video: Boolean, prev: Totals?, now: Totals, height: Int? = null, resumedAt: Double? = null): Track? {
        if (prev == null || now.at <= prev.at || now.packets < prev.packets) return null
        val seconds = (now.at - prev.at) / 1000
        fun delta(a: Double?, b: Double?): Double? = if (a != null && b != null && b >= a) b - a else null
        val received = now.packets - prev.packets
        val lostNow = max(0.0, now.lost - prev.lost)
        val lost = if (received + lostNow > 0) round1(lostNow * 100 / (received + lostNow)) else null
        val delay = delta(prev.jitterDelay, now.jitterDelay)
        val emitted = delta(prev.jitterEmitted, now.jitterEmitted)
        val jbMs = if (delay != null && emitted != null && emitted > 0) (delay * 1000 / emitted).roundToInt() else null
        // 1.0.6: the network's jitter, ms
        val jitterMs = now.jitter?.takeIf { it >= 0.001 }?.let { (it * 1000).roundToInt() }
        if (!video) {
            val samples = delta(prev.samples, now.samples)
            val concealed = delta(prev.concealed, now.concealed)
            val stretched = delta(prev.stretched, now.stretched)
            return Track(
                sid = sid,
                kind = "audio",
                concealed = if (samples != null && samples > 0 && concealed != null) round1(concealed * 100 / samples) else null,
                lost = lost,
                jbMs = jbMs,
                stretched = if (samples != null && samples > 0 && stretched != null && stretched > 0) round1(stretched * 100 / samples) else null,
                jitterMs = jitterMs,
            )
        }
        var freezes = delta(prev.freezes, now.freezes)
        var frozen = delta(prev.freezeSeconds, now.freezeSeconds)
        val pauses = delta(prev.pauses, now.pauses)?.takeIf { it > 0 }
        val paused = delta(prev.pauseSeconds, now.pauseSeconds)
        // 1.0.7 (rtc-client 1.0.17): a gap this device made itself, turning the video off (its view hidden or gone), isn't
        // the call's (2026-10-24: the live view's "paused 1× 16.1 s" and "stutters ±870 ms" after a browser's tab switch).
        // A video turned back on since just before the last reading owns the pauses ending in this one, or the one freeze
        // its gap came out as when it was too short for a pause; they're told apart as hiddenGaps.
        val resumed = resumedAt != null && resumedAt > (prev.readAt ?: prev.at) - RESUME_MS
        var hiddenGaps: Double? = null
        var hiddenSeconds: Double? = null
        if (resumed && pauses != null) {
            hiddenGaps = pauses
            hiddenSeconds = paused
        } else if (resumed && freezes == 1.0) {
            hiddenGaps = 1.0
            hiddenSeconds = frozen
            freezes = 0.0
            frozen = 0.0
        }
        // 1.0.6: how it decodes, how evenly it shows, what it asked for (each only where there's something to say)
        val frames = delta(prev.frames, now.frames)
        val decode = delta(prev.decodeTime, now.decodeTime)
        var gaps = delta(prev.gaps, now.gaps)
        var squared = delta(prev.gapsSquared, now.gapsSquared)
        var shown = frames
        if (resumed) {
            // WebRTC adds every gap to both sums, a pause's and a freeze's too, as its very length (VideoQualityObserver2),
            // so one hidden gap comes out exactly; several, or one no total tells, leave the spread unsaid this reading
            if (hiddenGaps == 1.0 && hiddenSeconds != null && frames != null && gaps != null && squared != null) {
                gaps -= hiddenSeconds
                squared -= hiddenSeconds * hiddenSeconds
                shown = frames - 1
            } else {
                gaps = null
            }
        }
        val uneven = if (shown != null && shown > 1 && gaps != null && squared != null) {
            val mean = gaps / shown
            (sqrt(max(0.0, squared / shown - mean * mean)) * 1000).roundToInt()
        } else {
            null
        }
        val toldPauses = pauses?.takeIf { hiddenGaps == null }
        return Track(
            sid = sid,
            kind = "video",
            fps = frames?.let { round1(it / seconds) },
            height = height?.takeIf { it > 0 },
            freezes = freezes?.toInt(),
            freezeMs = if (freezes != null) frozen?.let { (it * 1000).roundToInt() } else null,
            dropped = delta(prev.dropped, now.dropped)?.toInt(),
            lost = lost,
            jbMs = jbMs,
            decodeMs = if (frames != null && frames > 0 && decode != null) round1(decode * 1000 / frames) else null,
            hwDec = now.hwDec,
            unevenMs = uneven,
            pauses = toldPauses?.toInt(),
            pauseMs = if (toldPauses != null) paused?.let { (it * 1000).roundToInt() } else null,
            plis = delta(prev.plis, now.plis)?.takeIf { it > 0 }?.toInt(),
            nacks = delta(prev.nacks, now.nacks)?.takeIf { it > 0 }?.toInt(),
            jitterMs = jitterMs,
            hiddenGaps = hiddenGaps?.toInt(),
            hiddenGapMs = if (hiddenGaps != null) hiddenSeconds?.let { (it * 1000).roundToInt() } else null,
        )
    }

    /** The report as a node reads it: `{"tracks":[...]}`. */
    fun json(tracks: List<Track>): String = json.encodeToString(Body(tracks))

    /** A receiver's inbound-rtp from its own stats report: its members and when it was read, in ms. */
    fun inbound(report: RTCStatsReport): Pair<Map<String, Any?>, Double>? =
        report.statsMap.values.firstOrNull { it.type == "inbound-rtp" }?.let { it.members to it.timestampUs / 1000 }

    /** The same from its part of the connection's shared reading (1.0.6, [MeshStats.forReceiver]). */
    fun inbound(stats: List<MeshEncoders.Stat>): Pair<Map<String, Any?>, Double>? =
        stats.firstOrNull { it.type == "inbound-rtp" }?.let { it.values to it.timestampUs / 1000 }
}

/**
 * WordPlus Mesh (1.0.7, rtc-client 1.0.17): while this device has a received track turned off (its view hidden or gone,
 * `setEnabled(false)`), since when; and when it last turned it back on (ms since 1970), as its settings went to the node,
 * so the gap it made isn't told as the call's ([MeshReceivers.reading]).
 */
internal class MeshTurns {
    @Volatile
    var offAt: Double? = null
        private set

    @Volatile
    var onAt: Double? = null
        private set

    @Synchronized
    fun sent(enabled: Boolean, at: Double) {
        if (!enabled) {
            if (offAt == null) offAt = at
        } else if (offAt != null) {
            offAt = null
            onAt = at
        }
    }
}
