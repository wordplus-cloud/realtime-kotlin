/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import io.livekit.android.util.LKLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.long
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * WordPlus Mesh (1.0.9): the round trip from this device to each region's node, measured in the background while the
 * node's settings name the nodes ([MeshSettings.probe], `probe.enabled`) and said on the next join (`mesh_rtt`), so
 * the mesh can place the client in its fastest region rather than the region of the node DNS led it to. Never on a
 * join's path: a join says what was measured before, for the network it is on, within `probe.cacheMin`.
 *
 * Each node's `/mesh/ping` is asked once to open the connection, then `probe.samples` times on it, the fastest kept;
 * one region after the other, so the measures don't crowd each other.
 */
object MeshProbe {
    private const val PREFERENCES = "wordplus-mesh-probe"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var running: Job? = null

    /** The app's context, from the first room ([attach]), for a join that has none at hand ([joinParam]). */
    @Volatile
    private var appContext: Context? = null

    /** Gives the probe the app's context: a room does, when it is made. */
    fun attach(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    /** What a join says (`mesh_rtt`), from the context a room attached; null before any. */
    fun joinParam(): String? = appContext?.let { joinParam(it) }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .callTimeout(3, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false)
            .build()
    }

    /** The network a measure belongs to: the kind of transport the device uses now (Wi-Fi, cellular, wired), as
     * coarse as the browser's own key (its connection's type and effective type). */
    fun network(context: Context): String {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return "none"
        val caps = try {
            manager.getNetworkCapabilities(manager.activeNetwork)
        } catch (e: Exception) {
            null
        } ?: return "none"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "wired"
            else -> "other"
        }
    }

    /** Measures the targets in the background, unless this network has a measure of the same regions that is still
     * fresh, or a measure runs already. */
    fun measure(context: Context, targets: List<MeshProbeTarget>, samples: Int, cacheMinutes: Int) {
        if (targets.isEmpty() || running?.isActive == true) return
        val app = context.applicationContext
        val network = network(app)
        if (kept(app, network)?.keys == targets.map { it.region }.toSet()) return
        val count = samples.coerceIn(1, 10)
        running = scope.launch {
            val rtt = mutableMapOf<String, Int>()
            for (target in targets.take(16)) {
                roundTrip(target.url, count)?.let { rtt[target.region] = it }
            }
            if (rtt.isNotEmpty()) keep(app, rtt, network, cacheMinutes)
        }
    }

    /** The fastest of [samples] asks of the node's `/mesh/ping` on an open connection, whole ms from 1 to 5000; null when
     * the node doesn't answer. */
    internal fun roundTrip(origin: String, samples: Int): Int? {
        val request = Request.Builder().url("$origin/mesh/ping").header("Cache-Control", "no-store").build()
        fun ask(): Boolean = try {
            client.newCall(request).execute().use { true }
        } catch (e: Exception) {
            LKLog.v { "probe of $origin: ${e.message}" }
            false
        }
        if (!ask()) return null
        var best: Long? = null
        repeat(samples) {
            val start = System.nanoTime()
            if (ask()) {
                val took = System.nanoTime() - start
                best = minOf(best ?: took, took)
            }
        }
        return best?.let { (it / 1_000_000.0).toInt().coerceIn(1, 5000) }
    }

    /** What this network measured, by region, while fresh. */
    fun kept(context: Context, network: String, now: Long = System.currentTimeMillis()): Map<String, Int>? {
        val raw = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).getString(network, null) ?: return null
        val obj = try {
            Json.parseToJsonElement(raw).jsonObject
        } catch (e: Exception) {
            return null
        }
        val at = (obj["at"] as? JsonPrimitive)?.long ?: return null
        val minutes = (obj["minutes"] as? JsonPrimitive)?.long ?: return null
        if (now - at > minutes * 60_000) return null
        val rtt = obj["rtt"] as? JsonObject ?: return null
        return rtt.mapNotNull { (region, ms) -> (ms as? JsonPrimitive)?.content?.toIntOrNull()?.let { region to it } }.toMap()
    }

    internal fun keep(context: Context, rtt: Map<String, Int>, network: String, minutes: Int, now: Long = System.currentTimeMillis()) {
        val json = buildJsonObject {
            put("at", now)
            put("minutes", minutes.coerceIn(1, 1440))
            put("rtt", buildJsonObject { rtt.forEach { (region, ms) -> put(region, ms) } })
        }
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().putString(network, json.toString()).apply()
    }

    /** What a join says (`mesh_rtt`): this network's fresh measure, "fr:12,lim:18", null without one. */
    fun joinParam(context: Context, network: String = network(context), now: Long = System.currentTimeMillis()): String? {
        val rtt = kept(context, network, now)?.takeIf { it.isNotEmpty() } ?: return null
        return rtt.keys.sorted().take(16).filter { MeshSettings.isRegionName(it) }
            .joinToString(",") { "$it:${(rtt[it] ?: 0).coerceIn(1, 5000)}" }
            .takeIf { it.isNotEmpty() }
    }
}
