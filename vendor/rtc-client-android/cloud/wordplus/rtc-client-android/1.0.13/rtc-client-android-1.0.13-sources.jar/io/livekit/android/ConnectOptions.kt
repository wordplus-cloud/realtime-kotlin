/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android

import io.livekit.android.room.ClientProtocolVersion
import io.livekit.android.room.Mesh
import io.livekit.android.room.MeshApp
import io.livekit.android.room.MeshWait
import io.livekit.android.room.ProtocolVersion
import io.livekit.android.room.Room
import livekit.org.webrtc.PeerConnection

/**
 * Options for using with [Room.connect].
 */
data class ConnectOptions(
    /** Auto subscribe to room tracks upon connect, defaults to true */
    val autoSubscribe: Boolean = true,

    /**
     * A user-provided list of ice servers. This will be merged into
     * the ice servers in [rtcConfig] if it is also provided.
     */
    val iceServers: List<PeerConnection.IceServer>? = null,

    /**
     * A user-provided RTCConfiguration to override options.
     *
     * Note: LiveKit requires [PeerConnection.SdpSemantics.UNIFIED_PLAN] and
     * [PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY], and always enables
     * `enableSctpSnap`. These are overwritten even if set otherwise here.
     */
    val rtcConfig: PeerConnection.RTCConfiguration? = null,
    /**
     * capture and publish audio track on connect, defaults to false
     */
    val audio: Boolean = false,
    /**
     * capture and publish video track on connect, defaults to false
     */
    val video: Boolean = false,

    /**
     * the protocol version to use with the server.
     */
    val protocolVersion: ProtocolVersion = ProtocolVersion.v13,

    /**
     * The client protocol version to advertise to other participants in the room
     * for peer-to-peer feature negotiation (RPC v2, etc.). Defaults to the latest
     * version supported by this SDK build.
     */
    val clientProtocol: ClientProtocolVersion = ClientProtocolVersion.DATA_STREAM_RPC,

    /**
     * WordPlus Mesh: how long a join on a mesh keeps trying, in ms, walking busy nodes and waiting on a held slot,
     * before it reports its last error. A product with a waiting screen passes minutes, since a full mesh adds a
     * server in a few. Defaults to 30 seconds.
     */
    val meshJoinBudgetMs: Long = Mesh.JOIN_BUDGET_MS,

    /**
     * WordPlus Mesh: the video codecs this device decodes in hardware (`h264`, `h265`, `vp8`, `vp9`, `av1`), named on
     * a join to a mesh (`mesh_hwdec`), so the node gives it a track in one of them before any other the track has.
     * Empty says nothing, and the node keeps the track's own order.
     */
    val meshHardwareDecoders: List<String> = emptyList(),

    /**
     * WordPlus Mesh: called each time a join on a mesh starts to wait, with until when and why: `busy`, `slot` or
     * `full` while the mesh holds a place for it, `unreachable` while no server of the list answers.
     */
    val onMeshWait: ((MeshWait) -> Unit)? = null,

    /**
     * WordPlus Mesh (1.0.2): the video codecs this device encodes in hardware, named on a join to a mesh (`mesh_hwenc`),
     * as [meshHardwareDecoders] those it decodes: what a codec policy could have it send. Empty says nothing.
     */
    val meshHardwareEncoders: List<String> = emptyList(),

    /**
     * WordPlus Mesh (1.0.2): the product placing the call, named on each join to a mesh (`rtc_app`) for its live view.
     * A room's, as each room is joined with its own options.
     */
    val meshApp: MeshApp? = null,
    /**
     * WordPlus Mesh (1.0.9): how long the signal connection may take to open, ms (the client's settings'
     * `connect.signalTimeoutMs`); null: 10 s, as before.
     */
    val meshSignalTimeoutMs: Long? = null,
    /**
     * WordPlus Mesh (1.0.9): how long a reconnect waits for the media connections, ms (`connect.pcTimeoutMs`); null:
     * 20 s, as before.
     */
    val meshPcTimeoutMs: Long? = null,
) {
    internal var reconnect: Boolean = false
    internal var participantSid: String? = null
}
