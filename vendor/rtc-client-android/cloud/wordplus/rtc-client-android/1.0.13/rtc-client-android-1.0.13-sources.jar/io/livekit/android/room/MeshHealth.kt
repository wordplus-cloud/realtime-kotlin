/*
 * Copyright 2026 The WordPlus RTC client authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.room

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.roundToInt

// WordPlus Mesh (1.0.6, as rtc-client 1.0.16's room/meshHealth.ts): how the device and the app running a call are doing,
// told to the node with the other reports ([MeshHealth.FIELD]), numbers and the device's names only. A call where a
// viewer's playback froze on every camera at once and its own camera stopped arriving, on a clean line
// (2026-10-23), was a machine that hung; nothing the node saw could say so.
//
// Nothing here runs a timer of its own, so collecting it adds no load to the device: the system's thermal status (PowerManager, Android 10 on: the device's own measure of how hard it is
// pushed, named as the browser's CPU pressure is: nominal, fair, serious, critical), the app's activities going to the
// background and back, audio devices plugged in or out: each a callback the system makes anyway, which adds to a
// counter; the battery charging or not is read at the reading. The path each connection runs on comes from the
// connections' shared reading ([MeshStats]). The browser's main-thread hangs have no native counterpart that costs
// nothing (a watchdog is a timer), so a device says none.

internal object MeshHealth {
    /** The signal request field the report goes in (WordPlus Mesh 1.0.53's `MeshHealthFieldNumber`). */
    const val FIELD = 1003

    /**
     * One connection's path as libwebrtc sees it now, and since the last reading: the round trip (ms) and the upload it
     * estimates (kbit/s), packets the system failed to send (a network gone away), connectivity checks unanswered, the
     * times it changed path.
     */
    @Serializable
    data class Path(
        val rtt: Int? = null,
        val outKbps: Int? = null,
        val sendFailed: Int? = null,
        val unanswered: Int? = null,
        val switched: Int? = null,
    )

    /** The device, once a connection: its cores, memory (GB) and its chip (Android 12 on). */
    @Serializable
    data class Machine(val cores: Int? = null, val memGb: Double? = null, val gpu: String? = null)

    /** The device and the app since the last reading, as the node reads it (its `MeshHealth`): only what there is to say. */
    @Serializable
    data class Report(
        val cpu: String? = null,
        val cpuMs: Int? = null,
        val hangs: Int? = null,
        val hangMs: Int? = null,
        val hiddenMs: Int? = null,
        val battery: Boolean? = null,
        val devices: Int? = null,
        val pub: Path? = null,
        val sub: Path? = null,
        val machine: Machine? = null,
        /** 1.0.9: the settings revision the client runs ([MeshSettings.rev]), in every report once it has settings */
        val cfg: Long? = null,
    ) {
        val isEmpty: Boolean get() = this == Report()
    }

    /** A connection's path totals at a reading, for what changed since. */
    data class PathTotals(val sendFailed: Double?, val asked: Double?, val answered: Double?, val switched: Double?)

    val PRESSURE_RANK = mapOf("nominal" to 0, "fair" to 1, "serious" to 2, "critical" to 3)

    /** The system's thermal status (PowerManager.THERMAL_STATUS_*) named as the node reads pressure. */
    fun pressure(thermalStatus: Int): String = when (thermalStatus) {
        0 -> "nominal"
        1, 2 -> "fair"
        3 -> "serious"
        else -> "critical"
    }

    private fun num(v: Any?): Double? = (v as? Number)?.toDouble()?.takeIf { it.isFinite() }

    /**
     * A connection's path from its reading: the selected pair's round trip and upload estimate, and what changed since
     * [before] (its totals at the last reading); null where the reading has no selected pair.
     */
    fun path(stats: List<MeshEncoders.Stat>, before: PathTotals?): Pair<Path, PathTotals>? {
        val transport = stats.firstOrNull { it.type == "transport" && it.values["selectedCandidatePairId"] is String } ?: return null
        val pairId = transport.values["selectedCandidatePairId"] as String
        val pair = stats.firstOrNull { it.id == pairId } ?: return null
        val now = PathTotals(
            sendFailed = num(pair.values["packetsDiscardedOnSend"]),
            asked = num(pair.values["consentRequestsSent"]) ?: num(pair.values["requestsSent"]),
            answered = num(pair.values["responsesReceived"]),
            switched = num(transport.values["selectedCandidatePairChanges"]),
        )
        fun delta(a: Double?, b: Double?): Double? = if (a != null && b != null && b >= a) b - a else null
        var out = Path(
            rtt = num(pair.values["currentRoundTripTime"])?.let { (it * 1000).roundToInt() },
            outKbps = num(pair.values["availableOutgoingBitrate"])?.let { (it / 1000).roundToInt() },
        )
        if (before != null) {
            val asked = delta(before.asked, now.asked)
            val answered = delta(before.answered, now.answered)
            out = out.copy(
                sendFailed = delta(before.sendFailed, now.sendFailed)?.takeIf { it > 0 }?.toInt(),
                unanswered = if (asked != null && answered != null && asked > answered) (asked - answered).toInt() else null,
                switched = delta(before.switched, now.switched)?.takeIf { it > 0 }?.toInt(),
            )
        }
        return out to now
    }

    private val json = Json { explicitNulls = false }

    /** The report as a node reads it. */
    fun json(report: Report): String = json.encodeToString(report)

    /**
     * The device: its cores, its memory, and its chip as the system names it ("Google Tensor G3"; Android 12 on), the
     * device's model being in its join already (ClientInfo).
     */
    fun machine(context: Context?): Machine {
        var memGb: Double? = null
        (context?.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.let { am ->
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            if (info.totalMem > 0) memGb = Math.round(info.totalMem / 1_073_741_824.0 * 10) / 10.0
        }
        val chip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(Build.SOC_MANUFACTURER, Build.SOC_MODEL).filter { !it.isNullOrBlank() && it != Build.UNKNOWN }.joinToString(" ")
                .takeIf { it.isNotEmpty() }?.take(60)
        } else {
            null
        }
        return Machine(cores = Runtime.getRuntime().availableProcessors(), memGb = memGb, gpu = chip)
    }
}

/** Counts what happens to the device and the app between two readings, from the system's own callbacks. */
internal class MeshHealthWatch(private val context: Context?) {
    private class Counters(
        /** the worst thermal state since the last reading, the one it is in, since when, and ms serious or worse */
        var cpu: String? = null,
        var pressure: String? = null,
        var pressureAt: Long = System.currentTimeMillis(),
        var cpuMs: Long = 0,
        var hiddenMs: Long = 0,
        var hiddenAt: Long? = null,
        var devices: Int = 0,
    )

    private var c = Counters()
    private val paths = mutableMapOf<String, MeshHealth.PathTotals>()
    private var machineSaid = false
    private var started = false
    private val stops = mutableListOf<() -> Unit>()

    /** Starts counting, from the state the system is in now. */
    @Synchronized
    fun start() {
        if (started) return
        started = true
        c = Counters()
        val ctx = context ?: return
        val power = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (power != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            pressureChanged(MeshHealth.pressure(power.currentThermalStatus))
            val listener = PowerManager.OnThermalStatusChangedListener { pressureChanged(MeshHealth.pressure(it)) }
            power.addThermalStatusListener(listener)
            stops.add { power.removeThermalStatusListener(listener) }
        }
        // the app's activities on screen or not: a call answered from the lock screen starts in the background
        val app = ctx.applicationContext as? Application
        if (app != null) {
            val visible = foreground()
            var onScreen = if (visible) 1 else 0
            if (!visible) visibilityChanged(true)
            val callbacks = object : Application.ActivityLifecycleCallbacks {
                override fun onActivityStarted(activity: Activity) {
                    if (++onScreen == 1) visibilityChanged(false)
                }

                override fun onActivityStopped(activity: Activity) {
                    onScreen = maxOf(0, onScreen - 1)
                    if (onScreen == 0) visibilityChanged(true)
                }

                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
                override fun onActivityResumed(activity: Activity) {}
                override fun onActivityPaused(activity: Activity) {}
                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
                override fun onActivityDestroyed(activity: Activity) {}
            }
            app.registerActivityLifecycleCallbacks(callbacks)
            stops.add { app.unregisterActivityLifecycleCallbacks(callbacks) }
        }
        // audio devices plugged in or out; the system calls back once at once with those there, which is no change
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audio != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val callback = object : AudioDeviceCallback() {
                private var primed = false

                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                    if (primed) deviceChanged() else primed = true
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                    deviceChanged()
                }
            }
            audio.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
            stops.add { audio.unregisterAudioDeviceCallback(callback) }
        }
    }

    @Synchronized
    fun stop() {
        stops.forEach { runCatching { it() } }
        stops.clear()
        started = false
    }

    /** The next reading tells the device again: after a join or a reconnect, to a node that may know nothing of it. */
    @Synchronized
    fun tellMachineAgain() {
        machineSaid = false
    }

    @Synchronized
    fun pressureChanged(state: String, now: Long = System.currentTimeMillis()) {
        val rank = MeshHealth.PRESSURE_RANK[state] ?: return
        accountPressure(now)
        c.pressure = state
        val worst = c.cpu?.let { MeshHealth.PRESSURE_RANK[it] }
        if (worst == null || rank > worst) c.cpu = state
    }

    private fun accountPressure(now: Long) {
        val rank = c.pressure?.let { MeshHealth.PRESSURE_RANK[it] } ?: 0
        if (rank >= 2) c.cpuMs += now - c.pressureAt
        c.pressureAt = now
    }

    @Synchronized
    fun visibilityChanged(hidden: Boolean, now: Long = System.currentTimeMillis()) {
        val at = c.hiddenAt
        if (hidden && at == null) {
            c.hiddenAt = now
        } else if (!hidden && at != null) {
            c.hiddenMs += now - at
            c.hiddenAt = null
        }
    }

    @Synchronized
    fun deviceChanged() {
        c.devices++
    }

    /** Whether something since the last reading can't wait for the next: a thermal state serious or worse, a device plugged in or out. */
    @Synchronized
    fun troubled(): Boolean = (c.cpu?.let { MeshHealth.PRESSURE_RANK[it] } ?: 0) >= 2 || c.devices > 0

    /**
     * What happened since the last reading, and the counters started over; paths: each connection's shared reading by
     * name ("pub", "sub"); battery: on battery (not charging), where it can be read. Only what there is to say: a quiet
     * app on a cool device says almost nothing.
     */
    @Synchronized
    fun reading(
        paths: Map<String, List<MeshEncoders.Stat>>,
        battery: Boolean? = onBattery(),
        now: Long = System.currentTimeMillis(),
    ): MeshHealth.Report {
        accountPressure(now)
        val c = this.c
        var pub: MeshHealth.Path? = null
        var sub: MeshHealth.Path? = null
        for ((name, stats) in paths) {
            if (name != "pub" && name != "sub") continue
            val (path, totals) = MeshHealth.path(stats, this.paths[name]) ?: continue
            this.paths[name] = totals
            if (name == "pub") pub = path else sub = path
        }
        val hiddenMs = c.hiddenMs + (c.hiddenAt?.let { now - it } ?: 0)
        val machine = if (machineSaid) null else MeshHealth.machine(context)
        machineSaid = true
        // what carries on (a thermal state, the background) starts the next reading as it is now
        this.c = Counters(cpu = c.pressure, pressure = c.pressure, pressureAt = now, hiddenAt = if (c.hiddenAt != null) now else null)
        return MeshHealth.Report(
            cpu = c.cpu?.takeIf { it != "nominal" },
            cpuMs = c.cpuMs.takeIf { it > 0 }?.toInt(),
            hiddenMs = hiddenMs.takeIf { it > 0 }?.toInt(),
            battery = battery,
            devices = c.devices.takeIf { it > 0 },
            pub = pub,
            sub = sub,
            machine = machine,
        )
    }

    /** On battery (not charging), as the system says now; null where it can't be read. */
    private fun onBattery(): Boolean? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        val battery = context?.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return null
        return !battery.isCharging
    }

    private fun foreground(): Boolean {
        val info = ActivityManager.RunningAppProcessInfo()
        ActivityManager.getMyMemoryState(info)
        return info.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND ||
            info.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
    }
}
